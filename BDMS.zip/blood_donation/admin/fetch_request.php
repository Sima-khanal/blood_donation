<?php
// Include database connection
include('db.php');

// Fetch all blood donation requests from the database
$query = "SELECT * FROM blood_donations ORDER BY request_date DESC";
$result = mysqli_query($conn, $query);

// Generate HTML for the table rows
if (mysqli_num_rows($result) > 0) {
  while ($row = mysqli_fetch_assoc($result)) {
    echo '<tr>';
    echo '<td>' . htmlspecialchars($row['donor_name']) . '</td>';
    echo '<td>' . htmlspecialchars($row['contact']) . '</td>';
    echo '<td>' . htmlspecialchars($row['blood_type']) . '</td>';
    echo '<td>';
    if ($row['status'] == 'pending') {
      echo '<span class="status-pending">Pending</span>';
    } elseif ($row['status'] == 'approved') {
      echo '<span class="status-approved">Approved</span>';
    } else {
      echo '<span class="status-rejected">Rejected</span>';
    }
    echo '</td>';
    echo '<td>' . htmlspecialchars($row['request_date']) . '</td>';
    echo '<td>';
    if ($row['status'] == 'pending') {
      echo '<a href="approve_request.php?id=' . $row['id'] . '" class="btn-approve">Approve</a>';
      echo '<a href="reject_request.php?id=' . $row['id'] . '" class="btn-reject">Reject</a>';
    } else {
      echo '<span class="action-disabled">Action Disabled</span>';
    }
    echo '</td>';
    echo '</tr>';
  }
} else {
  echo '<tr><td colspan="6">No blood donation requests found.</td></tr>';
}
