<?php
include('db.php');

// Fetch blood stocks from the database in serial order
$query = "SELECT * FROM blood_stock ORDER BY id ASC";
$result = $conn->query($query);
$bloodStocks = $result->num_rows > 0 ? $result->fetch_all(MYSQLI_ASSOC) : [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Blood Stock</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f0f0f0;
        }

        /* Glass Effect Navbar */
        .glass-navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            background: rgba(255, 255, 255, 0.2);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .navbar-left h1 {
            font-size: 24px;
            color: #ff4d4d;
        }

        .navbar-right ul {
            list-style: none;
            display: flex;
            gap: 20px;
        }

        .navbar-right ul li {
            display: inline;
        }

        .navbar-right ul li a {
            text-decoration: none;
            color: #333;
            font-weight: bold;
            padding: 8px 15px;
            border-radius: 20px;
            transition: 0.3s;
        }

        .navbar-right ul li a:hover {
            background: rgba(255, 77, 77, 0.2);
            color: #ff4d4d;
        }

        /* Header */
        h1 {
            text-align: center;
            margin: 20px 0;
            color: #0056b3;
        }

        /* Table Styling */
        .table-container {
            width: 90%;
            margin: 20px auto;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
            font-size: 14px;
        }

        table th {
            background-color: #0056b3;
            color: white;
            font-weight: bold;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        /* Form & Buttons */
        form {
            display: inline-block;
        }

        input[type="number"] {
            width: 70px;
            padding: 5px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 4px;
            text-align: center;
        }

        button {
            padding: 5px 10px;
            font-size: 14px;
            color: white;
            background-color: #0056b3;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: 0.3s;
        }

        button:hover {
            background-color: #003d7a;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .glass-navbar {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }

            .navbar-right ul {
                flex-direction: column;
                gap: 10px;
            }

            table {
                font-size: 12px;
            }

            input[type="number"] {
                width: 50px;
            }
        }
    </style>
</head>
<body>

    <nav class="glass-navbar">
        <div class="navbar-left">
            <h1>Blood Donation System</h1>
        </div>
        <div class="navbar-right">
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage_stock.php">Manage Stock</a></li>
                <li><a href="manage_requests.php">Manage Requests</a></li>
                <li><a href="donor_request.php">Donor Request</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <h1>Manage Blood Stock</h1>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Serial No</th>
                    <th>Blood Type</th>
                    <th>Stock</th>
                    <th>Last Updated</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $serial = 1; // Serial number counter
                foreach ($bloodStocks as $stock): ?>
                    <tr>
                        <td><?= $serial++; ?></td>
                        <td><?= htmlspecialchars($stock['blood_type']); ?></td>
                        <td>
                            <form method="POST" action="crud.php">
                                <input type="hidden" name="id" value="<?= htmlspecialchars($stock['id']); ?>">
                                <input type="number" name="stock" value="<?= htmlspecialchars($stock['stock']); ?>" min="0" required>
                        </td>
                        <td><?= htmlspecialchars($stock['created_at']); ?></td>
                        <td>
                            <button type="submit" name="update">Update</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <?php include('footer.php'); ?>

</body>
</html>
