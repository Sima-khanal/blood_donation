<?php
// Include database connection
include('db.php');
if (isset($_GET['blood_type'])) {
    $blood_type = $_GET['blood_type'];

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT stock FROM blood_stock WHERE blood_type = ?");
    $stmt->bind_param("s", $blood_type);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo "<script>alert('Blood Type: " . $blood_type . ", Quantity Available: " . $row['stock'] . "');</script>";
    } else {
        echo "<script>alert('No stock available for Blood Type: " . $blood_type . "');</script>";
    }

    $stmt->close();
}
?>

<body>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f0f0f0;
            padding-bottom: 60px; /* To ensure there's space for the footer */
        }

        /* Glass Effect Navbar */
        .glass-navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            background: rgba(255, 255, 255, 0.2);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .navbar-left h1 {
            font-size: 24px;
            color: #ff4d4d;
        }

        .navbar-right ul {
            list-style: none;
            display: flex;
            gap: 20px;
        }

        .navbar-right ul li {
            display: inline;
        }

        .navbar-right ul li a {
            text-decoration: none;
            color: #333;
            font-weight: bold;
            padding: 8px 15px;
            border-radius: 20px;
            transition: 0.3s;
        }

        .navbar-right ul li a:hover {
            background: rgba(255, 77, 77, 0.2);
            color: #ff4d4d;
        }

        /* Additional page styles */
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background-color: #f4f4f4;
        }

        .search-bar {
            margin-bottom: 20px;
            text-align: center;
        }

        .search-bar input {
            padding: 8px;
            width: 250px;
            margin-right: 10px;
        }

        .search-bar button {
            padding: 8px 12px;
            background-color: #007BFF;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        .search-bar button:hover {
            background-color: #0056b3;
        }

        /* Action column styles */
        table td a {
            text-decoration: none;
            padding: 8px 12px;
            background-color: #007BFF;
            color: white;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        /* On hover, change the background color of the action links */
        table td a:hover {
            background-color: #0056b3;
        }

        /* Make sure the action column text is aligned properly */
        table td {
            text-align: center;
        }

        /* Footer Styles */
        footer {
            background-color: #333;
            color: #fff;
            padding: 40px 20px;
            font-family: Arial, sans-serif;
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        /* Footer Section */
        .footer-section {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            margin-top: 40px;
            margin-bottom: 40px;
            gap: 30px;
            text-align: left;
            width: 100%;
        }

        /* Section Titles */
        h4 {
            color: #007bff;
            margin-bottom: 15px;
            font-size: 18px;
        }

        /* Paragraph and Links */
        p, ul {
            color: #ddd;
            line-height: 1.6;
        }

        /* Links */
        a {
            color: #ddd;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        a:hover {
            color: #007bff;
        }

        /* Quick Links */
        .footer-section ul {
            list-style: none;
            padding: 0;
        }

        .footer-section ul li {
            margin-bottom: 10px;
        }

        /* Contact Info Section */
        .contact-info a {
            color: #ddd;
            text-decoration: underline;
        }

        .contact-info a:hover {
            color: #007bff;
        }

        /* Bottom Text */
        .bottom {
            margin-top: 20px;
            font-size: 14px;
            color: #aaa;
        }

        .bottom p {
            margin: 0;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .footer-section {
                flex-direction: column;
                align-items: center;
            }

            .footer-section div {
                width: 100%;
                margin-bottom: 20px;
            }
        }
    </style>

    <nav class="glass-navbar">
        <div class="navbar-left">
            <h1>Blood Donation System</h1>
        </div>
        <div class="navbar-right">
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage_stock.php">Manage Stock</a></li>
                <li><a href="manage_requests.php">Manage request</a></li>
                <li><a href="donor_request.php"> Donor Request</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <h1>Manage Blood Requests</h1>

    <!-- Search bar for blood types -->
    <form class="search-bar" method="GET" action="">
        <input type="text" name="blood_type" placeholder="Search Blood Group" required>
        <button type="submit">Search</button>
    </form>

    <!-- Display requests -->
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Phone No</th>
                <th>Blood Group</th>
                <th>Quantity</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Query to fetch blood requests
            $sql = "SELECT blood_requests.id, blood_requests.blood_type, blood_requests.quantity, 
                           blood_requests.status, blood_requests.contact_number, users.name 
                    FROM blood_requests 
                    JOIN users ON blood_requests.user_id = users.id";
            $result = $conn->query($sql);

            // Loop through each row and display
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>{$row['name']}</td>";
                echo "<td>{$row['contact_number']}</td>";
                echo "<td>{$row['blood_type']}</td>";
                echo "<td>{$row['quantity']}</td>";
                echo "<td>{$row['status']}</td>";
                echo "<td>";
                if ($row['status'] == 'pending') {
                    echo "<a href='approve_request.php?id={$row['id']}'>Approve</a>";
                } elseif ($row['status'] == 'approved') {
                    echo "<a href='dispatch_request.php?id={$row['id']}'>Dispatch</a>";
                } else {
                    echo "Dispatched";
                }
                echo "</td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>

    <footer>
        <div class="container">
            <div class="footer-section">
                <div>
                    <h4>BD - Admin Panel</h4>
                    <p>Efficiently manage system users, records, and operations.</p>
                </div>

                <div>
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="manage_requests.php">Manage Request</a></li>
                        <li><a href="manage_stock.php">Manage Stock</a></li>
                        <li><a href="donar_request.php">Donar Request</a></li>
                    </ul>
                </div>

                <div class="contact-info">
                    <h4>Contact Support</h4>
                    <p>For any assistance, contact IT support:</p>
                    <p>Email: <a href="mailto:simacodevibrant@gmail.com/upreti.cloudtechservices@gmail.com">simacodevibrant@gmail.com/upreti.cloudtechservices@gmail.com</a></p>
                    <p>Phone: +977-01-2345678</p>
                </div>
            </div>

            <div class="bottom">
                <p>©2025 SD creation. All Rights Reserved.</p>
            </div>
        </div>
    </footer>
</body>

</html>
