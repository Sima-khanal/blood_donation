<?php
// Include database connection
include('db.php');

// Handle donation status update to "approved"
if (isset($_POST['approve_donation'])) {
    $donation_id = $_POST['donation_id'];

    // Update the donation status to "approved" in the database
    $sql = "UPDATE donation SET status = 'approved' WHERE id = $donation_id";
    if ($conn->query($sql) === TRUE) {
        echo "Donation approved.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Handle donation status update to "donated"
if (isset($_POST['donate_blood'])) {
    $donation_id = $_POST['donation_id'];

    // Update the donation status to "donated" in the database
    $sql = "UPDATE donation SET status = 'donated' WHERE id = $donation_id";
    if ($conn->query($sql) === TRUE) {
        // Increase the blood stock when status is updated to "donated"
        $update_stock_sql = "UPDATE blood_stock SET stock = stock + 1 WHERE blood_type = (SELECT blood_type FROM donation WHERE id = $donation_id)";
        $conn->query($update_stock_sql);
        echo "Donation marked as donated. Stock updated.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Handle donation request deletion
if (isset($_POST['delete_donation'])) {
    $donation_id = $_POST['donation_id'];

    // Delete the donation request from the database
    $delete_sql = "DELETE FROM donation WHERE id = $donation_id";
    if ($conn->query($delete_sql) === TRUE) {
        echo "Donation request deleted successfully.";
    } else {
        echo "Error: " . $delete_sql . "<br>" . $conn->error;
    }
}

// Retrieve all donations
$sql = "SELECT * FROM donation";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Donations</title>
    <style>
        /* Reset and Basic Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f7f7f7;
            color: #333;
            flex: 1;
        }

        /* Glass Effect Navbar */
        .glass-navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            background: rgba(255, 255, 255, 0.2);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .navbar-left h1 {
            font-size: 24px;
            color: #ff4d4d;
        }

        .navbar-right ul {
            list-style: none;
            display: flex;
            gap: 20px;
        }

        .navbar-right ul li {
            display: inline;
        }

        .navbar-right ul li a {
            text-decoration: none;
            color: #333;
            font-weight: bold;
            padding: 8px 15px;
            border-radius: 20px;
            transition: 0.3s;
        }

        .navbar-right ul li a:hover {
            background: rgba(255, 77, 77, 0.2);
            color: #ff4d4d;
        }

        /* Table Styles */
        table {
            width: 100%;
            margin: 30px 0;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f4f4f9;
        }

        /* Button Styles */
        button {
            background-color: #4CAF50;
            color: white;
            padding: 6px 15px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #45a049;
        }

        .delete-btn {
            background-color: #f44336;
        }

        .delete-btn:hover {
            background-color: #e53935;
        }

        .donate-btn {
            background-color: #008CBA;
        }

        .donate-btn:hover {
            background-color: #007B9C;
        }

        /* Footer Styles */
        footer {
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 20px;
            background-color: #f1f1f1;
            font-size: 14px;
            color: #888;
            margin-top: auto; /* Added to ensure the footer stays at the bottom */
        }
    </style>
</head>
<body>
    <!-- Glass Navbar -->
    <nav class="glass-navbar">
        <div class="navbar-left">
            <h1>Blood Donation System</h1>
        </div>
        <div class="navbar-right">
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage_stock.php">Manage Stock</a></li>
                <li><a href="manage_requests.php">Manage Requests</a></li>
                <li><a href="donor_request.php">Donor Request</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <!-- Donation Table -->
    <table>
        <thead>
            <tr>
                <th>Donation ID</th>
                <th>Donor Info</th>
                <th>Donation Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="donation-list">
            <?php
            // Display donation records
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <tr id="donation-<?php echo $row['id']; ?>">
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['birthdate'] . " - " . $row['blood_type']; ?></td>
                        <td><?php echo $row['donation_date']; ?></td>
                        <td><?php echo ucfirst($row['status']); ?></td>
                        <td>
                            <?php if ($row['status'] == 'pending') { ?>
                                <button onclick="approveDonation(<?php echo $row['id']; ?>)">Approve</button>
                            <?php } ?>
                            <?php if ($row['status'] == 'approved') { ?>
                                <button onclick="donateBlood(<?php echo $row['id']; ?>)" class="donate-btn">Donate</button>
                            <?php } ?>

                            <?php if ($row['status'] != 'donated') { ?>
                                <button onclick="deleteDonation(<?php echo $row['id']; ?>)" class="delete-btn">Delete</button>
                            <?php } ?>
                        </td>
                    </tr>
                    <?php
                }
            } else {
                echo "<tr><td colspan='5'>No donation records found.</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <script>
        function approveDonation(donation_id) {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onload = function() {
                if (xhr.status == 200) {
                    alert(xhr.responseText);
                    document.getElementById('donation-' + donation_id).querySelector("td:nth-child(4)").textContent = 'Approved';
                    document.getElementById('donation-' + donation_id).querySelector("button").disabled = true;
                }
            };
            xhr.send("approve_donation=true&donation_id=" + donation_id);
        }

        function donateBlood(donation_id) {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onload = function() {
                if (xhr.status == 200) {
                    alert(xhr.responseText);
                    document.getElementById('donation-' + donation_id).querySelector("td:nth-child(4)").textContent = 'Donated';
                    document.getElementById('donation-' + donation_id).querySelector("button").disabled = true;
                }
            };
            xhr.send("donate_blood=true&donation_id=" + donation_id);
        }

        function deleteDonation(donation_id) {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onload = function() {
                if (xhr.status == 200) {
                    alert(xhr.responseText);
                    document.getElementById('donation-' + donation_id).remove();
                }
            };
            xhr.send("delete_donation=true&donation_id=" + donation_id);
        }
    </script>

    <?php include('footer.php'); ?>
</body>
</html>
