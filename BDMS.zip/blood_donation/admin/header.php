<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="Stylesheet" href="styles.css">
</head>

<body>
 <header>
        <div class="container">
          <div class="logo">
            <img src="https://i.pinimg.com/474x/3f/66/64/3f66647bf0b133d872d22f016aedaf56.jpg" alt="Hospital Logo">
          </div>
      
        <nav>
            <button type="button" onclick="window.location.href='dashboard.php'">Dashboard</button>
            <button type="button" onclick="window.location.href='manage_stock.php'">Manage Stock</button>
            <button type="button" onclick="window.location.href='manage_requests.php'">Manage Requests</button>
            <button type="button" onclick="window.location.href='donor_request.php'">Donor Request</button>
            <button type="button" onclick="window.location.href='logout.php'">Logout</button>
        </nav>
    </div>
</header>


