<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="Stylesheet" href="style.css">
</head>

<body>
 <header>
        <div class="container">
          <div class="logo">
            <img src="https://i.pinimg.com/474x/3f/66/64/3f66647bf0b133d872d22f016aedaf56.jpg" alt="Hospital Logo">
          </div>
      
          <nav>
              <button type="button" onclick="window.location.href='dashboard.php'">Dashboard</button>
           <button type="button" onclick="window.location.href='request_blood.php'">Blood Request</button>
           <button type="button" onclick="window.location.href='blood_donation.php'">Donation Request</button> 
           <button type="button" onclick="window.location.href='view_requests.php'">View Request</button>
              <button type="button" onclick="window.location.href='logout.php'">Logout</button>
          </nav>
        </div>
      </header>
