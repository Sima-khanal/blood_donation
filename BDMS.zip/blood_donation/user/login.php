<?php
// Include the database connection
include('db.php');

// Define variables and set them to empty values
$email = $password = "";
$emailErr = $passwordErr = "";
$userErr = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize the email and password input
    $email = test_input($_POST["email"]);
    $password = test_input($_POST["password"]);

    // If email and password are provided, check in the database
    if (!empty($email) && !empty($password)) {
        // Prepare the SQL query to fetch user data
        $sql = "SELECT * FROM users WHERE email='$email'";

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) == 1) {
            // Fetch the user data
            $row = mysqli_fetch_assoc($result);
            // Verify the password
            if (password_verify($password, $row['password'])) {
                // Correct password, start a session and redirect to the dashboard
                session_start();
                $_SESSION['user_id'] = $row['id']; // Store the user ID in session
                header("Location: dashboard.php"); // Redirect to the dashboard
                exit();
            } else {
                $userErr = "Invalid email or password.";
            }
        } else {
            $userErr = "No user found with this email.";
        }
    } else {
        $userErr = "Please enter both email and password.";
    }
}

// Function to clean input data to avoid XSS and other vulnerabilities
function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
        }

        #login-section {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #f8f9fa;
        }

        .login-container {
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
            padding: 20px;
        }

        .login-container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #007bff;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        form label {
            margin-bottom: 5px;
            font-weight: bold;
        }

        form input {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        form .error {
            color: #d9534f;
            font-size: 12px;
        }

        .btn-submit {
            background-color: #007bff;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .btn-submit:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <section id="login-section">
        <div class="login-container">
            <h2>User Login</h2>
            <form action="login.php" method="POST">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo $email; ?>" required />

                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required />

                <span class="error"><?php echo $userErr; ?></span>

                <button type="submit" class="btn-submit">Login</button>
                
        <p> Don't have account? <a href="register.php">Register Here</a></p>
            </form>
        </div>
    </section>
</body>

</html>
