 MySQL returned an empty result set (i.e. zero rows). (Query took 0.0009 seconds.)
-- Create the database (if not already created) CREATE DATABASE blood_donation;
[ Edit inline ] [ Edit ] [ Create PHP code ]
 Error: #1046 No database selected
 MySQL returned an empty result set (i.e. zero rows). (Query took 0.0002 seconds.)
-- Use the database USE blood_donation;
[ Edit inline ] [ Edit ] [ Create PHP code ]
 Error: #1046 No database selected
 MySQL returned an empty result set (i.e. zero rows). (Query took 0.3454 seconds.)
-- Create the admin table CREATE TABLE admins ( admin_id VARCHAR(50) PRIMARY KEY, password VARCHAR(255) NOT NULL -- Store hashed passwords for security );
[ Edit inline ] [ Edit ] [ Create PHP code ]
 1 row inserted. (Query took 0.0498 seconds.)
-- Insert sample admin credentials (replace 'admin123' and 'password123' with your desired values) INSERT INTO admins (admin_id, password) VALUES ('admin123', 'password123');
[ Edit inline ] [ Edit ] [ Create PHP code ]
 MySQL returned an empty result set (i.e. zero rows). (Query took 0.0003 seconds.)
-- The password 'password123' is hashed using PHP's password_hash() function.;
[ Edit inline ] [ Edit ] [ Create PHP code ]