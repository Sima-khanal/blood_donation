<?php
require 'db.php'; // Database connection file
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id']; // Get the logged-in user's ID

// Fetch donation requests for the logged-in user
$sql = "SELECT * FROM donation WHERE user_id = ? ORDER BY created_at DESC";
// Check if we are receiving the quantity update request
if (isset($_POST['update_quantity']) && isset($_POST['request_id']) && isset($_POST['new_quantity'])) {
    // Sanitize and get the inputs
    $request_id = $_POST['request_id'];
    $new_quantity = $_POST['new_quantity'];

    // Update the quantity in the database
    $sql_update = "UPDATE blood_requests SET quantity = '$new_quantity' WHERE id = '$request_id' AND user_id = '$user_id'";
    if (mysqli_query($conn, $sql_update)) {
        echo "Quantity updated successfully!";
    } else {
        echo "Error updating quantity: " . mysqli_error($conn);
    }
    exit(); // Exit after the update
}

// Retrieve the blood requests made by the logged-in user
$sql = "SELECT * FROM donation WHERE user_id = '$user_id'";
$result = mysqli_query($conn, $sql);?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Donation Requests</title>
    <style>
        <style>
    * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background: #f0f0f0;
}

/* Glass Effect Navbar */
.glass-navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 30px;
    background: rgba(255, 255, 255, 0.2);
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(10px);
    position: sticky;
    top: 0;
    z-index: 1000;
}

.navbar-left h1 {
    font-size: 24px;
    color: #ff4d4d;
}

.navbar-right ul {
    list-style: none;
    display: flex;
    gap: 20px;
}

.navbar-right ul li {
    display: inline;
}

.navbar-right ul li a {
    text-decoration: none;
    color: #333;
    font-weight: bold;
    padding: 8px 15px;
    border-radius: 20px;
    transition: 0.3s;
}

.navbar-right ul li a:hover {
    background: rgba(255, 77, 77, 0.2);
    color: #ff4d4d;
}

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #f4f4f4;
        }

        .pending { color: orange; }
        .approved { color: green; }
        .cancelled { color: red; }
        .donated { color: blue; }
    </style>
</head>
<body>
 <nav class="glass-navbar">
        <div class="navbar-left">
            <h1>Blood Donation System</h1>
        </div>
            <div class="navbar-right">
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="request_blood.php">Request</a></li>
            <li><a href="blood_donation.php">Donation</a></li>
            <li><a href="view_requests.php">View Request Status</a></li>
            <li><a href="view_donation_status.php">Donation Status</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>
    </nav>

<div class="container">
    <h2>My Donation Requests</h2>

    <?php if ($result->num_rows > 0): ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Donation Date</th>
                <th>Blood Type</th>
                <th>Weight (kg)</th>
                <th>Status</th>
            </tr>

            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= $row['donation_date']; ?></td>
                    <td><?= $row['blood_type']; ?></td>
                    <td><?= $row['weight_kg']; ?></td>
                    <td class="<?= strtolower($row['status']); ?>"><?= $row['status']; ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>No donation requests found.</p>
    <?php endif; ?>

</div>
<?php include('footer.php'); ?>

</body>
</html>
