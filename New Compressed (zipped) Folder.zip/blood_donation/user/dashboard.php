<?php
// Start the session to access session variables
session_start();

// Include the header
include('header.php');
?>

<style>
  /* General Styling for User Dashboard */
  #user-dashboard {
    background-color: #f9f9f9;
    padding: 20px;
    font-family: Arial, sans-serif;
  }

  .dashboard-container {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
  }

  /* Main Content Area */
  #main-content {
    flex: 1;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    padding: 20px;
  }

  /* Header Styling */
  .main-content-header {
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid #ddd;
  }

  .admin-info h2 {
    font-size: 24px;
    color: #333;
    margin: 0;
  }

  .admin-info p {
    color: #666;
    margin-top: 5px;
    font-size: 14px;
  }

  /* Overview Items */
  .overview-item {
    background-color: #e8f5e9;
    border: 1px solid #c8e6c9;
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 20px;
    text-align: center;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
  }

  .overview-item:hover {
    transform: translateY(-5px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
  }

  .overview-item a {
    text-decoration: none;
    color: #333;
  }

  .overview-item h3 {
    margin: 0;
    font-size: 20px;
    color: #2e7d32;
  }

  .overview-item p {
    margin: 10px 0 0;
    font-size: 18px;
    font-weight: bold;
    color: #1b5e20;
  }

  /* Responsive Design */
  @media (max-width: 768px) {
    .dashboard-container {
      flex-direction: column;
    }

    .overview-item {
      margin: 0 auto 20px;
      width: 100%;
    }
  }
</style>

<!-- Admin Dashboard Section -->
<section id="user-dashboard">
  <div class="dashboard-container">
    <!-- Sidebar -->

    <!-- Main Content Area -->
    <main id="main-content">
      <div class="main-content-header">
        <div class="admin-info">
  <h2>Welcome, <?php echo isset($_SESSION['username']) ? $_SESSION['username'] : 'User'; ?>!</h2>
  <p>Manage the blood donation system with ease.</p>
</div>

      </div>

      <!-- Dashboard Overview -->
      <div class="overview-item">
        <a href="request_blood.php">
          <h3>Blood Request</h3>
          <p>120</p>
        </a>
      </div>

      <div class="overview-item">
        <a href="view_requests.php">
          <h3>View Request</h3>
          <p>15</p>
        </a>
      </div>
    </div>
  </main>
</div>
</section>

<script src="script.js"></script>

<?php
// If the session contains a username, show the welcome alert
if (isset($_SESSION['username'])) {
    echo '<script>alert("Welcome, ' . $_SESSION['username'] . '!");</script>';
    // Unset session username after displaying the alert
    unset($_SESSION['username']);
}
?>

<?php
// Include the footer
include('footer.php');
?>
