<?php
session_start();

// Include the database connection
include('db.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

// Get the logged-in user's ID
$user_id = $_SESSION['user_id'];

// Check if we are receiving the quantity update request
if (isset($_POST['update_quantity']) && isset($_POST['request_id']) && isset($_POST['new_quantity'])) {
    // Sanitize and get the inputs
    $request_id = $_POST['request_id'];
    $new_quantity = $_POST['new_quantity'];

    // Validation: Quantity must be between 1 and 5, and not negative
    if ($new_quantity < 1) {
        echo "Error: Quantity must be greater or equal to 1.";
        exit();
    } elseif ($new_quantity > 5) {
        echo "Error: Quantity must be less or equal to 5.";
        exit();
    }

    // Update the quantity in the database
    $sql_update = "UPDATE blood_requests SET quantity = '$new_quantity' WHERE id = '$request_id' AND user_id = '$user_id'";
    if (mysqli_query($conn, $sql_update)) {
        echo "Quantity updated successfully!";
    } else {
        echo "Error updating quantity: " . mysqli_error($conn);
    }
    exit(); // Exit after the update
}

// Retrieve the blood requests made by the logged-in user
$sql = "SELECT * FROM blood_requests WHERE user_id = '$user_id'";
$result = mysqli_query($conn, $sql);
?>
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: Arial, sans-serif;
        background: #f0f0f0;
    }

    /* Glass Effect Navbar */
    .glass-navbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px 30px;
        background: rgba(255, 255, 255, 0.2);
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        backdrop-filter: blur(10px);
        position: sticky;
        top: 0;
        z-index: 1000;
    }

    .navbar-left h1 {
        font-size: 24px;
        color: #ff4d4d;
    }

    .navbar-right ul {
        list-style: none;
        display: flex;
        gap: 20px;
    }

    .navbar-right ul li {
        display: inline;
    }

    .navbar-right ul li a {
        text-decoration: none;
        color: #333;
        font-weight: bold;
        padding: 8px 15px;
        border-radius: 20px;
        transition: 0.3s;
    }

    .navbar-right ul li a:hover {
        background: rgba(255, 77, 77, 0.2);
        color: #ff4d4d;
    }
</style>
<nav class="glass-navbar">
    <div class="navbar-left">
        <h1>Blood Donation System</h1>
    </div>
    <div class="navbar-right">
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="request_blood.php">Request</a></li>
            <li><a href="blood_donation.php">Donation</a></li>
            <li><a href="view_requests.php">View Request Status</a></li>
            <li><a href="view_donation_status.php">Donation Status</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>
</nav>
<!-- View Requests Section -->
<section id="view-requests-section">
    <div class="view-requests-container">
        <h2>Your Blood Donation Requests</h2>

        <?php
            // Check if the user has made any requests
            if (mysqli_num_rows($result) > 0) {
                // Display the requests in a table
                echo '<table class="requests-table">
                        <tr>
                            <th>Blood Type</th>
                            <th>Contact Number</th>
                            <th>Status</th>
                            <th>Quantity</th>
                            <th>Message</th>
                            <th>Action</th>
                        </tr>';

                        while ($row = mysqli_fetch_assoc($result)) {
                            // Determine the status
                            $status = $row['status'] == 'pending' ? 'Pending' : ($row['status'] == 'approved' ? 'Approved' : 'Dispatched');
                            
                            // Allow users to update the quantity only if status is 'pending'
                            $can_update = ($row['status'] == 'pending');

                            echo '<tr>
                            <td>' . $row['blood_type'] . '</td>
                            <td>' . $row['contact_number'] . '</td>
                            <td>' . $status . '</td>
                            <td class="quantity-column" data-id="' . $row['id'] . '">
                                <span class="quantity-text">' . $row['quantity'] . '</span>
                                <input class="quantity-input" type="number" value="' . $row['quantity'] . '" style="display: none;">
                                <span class="quantity-error" style="color: red; display: none;"></span>
                            </td>
                            <td>' . $row['message'] . '</td>
                            <td>';

                            if ($can_update) {
                                echo '<button class="btn-update-quantity" data-id="' . $row['id'] . '">Update Quantity</button>';
                            } else {
                                echo 'N/A';
                            }

                            echo '</td></tr>';
                        }
                echo '</table>';
            } else {
                echo '<p>You have not made any blood donation requests yet.</p>';
            }
            ?>
        </div>
    </section>

    <script>
document.addEventListener('DOMContentLoaded', function() {
    const updateButtons = document.querySelectorAll('.btn-update-quantity');

    updateButtons.forEach(button => {
        button.addEventListener('click', function() {
            const row = this.closest('tr');
            const quantityColumn = row.querySelector('.quantity-column');
            const quantityText = quantityColumn.querySelector('.quantity-text');
            const quantityInput = quantityColumn.querySelector('.quantity-input');
            const quantityError = quantityColumn.querySelector('.quantity-error');

            // Toggle visibility of the text and input field
            quantityText.style.display = 'none';
            quantityInput.style.display = 'inline';
            quantityError.style.display = 'none'; // Hide error message when editing

            // Focus the input field
            quantityInput.focus();
        });
    });

    // Function to update quantity when Enter is pressed
    const quantityInputs = document.querySelectorAll('.quantity-input');
    quantityInputs.forEach(input => {
        input.addEventListener('keydown', function(event) {
            if (event.key === 'Enter') {
                const row = this.closest('tr');
                const quantityColumn = row.querySelector('.quantity-column');
                const quantityText = quantityColumn.querySelector('.quantity-text');
                const quantityError = quantityColumn.querySelector('.quantity-error');
                const newQuantity = this.value;
                const requestId = row.querySelector('.btn-update-quantity').getAttribute('data-id');

                // Client-side validation for quantity: Must be between 1 and 5
                if (newQuantity < 1) {
                    quantityError.textContent = "Value must be greater or equal to 1";
                    quantityError.style.display = 'block';
                    return; // Prevent the update if invalid
                } else if (newQuantity > 5) {
                    quantityError.textContent = "Value must be less or equal to 5";
                    quantityError.style.display = 'block';
                    return; // Prevent the update if invalid
                }

                // Update the table and the database
                updateQuantity(requestId, newQuantity);

                // Hide the input and show the updated quantity
                quantityText.textContent = newQuantity;
                quantityText.style.display = 'inline';
                this.style.display = 'none';
            }
        });
    });

    // Function to send the updated quantity to the server
    function updateQuantity(requestId, newQuantity) {
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'view_requests.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                // Handle the server response
                console.log(xhr.responseText);
                // After updating, reload the page to get the latest data
                window.location.reload(); // This will reload the page and show the updated quantity
            }
        };
        xhr.send('update_quantity=true&request_id=' + requestId + '&new_quantity=' + newQuantity);
    }
});
</script>

<style>
/* View Requests Section */
#view-requests-section {
    padding: 40px 20px;
    background-color: #f9f9f9;
    font-family: Arial, sans-serif;
}

.view-requests-container {
    max-width: 900px;
    margin: 0 auto;
    background-color: #fff;
    padding: 20px 30px;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.view-requests-container h2 {
    text-align: center;
    font-size: 24px;
    color: #333;
    margin-bottom: 20px;
}

/* Table Styling */
.requests-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
}

.requests-table th,
.requests-table td {
    padding: 12px 15px;
    text-align: center;
    border: 1px solid #ddd;
    font-size: 14px;
}

.requests-table th {
    background-color: #007bff;
    color: #fff;
    font-weight: bold;
}

.requests-table tr:nth-child(even) {
    background-color: #f2f2f2;
}

.requests-table tr:hover {
    background-color: #e6f7ff;
}

/* Action Button Styling */
.btn-update-quantity {
    display: inline-block;
    padding: 8px 12px;
    background-color: #ff9900;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
    font-size: 14px;
    transition: background-color 0.3s;
}

.btn-update-quantity:hover {
    background-color: #cc7a00;
}

/* No Requests Message */
.view-requests-container p {
    text-align: center;
    color: #666;
    font-size: 16px;
    margin-top: 20px;
}

/* Responsive Design */
@media (max-width: 768px) {
    .view-requests-container {
        padding: 15px 20px;
    }

    .requests-table th,
    .requests-table td {
        padding: 10px;
        font-size: 12px;
    }

    .btn-update-quantity {
        font-size: 12px;
        padding: 6px 10px;
    }
}
</style>

<?php include('footer.php'); ?>
