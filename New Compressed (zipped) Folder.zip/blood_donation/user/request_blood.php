<?php
session_start();

// Include the database connection
include('db.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
  header('Location: login.php');
  exit();
}

// Define variables and set them to empty values
$blood_type = $contact_number = $message = $quantity = "";
$blood_typeErr = $contact_numberErr = $messageErr = $quantityErr = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Validate Blood Type
  if (empty($_POST["blood_type"])) {
    $blood_typeErr = "Blood type is required.";
  } else {
    $blood_type = test_input($_POST["blood_type"]);
  }

  // Validate Contact Number
  if (empty($_POST["contact_number"])) {
    $contact_numberErr = "Contact number is required.";
  } else {
    $contact_number = test_input($_POST["contact_number"]);
    if (!preg_match("/^[0-9]{10}$/", $contact_number)) {
      $contact_numberErr = "Invalid contact number.";
    }
  }

  // Validate Message
  if (empty($_POST["message"])) {
    $messageErr = "Message is required.";
  } else {
    $message = test_input($_POST["message"]);
  }

  // Validate Quantity
  if (empty($_POST["quantity"])) {
    $quantityErr = "Quantity is required.";
  } else {
    $quantity = test_input($_POST["quantity"]);
    if ($quantity < 1 || $quantity > 5) {
      $quantityErr = "Quantity must be between 1 and 5.";
    }
  }

  // Check how many requests the user has made in the current week
  if (empty($blood_typeErr) && empty($contact_numberErr) && empty($messageErr) && empty($quantityErr)) {
    $user_id = $_SESSION['user_id'];

    // Get the current date and the start of the current week
    $current_date = date('Y-m-d');
    $start_of_week = date('Y-m-d', strtotime('monday this week'));

    // Query to count blood requests made by the user in the current week
    $sql = "SELECT COUNT(*) as request_count FROM blood_requests 
            WHERE user_id = '$user_id' AND created_at >= '$start_of_week' AND created_at <= '$current_date'";

    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    if ($row['request_count'] >= 2) {
      $quantityErr = "You can only request blood twice a week.";
    } else {
      // If no errors, save the request to the database
      $sql_insert = "INSERT INTO blood_requests (user_id, blood_type, contact_number, message, quantity, status, created_at) 
                     VALUES ('$user_id', '$blood_type', '$contact_number', '$message', '$quantity', 'pending', NOW())";

      if (mysqli_query($conn, $sql_insert)) {
        $success_message = "Your blood request has been submitted successfully.";
      } else {
        $error_message = "Error: Could not submit the request.";
      }
    }
  }
}

// Function to clean input data
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Request Blood Donation</title>
  <style>
    /* Add your styles here */
  </style>
</head>

<body>

<style>
    * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background: #f0f0f0;
}

/* Glass Effect Navbar */
.glass-navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 30px;
    background: rgba(255, 255, 255, 0.2);
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(10px);
    position: sticky;
    top: 0;
    z-index: 1000;
}

.navbar-left h1 {
    font-size: 24px;
    color: #ff4d4d;
}

.navbar-right ul {
    list-style: none;
    display: flex;
    gap: 20px;
}

.navbar-right ul li {
    display: inline;
}

.navbar-right ul li a {
    text-decoration: none;
    color: #333;
    font-weight: bold;
    padding: 8px 15px;
    border-radius: 20px;
    transition: 0.3s;
}

.navbar-right ul li a:hover {
    background: rgba(255, 77, 77, 0.2);
    color: #ff4d4d;
}
</style>

    <nav class="glass-navbar">
        <div class="navbar-left">
            <h1>Blood Donation System</h1>
        </div>
        <div class="navbar-right">
            <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="request_blood.php">Request</a></li>
            <li><a href="blood_donation.php">Donation</a></li>
            <li><a href="view_requests.php">View Request Status</a></li>
            <li><a href="view_donation_status.php">Donation Status</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
        </div>
    </nav>
  <section id="request-blood-section">
    <div class="request-container">
      <h2>Request Blood Donation</h2>
      <?php
      if (isset($success_message)) {
        echo '<p class="success-message">' . $success_message . '</p>';
      }
      if (isset($error_message)) {
        echo '<p class="error-message">' . $error_message . '</p>';
      }
      ?>
     <form action="request_blood.php" method="POST">
  <label for="blood_type">Blood Type:</label>
  <select id="blood_type" name="blood_type" required>
    <option value="">Select Blood Type</option>
    <option value="A+" <?php echo ($blood_type == "A+") ? 'selected' : ''; ?>>A+</option>
    <option value="A-" <?php echo ($blood_type == "A-") ? 'selected' : ''; ?>>A-</option>
    <option value="B+" <?php echo ($blood_type == "B+") ? 'selected' : ''; ?>>B+</option>
    <option value="B-" <?php echo ($blood_type == "B-") ? 'selected' : ''; ?>>B-</option>
    <option value="O+" <?php echo ($blood_type == "O+") ? 'selected' : ''; ?>>O+</option>
    <option value="O-" <?php echo ($blood_type == "O-") ? 'selected' : ''; ?>>O-</option>
    <option value="AB+" <?php echo ($blood_type == "AB+") ? 'selected' : ''; ?>>AB+</option>
    <option value="AB-" <?php echo ($blood_type == "AB-") ? 'selected' : ''; ?>>AB-</option>
  </select>
  <span class="error"><?php echo $blood_typeErr; ?></span>

  <label for="contact_number">Contact Number:</label>
  <input type="text" id="contact_number" name="contact_number" value="<?php echo $contact_number; ?>" required />
  <span class="error"><?php echo $contact_numberErr; ?></span>

  <label for="message">Message:</label>
  <textarea id="message" name="message" required><?php echo $message; ?></textarea>
  <span class="error"><?php echo $messageErr; ?></span>

  <!-- Quantity Section -->
  <label for="quantity">Quantity (up to 5):</label>
  <input type="number" id="quantity" name="quantity" value="<?php echo $quantity; ?>" min="1" max="5" required />
  <span class="error"><?php echo $quantityErr; ?></span>

  <button type="submit" class="btn-submit">Submit Request</button>
</form>

    </div>
  </section>

  <!-- Your Footer here -->
  <?php include('footer.php'); ?>
  <style>
    /* Request Blood Section Styling */
    #request-blood-section {
      background-color: #f9f9f9;
      /* Light background */
      padding: 40px 20px;
      font-family: Arial, sans-serif;
    }

    .request-container {
      max-width: 600px;
      margin: 0 auto;
      /* Center the container */
      background-color: #fff;
      /* White background for form */
      border-radius: 8px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      /* Subtle shadow */
      padding: 20px 30px;
    }

    .request-container h2 {
      text-align: center;
      font-size: 24px;
      color: #333;
      margin-bottom: 20px;
    }

    /* Success and Error Messages */
    .success-message {
      color: #2e7d32;
      /* Green text for success */
      background-color: #e8f5e9;
      /* Light green background */
      border: 1px solid #c8e6c9;
      padding: 10px;
      margin-bottom: 15px;
      border-radius: 5px;
    }

    .error-message {
      color: #b71c1c;
      /* Red text for error */
      background-color: #ffcdd2;
      /* Light red background */
      border: 1px solid #e57373;
      padding: 10px;
      margin-bottom: 15px;
      border-radius: 5px;
    }

    /* Form Styling */
    form {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }

    form label {
      font-size: 14px;
      color: #555;
    }

    form select,
    form input[type="text"],
    form textarea {
      width: 100%;
      padding: 10px;
      font-size: 14px;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
      background-color: #fff;
      transition: border-color 0.3s;
    }

    form select:focus,
    form input[type="text"]:focus,
    form textarea:focus {
      border-color: #007bff;
      /* Highlighted border */
      outline: none;
    }

    form textarea {
      resize: none;
      /* Prevents resizing */
      height: 100px;
    }

    form .error {
      font-size: 12px;
      color: #b71c1c;
      /* Red for error text */
    }

    /* Button Styling */
    .btn-submit {
      background-color: #007bff;
      /* Primary blue color */
      color: #fff;
      padding: 12px;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .btn-submit:hover {
      background-color: #0056b3;
      /* Darker blue on hover */
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      .request-container {
        padding: 15px 20px;
      }

      form textarea {
        height: 80px;
      }

      .btn-submit {
        font-size: 14px;
        padding: 10px;
      }
    }
  </style>

</body>

</html>