<?php
// Include database connection
include('db.php');

// Retrieve form data
$donation_date = isset($_POST['donation_date']) ? $_POST['donation_date'] : ''; // New field
$birthdate = isset($_POST['birthdate']) ? $_POST['birthdate'] : '';
$last_donated_date = isset($_POST['last_donated_date']) ? $_POST['last_donated_date'] : '';
$blood_type = isset($_POST['blood_type']) ? $_POST['blood_type'] : '';
$quantity = isset($_POST['quantity']) ? $_POST['quantity'] : '';
$weight = isset($_POST['weight']) ? $_POST['weight'] : '';
$health_declaration = isset($_POST['health_declaration']) ? 1 : 0;

// Validate health declaration
if ($health_declaration == 0) {
    echo "You must declare that you are fit to donate blood.";
    exit;
}

// SQL query to insert data into the donation table
$sql = "INSERT INTO donation (birthdate, last_donated_date, donation_date, blood_type, quantity_ml, weight_kg) 
        VALUES ('$birthdate', '$last_donated_date', '$donation_date', '$blood_type', $quantity, $weight)";

// Execute the query
if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Thank you for your donation! Your data has been successfully recorded.');</script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enhanced Blood Donation Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: #f4f4f9;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            margin: 0 auto;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            font-weight: bold;
        }

        input, select, textarea {
            width: 100%;
            padding: 8px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        span {
            font-size: 12px;
            color: red;
        }

        .checkbox-group {
            margin-bottom: 15px;
        }

        #donation-date-message {
    color: red;
    font-size: 12px;
}

    </style>
</head>
<body>
    <?php include('header.php'); ?>
    <h2>Blood Donation Form</h2>
    <form id="blood-donation-form" method="POST" action="blood_donation.php">
        <div class="form-group">
            <label for="birthdate">Birthdate:</label>
            <input type="date" id="birthdate" name="birthdate" required>
            <span id="age-message"></span>
        </div>
       
        <div class="form-group">
            <label for="last_donated_date">Last Donated Date:</label>
            <input type="date" id="last_donated_date" name="last_donated_date" required>
            <span id="donation-message"></span>
        </div>

        <div class="form-group">
            <label for="donation_date">Appointment Date:</label>
            <input type="date" id="donation_date" name="donation_date" required>
        </div>

        <div class="form-group">
            <label for="blood_type">Blood Type:</label>
            <select id="blood_type" name="blood_type" required>
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
            </select>
        </div>

        <div class="form-group">
            <label for="quantity">Quantity (in milliliters):</label>
            <input type="number" id="quantity" name="quantity" min="200" max="500" step="50" required>
            <span id="quantity-message"></span>
        </div>

        <div class="form-group">
            <label for="weight">Weight (in kilograms):</label>
            <input type="number" id="weight" name="weight" min="50" required>
            <span id="weight-message"></span>
        </div>

        <div class="checkbox-group">
            <label>
                <input type="checkbox" id="health-declaration" name="health_declaration" required>
                I declare that I do not have any communicable or non-communicable diseases.
            </label>
            <span id="health-message"></span>
        </div>

        <button type="submit" id="submit-btn">Submit Donation</button>
    </form>

    <?php include('footer.php'); ?>
    <script>

    document.getElementById("blood-donation-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form submission

    let valid = true;
    const ageMessage = document.getElementById("age-message");
    const donationMessage = document.getElementById("donation-message");
    const quantityMessage = document.getElementById("quantity-message");
    const weightMessage = document.getElementById("weight-message");
    const healthMessage = document.getElementById("health-message");
    const donationDateMessage = document.getElementById("donation-date-message"); // New message span

    ageMessage.textContent = "";
    donationMessage.textContent = "";
    quantityMessage.textContent = "";
    weightMessage.textContent = "";
    healthMessage.textContent = "";
    donationDateMessage.textContent = ""; // Clear donation date message

    // Age Validation (18-50 years)
    const birthdate = document.getElementById("birthdate").value;
    const birthDateObj = new Date(birthdate);
    const today = new Date();
    let age = today.getFullYear() - birthDateObj.getFullYear();
    const month = today.getMonth() - birthDateObj.getMonth();
    if (month < 0 || (month === 0 && today.getDate() < birthDateObj.getDate())) {
        age--;
    }

    if (age < 18 || age > 50) {
        valid = false;
        ageMessage.textContent = "You must be between 18 and 50 years old to donate blood.";
    }

    /// Donation Date Validation (Appointment Date cannot be in the past)
const donationDate = document.getElementById("donation_date").value;
const donationDateObj = new Date(donationDate);
const today = new Date();

// Set the time of 'today' to midnight to ensure only the date is compared
today.setHours(0, 0, 0, 0);  // This ensures the time part is ignored

if (donationDateObj < today) {
    valid = false;
    donationMessage.textContent = "Your appointment date cannot be in the past. Please choose a future date.";
}

    // Donation Date Validation (At least 3 months since last donation)
    const lastDonatedDate = document.getElementById("last_donated_date").value;
    const lastDonationDateObj = new Date(lastDonatedDate);
    const diffInTime = today - lastDonationDateObj;
    const diffInDays = diffInTime / (1000 * 3600 * 24);

    if (diffInDays < 90) {
        valid = false;
        donationMessage.textContent = "You must wait at least 3 months between donations.";
    }

    // Weight Validation
    const weight = document.getElementById("weight").value;
    if (weight < 50) {
        valid = false;
        weightMessage.textContent = "You must weigh at least 50 kg to donate blood.";
    }

    // Health Declaration Validation
    const healthDeclaration = document.getElementById("health-declaration").checked;
    if (!healthDeclaration) {
        valid = false;
        healthMessage.textContent = "You must confirm that you have no communicable or non-communicable diseases.";
    }

    // Quantity Validation
    const quantity = document.getElementById("quantity").value;
    if (quantity < 200 || quantity > 500) {
        valid = false;
        quantityMessage.textContent = "You can only donate between 200 ml and 500 ml.";
    }

    // If all validations pass, show success alert and submit the form
    if (valid) {
        alert("Donation form submitted successfully!");
        this.submit(); // Submit the form
    }
});
</script>
</body>
</html>
