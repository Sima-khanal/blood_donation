<footer style="background-color: #333; color: white; padding: 30px 20px; text-align: center; font-family: Arial, sans-serif;">
  <div style="max-width: 1200px; margin: auto;">
    <div style="display: flex; flex-wrap: wrap; justify-content: space-between; margin-bottom: 20px;">

      <!-- About Section -->
      <div style="flex: 1; min-width: 250px; margin: 10px;">
        <h4 style="color: #007bff; margin-bottom: 10px;">Blood Donation</h4>
        <p>
          Blood Donation is situated at Attarkhel of Jorpati-8, Gokarneshwar Municipality,
          in Kathmandu, about 11 km northeast of Kathmandu Valley.
        </p>
      </div>

      <!-- Quick Links Section -->
      <div style="flex: 1; min-width: 250px; margin: 10px;">
        <h4 style="color: #007bff; margin-bottom: 10px;">Quick Links</h4>
        <ul style="list-style: none; padding: 0; line-height: 1.8;">
          <li><a href="#" style="color: #ddd; text-decoration: none;">Appointment</a></li>
          <li><a href="#" style="color: #ddd; text-decoration: none;">Department</a></li>
          <li><a href="#" style="color: #ddd; text-decoration: none;">About Us</a></li>
          <li><a href="#" style="color: #ddd; text-decoration: none;">Notice</a></li>
          <li><a href="#" style="color: #ddd; text-decoration: none;">Research</a></li>
          <li><a href="#" style="color: #ddd; text-decoration: none;">Contact Us</a></li>
        </ul>
      </div>

      <!-- Contact Section -->
      <div style="flex: 1; min-width: 250px; margin: 10px;">
        <h4 style="color: #007bff; margin-bottom: 10px;">Contact Us</h4>
        <p style="margin: 5px 0;">+977-01-4911008</p>
        <p style="margin: 5px 0;">BD.edu</p>
        <p style="margin: 5px 0;">Attarkhel, Jorpati-8, Gokarneshwor Municipality, Kathmandu, Nepal</p>
      </div>
    </div>

    <!-- Newsletter and Social Media Section -->
    <div style="margin-top: 20px;">
      <h4 style="color: #007bff; margin-bottom: 10px;">Newsletter</h4>
      <p>© 2023 Blood Donation. All Rights Reserved.</p>
      <div style="margin-top: 10px;">
        <a href="https://www.facebook.com" target="_blank" style="margin: 0 5px; color: #ddd; text-decoration: none;">
          <img src="facebook-icon.png" alt="Facebook" style="width: 20px;">
        </a>
        <a href="https://www.twitter.com" target="_blank" style="margin: 0 5px; color: #ddd; text-decoration: none;">
          <img src="twitter-icon.png" alt="Twitter" style="width: 20px;">
        </a>
        <a href="https://www.instagram.com" target="_blank" style="margin: 0 5px; color: #ddd; text-decoration: none;">
          <img src="instagram-icon.png" alt="Instagram" style="width: 20px;">
        </a>
        <a href="https://www.linkedin.com" target="_blank" style="margin: 0 5px; color: #ddd; text-decoration: none;">
          <img src="linkedin-icon.png" alt="LinkedIn" style="width: 20px;">
        </a>
      </div>
    </div>
  </div>
</footer>