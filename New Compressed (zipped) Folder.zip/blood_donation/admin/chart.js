const labels = categoryData.map(item => item.category);
    const data = categoryData.map(item => item.total);
    
    const expenseCategoriesCtx = document
      .getElementById('expenseCategories')
      .getContext('2d');
    
    new Chart(expenseCategoriesCtx, {
      type: 'doughnut',
      data: {
        labels: labels,
        datasets: [
          {
            data: data,
            backgroundColor: ['#2563eb', '#16a34a', '#eab308', '#dc2626', '#8b5cf6'],
          },
        ],
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom',
          },
        },
      },
    });