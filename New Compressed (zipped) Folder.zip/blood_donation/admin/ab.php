<?php
// Include database connection
include('db.php');

// Fetch data from the database
$query = "SELECT date, stock FROM blood_stock WHERE blood_type = 'A+' ORDER BY date";
$result = $conn->query($query);

$dates = [];
$stocks = [];

while ($row = $result->fetch_assoc()) {
  $dates[] = $row['date'];
  $stocks[] = $row['stock'];
}


$datesJson = json_encode($dates);
$stocksJson = json_encode($stocks);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Line Graph with PHP and Chart.js</title>
</head>

<body>
  <div style="width: 80%; margin: auto;">
    <canvas id="lineChart"></canvas>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>

  <canvas id="expenseCategories"></canvas>

<script>

    // Expense Categories Pie Chart
    const labels = categoryData.map(item => item.category);
    const data = categoryData.map(item => item.total);
    
    const expenseCategoriesCtx = document
      .getElementById('expenseCategories')
      .getContext('2d');
    
    new Chart(expenseCategoriesCtx, {
      type: 'doughnut',
      data: {
        labels: labels,
        datasets: [
          {
            data: data,
            backgroundColor: ['#2563eb', '#16a34a', '#eab308', '#dc2626', '#8b5cf6'],
          },
        ],
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom',
          },
        },
      },
    });

  </script>