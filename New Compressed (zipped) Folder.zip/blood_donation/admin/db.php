<?php
// Database configuration
$host = 'localhost'; // or your database host
$username = 'root';  // your database username
$password = '';      // your database password
$dbname = 'blood_donation'; // your database name

// Create a connection to the MySQL database using mysqli
$conn = new mysqli($host, $username, $password, $dbname);

// Check if the connection is successful
if ($conn->connect_error) {
  // If there is a connection error, stop and show the error
  die("Connection failed: " . $conn->connect_error);
}

// You can now use $conn to interact with the database in your PHP files
