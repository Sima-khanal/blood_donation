<?php
require 'db.php'; // Database connection file

// Handle status updates
if (isset($_POST['update_status'])) {
    $donation_id = $_POST['donation_id'];
    $new_status = $_POST['new_status'];

    $update_sql = "UPDATE donation SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("si", $new_status, $donation_id);

    if ($stmt->execute()) {
        // Increase stock when donated
        if ($new_status == "Donated") {
            $blood_type_query = "SELECT blood_type FROM donation WHERE id = ?";
            $stmt_blood = $conn->prepare($blood_type_query);
            $stmt_blood->bind_param("i", $donation_id);
            $stmt_blood->execute();
            $result_blood = $stmt_blood->get_result();
            $blood_row = $result_blood->fetch_assoc();
            $blood_type = $blood_row['blood_type'];

            // Update blood stock
            $stock_update_sql = "UPDATE blood_stock SET stock = stock + 1 WHERE blood_type = ?";
            $stmt_stock = $conn->prepare($stock_update_sql);
            $stmt_stock->bind_param("s", $blood_type);
            $stmt_stock->execute();
        }

        echo "<script>alert('Status updated successfully!'); window.location.href='donor_request.php';</script>";
    } else {
        echo "<script>alert('Failed to update status');</script>";
    }
}

// Fetch donation requests
$sql = "SELECT * FROM donation ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donation Requests</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f0f0f0;
        }

        /* Glass Effect Navbar */
        .glass-navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            background: rgba(255, 255, 255, 0.2);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .navbar-left h1 {
            font-size: 24px;
            color: #ff4d4d;
        }

        .navbar-right ul {
            list-style: none;
            display: flex;
            gap: 20px;
        }

        .navbar-right ul li {
            display: inline;
        }

        .navbar-right ul li a {
            text-decoration: none;
            color: #333;
            font-weight: bold;
            padding: 8px 15px;
            border-radius: 20px;
            transition: 0.3s;
        }

        .navbar-right ul li a:hover {
            background: rgba(255, 77, 77, 0.2);
            color: #ff4d4d;
        }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: center; }
        th { background-color: #f4f4f4; }
        .pending { color: orange; }
        .approved { color: green; }
        .cancelled { color: red; }
        .donated { color: blue; }
        button { padding: 5px 10px; cursor: pointer; }
    </style>
</head>
<body>

    <nav class="glass-navbar">
        <div class="navbar-left">
            <h1>Blood Donation System</h1>
        </div>
        <div class="navbar-right">
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage_stock.php">Manage Stock</a></li>
                <li><a href="manage_requests.php">Manage Requests</a></li>
                <li><a href="donor_request.php">Donor Request</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>
<div class="container">
    <h2>Manage Donation Requests</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Birthdate</th>
            <th>Last Donated</th>
            <th>Donation Date</th>
            <th>Blood Type</th>
            <th>Weight (kg)</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id']; ?></td>
                <td><?= $row['birthdate']; ?></td>
                <td><?= $row['last_donated_date']; ?></td>
                <td><?= $row['donation_date']; ?></td>
                <td><?= $row['blood_type']; ?></td>
                <td><?= $row['weight_kg']; ?></td>
                <td class="<?= strtolower($row['status']); ?>"><?= $row['status']; ?></td>
                <td>
                    <?php if ($row['status'] == 'Pending'): ?>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="donation_id" value="<?= $row['id']; ?>">
                            <input type="hidden" name="new_status" value="Approved">
                            <button type="submit" name="update_status" style="background-color: green; color: white;">Approve</button>
                        </form>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="donation_id" value="<?= $row['id']; ?>">
                            <input type="hidden" name="new_status" value="Cancelled">
                            <button type="submit" name="update_status" style="background-color: red; color: white;">Cancel</button>
                        </form>

                    <?php elseif ($row['status'] == 'Approved'): ?>
                        <form method="POST">
                            <input type="hidden" name="donation_id" value="<?= $row['id']; ?>">
                            <input type="hidden" name="new_status" value="Donated">
                            <button type="submit" name="update_status" style="background-color: blue; color: white;">Donate</button>
                        </form>

                    <?php else: ?>
                        <span style="color: grey;">N/A</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</div>
    <?php include('footer.php'); ?>
</body>
</html>
