<?php
// Include database connection
include('db.php');

// Handle donation status update
if (isset($_POST['update_status'])) {
    $donation_id = $_POST['donation_id'];
    $new_status = $_POST['status'];

    // Update the donation status in the database
    $sql = "UPDATE donation SET status = '$new_status' WHERE id = $donation_id";
    if ($conn->query($sql) === TRUE) {
        // If the status is "Donated", increase the blood stock
        if ($new_status == 'donated') {
            // Assuming you have a blood_stock table or column to track blood stock
            $update_stock_sql = "UPDATE blood_stock SET stock = stock + 1 WHERE blood_type = (SELECT blood_type FROM donation WHERE id = $donation_id)";
            $conn->query($update_stock_sql);
        }
        echo "<script>alert('Donation status updated successfully.');</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Handle donation request deletion
if (isset($_POST['delete_donation'])) {
    $donation_id = $_POST['donation_id'];

    // Delete the donation request from the database
    $delete_sql = "DELETE FROM donation WHERE id = $donation_id";
    if ($conn->query($delete_sql) === TRUE) {
        echo "<script>alert('Donation request deleted successfully.');</script>";
    } else {
        echo "Error: " . $delete_sql . "<br>" . $conn->error;
    }
}

// Retrieve all donations
$sql = "SELECT * FROM donation";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Donations</title>
    <style>
        table {
            width: 100%;
            margin: 20px 0;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f4f4f9;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            border-radius: 4px;
        }

        button:hover {
            background-color: #45a049;
        }

        .delete-btn {
            background-color: #f44336;
        }

        .delete-btn:hover {
            background-color: #e53935;
        }
    </style>
</head>
<body>
    <h2>Admin - Manage Blood Donation Requests</h2>

    <table>
        <thead>
            <tr>
                <th>Donation ID</th>
                <th>Donor Info</th>
                <th>Donation Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Display donation records
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td>" . $row['birthdate'] . " - " . $row['blood_type'] . "</td>";
                    echo "<td>" . $row['donation_date'] . "</td>";
                    echo "<td>" . ucfirst($row['status']) . "</td>";
                    echo "<td>
                            <form method='POST' action=''>
                                <input type='hidden' name='donation_id' value='" . $row['id'] . "'>
                                <select name='status' required>
                                    <option value='pending' " . ($row['status'] == 'pending' ? 'selected' : '') . ">Pending</option>
                                    <option value='accepted' " . ($row['status'] == 'accepted' ? 'selected' : '') . ">Accepted</option>
                                    <option value='donated' " . ($row['status'] == 'donated' ? 'selected' : '') . ">Donated</option>
                                </select>
                                <button type='submit' name='update_status'>Update Status</button>
                            </form>";

                    // Only allow deletion for requests in "pending" status
                    if ($row['status'] == 'pending') {
                        echo "<form method='POST' action='' style='display:inline;'>
                                <input type='hidden' name='donation_id' value='" . $row['id'] . "'>
                                <button type='submit' name='delete_donation' class='delete-btn'>Delete</button>
                            </form>";
                    }

                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No donation records found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>
