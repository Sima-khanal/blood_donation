<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="Stylesheet" href="css/styles.css">
</head>

<body>
  <header>
    <div class="container">
      <!-- Logo Section -->
      <div class="logo">
        <img src="https://i.pinimg.com/474x/3f/66/64/3f66647bf0b133d872d22f016aedaf56.jpg" alt="Hospital Logo">
      </div>
      <nav>
        <ul>
          <li><a href="login.php">Login</a></li>
        </ul>
      </nav>
  </header>
  <!-- Main Content Section -->
  <section id="main-banner">
    <div class="banner-content">
      <h1>Welcome to Blood Donation Admin Page</h1>
      <p>Your Health, Our Priority</p>
    </div>
  </section>

  <!-- About NMC Section -->
  <section id="about">
    <div class="section-container">
      <h2>About Blood Donation</h2>
      <p>
        Blood donation is a well-established medical institution located in Kathmandu. It aims to provide high-quality health services, and research for the betterment of society.
      </p>
    </div>
  </section>


  <!-- Services Section -->
  <section id="services">
    <div class="section-container">
      <h2>Our Services</h2>
      <div class="service-list">
        <div class="service">
          <h3>Emergency Care</h3>
          <p>24/7 emergency blood services for critical conditions.</p>
        </div>
        <div class="service">
          <h3>Blood Donation</h3>
          <p>Donate blood and save lives. Join our blood donation program.</p>
        </div>
        <div class="service">
          <h3>Health Checkups</h3>
          <p>Regular health checkups to monitor and maintain well-being.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Media Section -->
  <section id="media">
    <div class="section-container">
      <h2>Latest Media</h2>
      <div class="media-gallery">
        <div class="media-item">
          <img src="https://i.pinimg.com/474x/be/aa/7d/beaa7db3f7886160fa06de5286a5647a.jpg" alt=" Hospital">
          <p>Healthcare innovation </p>
        </div>
        <div class="media-item">
          <img src="https://i.pinimg.com/474x/70/e1/8c/70e18c4027a001787afb0c82a5bb91c3.jpg" alt=" Hospital">
          <p>Providing quality medical care</p>
        </div>
        <div class="media-item">
          <img src="https://i.pinimg.com/474x/c2/8c/66/c28c668d7f4ce8bd9597219e9f19d1ec.jpg" alt=" Hospital">
          <p>Modern medical facilities</p>
        </div>
      </div>
    </div>
  </section>
  <script src="script.js"></script>

  <footer>
    <p>© 2023 BD. Admin Panel. All Rights Reserved.</p>
  </footer>
  <style>
    header {
      background-color: #2c3e50;
      /* Green background */
      padding: 10px 20px;
      /* Space inside the header */
      display: flex;
      align-items: center;
      justify-content: space-between;
      /* Space between logo and navigation */
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      /* Subtle shadow for depth */
    }

    header .container {
      display: flex;
      align-items: center;
      justify-content: space-between;
      width: 100%;
      max-width: 1200px;
      margin: 0 auto;
      /* Center the header content */
    }

    header .logo img {
      height: 50px;
      /* Adjust the logo size */
      width: auto;
      /* Maintain aspect ratio */
      border-radius: 8px;
      /* Rounded corners for the logo */
    }

    header nav ul {
      list-style: none;
      /* Remove default list styles */
      margin: 0;
      padding: 0;
      display: flex;
      /* Horizontal alignment for navigation links */
      align-items: center;
    }

    header nav ul li {
      margin-left: 20px;
      /* Spacing between navigation items */
    }

    header nav ul li a {
      text-decoration: none;
      /* Remove underline from links */
      color: white;
      /* White text for links */
      font-size: 16px;
      /* Adjust font size */
      font-weight: bold;
      padding: 8px 16px;
      /* Add padding to the link */
      border-radius: 4px;
      /* Rounded corners for links */
      transition: background-color 0.3s ease;
      /* Smooth hover effect */
    }

    header nav ul li a:hover {
      background-color: rgb(223, 101, 71);
      /* Slightly darker green on hover */
    }

    /* Main Banner Section */
    #main-banner {
      background: url('https://i.pinimg.com/474x/d3/31/c0/d331c0eb0af5fd0c7898dfd06f0d1ed3.jpg') no-repeat center center/cover;
      color: white;
      text-align: center;
      padding: 100px 20px;
    }

    #main-banner .banner-content {
      max-width: 600px;
      margin: 0 auto;
      background-color: rgba(0, 0, 0, 0.6);
      padding: 20px;
      border-radius: 8px;
    }

    #main-banner h1 {
      font-size: 40px;
      margin-bottom: 10px;
    }

    #main-banner p {
      font-size: 18px;
    }

    /* About Section */
    #about {
      background-color: #fff;
      padding: 50px 20px;
      text-align: center;
    }

    #about h2 {
      font-size: 32px;
      margin-bottom: 15px;
      color: #d9534f;
    }

    #about p {
      font-size: 16px;
      max-width: 800px;
      margin: 0 auto;
      line-height: 1.8;
    }

    /* Services Section */
    #services {
      background-color: #f5f5f5;
      padding: 50px 20px;
      text-align: center;
    }

    #services h2 {
      font-size: 32px;
      margin-bottom: 15px;
      color: #d9534f;
    }

    .service-list {
      display: flex;
      justify-content: center;
      gap: 20px;
      flex-wrap: wrap;
    }

    .service {
      background-color: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      max-width: 250px;
    }

    .service h3 {
      font-size: 18px;
      color: #d9534f;
    }

    .service p {
      font-size: 14px;
      color: #555;
    }

    /* Media Section */
    #media {
      background-color: #fff;
      padding: 50px 20px;
      text-align: center;
    }

    #media h2 {
      font-size: 32px;
      margin-bottom: 15px;
      color: #d9534f;
    }

    .media-gallery {
      display: flex;
      justify-content: center;
      gap: 20px;
      flex-wrap: wrap;
    }

    .media-item {
      max-width: 250px;
      text-align: center;
    }

    .media-item img {
      width: 100%;
      height: auto;
      border-radius: 8px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .media-item p {
      margin-top: 10px;
      font-size: 14px;
      color: #555;
    }


    /* Responsive Design */
    @media (max-width: 768px) {
      #main-banner {
        padding: 60px 20px;
      }

      .service-list,
      .media-gallery {
        flex-direction: column;
        align-items: center;
      }
    }

    footer {
      background-color: #2c3e50;
      color: white;
      text-align: center;
      padding: 15px;
      position: fixed;
      width: 100%;
      bottom: 0;
    }
  </style>

</body>

</html>