<?php
// Include database connection
include('db.php');

// Check if the 'id' parameter is provided
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch blood request details
    $stmt = $conn->prepare("SELECT blood_type, quantity FROM blood_requests WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $blood_type = $row['blood_type'];
        $units_to_dispatch = $row['quantity'];

        // Fetch current stock for the blood type
        $stock_stmt = $conn->prepare("SELECT stock FROM blood_stock WHERE blood_type = ?");
        $stock_stmt->bind_param("s", $blood_type);
        $stock_stmt->execute();
        $stock_result = $stock_stmt->get_result();

        if ($stock_result->num_rows > 0) {
            $stock_row = $stock_result->fetch_assoc();
            $current_stock = $stock_row['stock'];

            if ($current_stock >= $units_to_dispatch) {
                $new_stock = $current_stock - $units_to_dispatch;

                // Update stock
                $update_stock_stmt = $conn->prepare("UPDATE blood_stock SET stock = ? WHERE blood_type = ?");
                $update_stock_stmt->bind_param("is", $new_stock, $blood_type);
                $update_stock_stmt->execute();

                // Mark the request as dispatched
                $update_request_stmt = $conn->prepare("UPDATE blood_requests SET status = ? WHERE id = ?");
                $status = 'Dispatched'; // Ensure correct value
                $update_request_stmt->bind_param("si", $status, $id);
                $update_request_stmt->execute();

                header("Location: manage_requests.php?message=Blood dispatched successfully.");
                exit();
            } else {
                echo "Insufficient stock to dispatch the request.";
            }
        } else {
            echo "Stock record not found for the specified blood type.";
        }
    } else {
        echo "Invalid request ID.";
    }
} else {
    echo "Request ID not provided.";
}

$conn->close();
?>
