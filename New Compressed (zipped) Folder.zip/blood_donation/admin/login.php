<?php
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $admin_id = $_POST['admin_id'];
    $password = $_POST['password'];

    // Static credentials for admin
    $valid_admin_id = "admin123";
    $valid_password = "password123";

    // Validate credentials
    if ($admin_id === $valid_admin_id && $password === $valid_password) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_id'] = $admin_id;
        header("Location: dashboard.php"); // Redirect to dashboard
        exit();
    } else {
        $error_message = "Invalid Admin ID or Password!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        #login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .login-box {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
        }
        .login-box h2 {
            margin-bottom: 20px;
            color: #333;
        }
        .login-box label {
            display: block;
            margin: 10px 0 5px;
            text-align: left;
        }
        .login-box input {
            width: 100%;
            padding: 10px;
            margin: 5px 0 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .login-box button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .login-box button:hover {
            background-color: #45a049;
        }
        .error-message {
            color: red;
            font-size: 14px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div id="login-container">
        <div class="login-box">
            <h2>Admin Login</h2>
            <?php if (isset($error_message)) { ?>
                <p class="error-message"><?= $error_message; ?></p>
            <?php } ?>
            <form action="login.php" method="POST">
                <label for="admin_id">Admin ID</label>
                <input type="text" id="admin_id" name="admin_id" required placeholder="Enter Admin ID">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required placeholder="Enter Password">
                <button type="submit">Login</button>
            </form>
        </div>
    </div>
</body>
</html>
