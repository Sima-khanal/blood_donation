<?php
// Include database connection
include('db.php');

// Check if request ID is provided
if (isset($_GET['id'])) {
  $request_id = $_GET['id'];

  // Delete the request from the database
  $sql = "DELETE FROM blood_requests WHERE id = '$request_id'";

  if (mysqli_query($conn, $sql)) {
    // Redirect to the same page to see changes
    header("Location: manage_requests.php?message=Request successfully deleted.");
    exit();
  } else {
    // Show an error message if the query fails
    echo "Error: Could not delete the request.";
  }
} else {
  echo "Invalid request ID.";
}

$conn->close();
