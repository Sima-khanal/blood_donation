<?php
// Start the session

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="Stylesheet" href="styles.css">
</head>

<body>
  <header>
    <div class="container">
      <!-- Logo Section -->
      <div class="logo">
        <img src="https://i.pinimg.com/474x/3f/66/64/3f66647bf0b133d872d22f016aedaf56.jpg" alt="Hospital Logo">
      </div>

      <nav>
        <ul>
          <li><a href="dashboard.php">Dashboard</a></li>
          <li><a href="manage_stock.php">Manage Stock</a></li>
          <li><a href="manage_requests.php">Manage Requests</a></li>
          <li><a href="logout.php">Logout</a></li>
        </ul>
      </nav>
  </header>

</body>

</html>