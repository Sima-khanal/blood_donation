<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
  header("Location: login.php");
  exit();
}

// Include database connection file
include('db.php');

// Fetch blood stock data from the database
$query = "SELECT * FROM blood_stock ORDER BY blood_type ASC";
$result = $conn->query($query);
$bloodStocks = [];
if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $bloodStocks[] = $row;
  }
}

// Add Blood Stock (Create)
if (isset($_POST['add'])) {
  $blood_type = $_POST['blood_type'];
  $stock = $_POST['stock'];

  // Insert blood stock into the database
  $stmt = $conn->prepare("INSERT INTO blood_stock (blood_type, stock) VALUES (?, ?)");
  $stmt->bind_param("si", $blood_type, $stock); // 'si' -> string, integer
  if ($stmt->execute()) {
    header("Location: dashboard.php"); // Redirect back to index page after successful insertion
    exit();
  } else {
    echo "Error: " . $stmt->error;
  }
}

// Update Blood Stock (Update)
if (isset($_POST['update'])) {
  $id = $_POST['id'];
  $stock = $_POST['stock'];

  // Update the blood stock in the database
  $stmt = $conn->prepare("UPDATE blood_stock SET stock = ? WHERE id = ?");
  $stmt->bind_param("ii", $stock, $id); // 'ii' -> integer, integer
  if ($stmt->execute()) {
    header("Location: index.php"); // Redirect back to index page after successful update
    exit();
  } else {
    echo "Error: " . $stmt->error;
  }
}

// Delete Blood Stock (Delete)
if (isset($_GET['delete_id'])) {
  $id = $_GET['delete_id'];

  // Delete the blood stock from the database
  $stmt = $conn->prepare("DELETE FROM blood_stock WHERE id = ?");
  $stmt->bind_param("i", $id); // 'i' -> integer
  if ($stmt->execute()) {
    header("Location: dashboard.php"); // Redirect back to index page after successful deletion
    exit();
  } else {
    echo "Error: " . $stmt->error;
  }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard - Blood Donation</title>
  <link rel="stylesheet" href="styles.css">
</head>

<body>
  <?php include('header.php'); ?>
  <style>
    .main-content-header {
      position: relative;
      padding: 50px 20px;

      background-size: cover;
      color: #333;
      /* Ensures the image covers the entire area */
      background-position: center;
      /* Ensures text is visible on top of the image */
      text-align: center;
      border-radius: 10px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .main-content-header .admin-info h2 {
      font-size: 36px;
      margin: 0;
    }

    .main-content-header .admin-info p {
      font-size: 18px;
      margin-top: 10px;
    }

    .dashboard-overview {
      display: flex;
      gap: 20px;
      flex-wrap: wrap;
      justify-content: center;
      margin-top: 20px;
    }

    .overview-item {
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      padding: 20px;
      width: 250px;
      text-align: center;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      text-decoration: none;
      /* Removes underline from links */
      color: inherit;
      /* Inherits the color of the text */
    }

    .overview-item h3 {
      font-size: 20px;
      color: #333;
      margin-bottom: 10px;
    }

    .overview-item p {
      font-size: 24px;
      font-weight: bold;
      color: #007bff;
    }

    .overview-item:hover {
      transform: translateY(-10px);
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
    }

    /* Optional: Add a hover effect to the <a> tag itself for better visual feedback */
    a.overview-item:hover {
      cursor: pointer;
      /* Change the cursor to a pointer to indicate it's clickable */
    }

    .btn-appointments {
      display: inline-block;
      padding: 10px 15px;
      background-color: #4CAF50;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
      text-align: center;
    }

    .btn-appointments:hover {
      background-color: #45a049;
    }
  </style>

  <section id="admin-dashboard">
    <div class="dashboard-container">


      <!-- Main Content Area -->
      <main id="main-content">

        <div class="main-content-header">
          <div class="admin-info">
            <h2>Welcome, Admin!</h2>
            <p>Manage the blood donation system with ease.</p>
          </div>
        </div>

        <!-- Dashboard Overview -->
        <div class="dashboard-overview">
          <a href="manage_stock.php" class="overview-item">
            <h3>Total Stocks</h3>
            <p><?php echo count($bloodStocks); ?></p>
          </a>
          <div class="overview-item">
            <h3>Appointments Today</h3>
            <p><a href="manage_requests.php" class="btn-appointments">15</a></p>
          </div>

        </div>

  </section>
  <script src="script.js"></script>
  <?php include('footer.php'); ?>
</body>

</html>