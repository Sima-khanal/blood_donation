<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit();
}

// Include database connection file
include('db.php');

// Ensure $conn is initialized
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Initialize variables
$bloodStocks = [];
$bloodTypes = [];
$stockValues = [];

// Fetch blood stock data from the database
$query = "SELECT * FROM blood_stock ORDER BY blood_type ASC";
$result = $conn->query($query);
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $bloodStocks[] = $row;
        $bloodTypes[] = $row['blood_type'];
        $stockValues[] = (int)$row['stock'];
    }
}

// Add Blood Stock (Create)
if (isset($_POST['add'])) {
    $blood_type = trim(htmlspecialchars($_POST['blood_type']));
    $stock = intval($_POST['stock']); // Ensure stock is an integer

    if (!empty($blood_type) && $stock >= 0) {
        $stmt = $conn->prepare("INSERT INTO blood_stock (blood_type, stock) VALUES (?, ?)");
        if ($stmt) {
            $stmt->bind_param("si", $blood_type, $stock);
            if ($stmt->execute()) {
                header("Location: dashboard.php");
                exit();
            } else {
                echo "Error: " . $stmt->error;
            }
            $stmt->close();
        }
    } else {
        echo "Invalid input.";
    }
}

// Update Blood Stock (Update)
if (isset($_POST['update'])) {
    $id = intval($_POST['id']);
    $stock = intval($_POST['stock']);

    if ($stock >= 0) {
        $stmt = $conn->prepare("UPDATE blood_stock SET stock = ? WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("ii", $stock, $id);
            if ($stmt->execute()) {
                header("Location: dashboard.php");
                exit();
            } else {
                echo "Error: " . $stmt->error;
            }
            $stmt->close();
        }
    } else {
        echo "Invalid stock value.";
    }
}

// Close database connection
$conn->close();
?>

<style>
    * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background: #f0f0f0;
}

/* Glass Effect Navbar */
.glass-navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 30px;
    background: rgba(255, 255, 255, 0.2);
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(10px);
    position: sticky;
    top: 0;
    z-index: 1000;
}

.navbar-left h1 {
    font-size: 24px;
    color: #ff4d4d;
}

.navbar-right ul {
    list-style: none;
    display: flex;
    gap: 20px;
}

.navbar-right ul li {
    display: inline;
}

.navbar-right ul li a {
    text-decoration: none;
    color: #333;
    font-weight: bold;
    padding: 8px 15px;
    border-radius: 20px;
    transition: 0.3s;
}

.navbar-right ul li a:hover {
    background: rgba(255, 77, 77, 0.2);
    color: #ff4d4d;
}
</style>

    <nav class="glass-navbar">
        <div class="navbar-left">
            <h1>Blood Donation System</h1>
        </div>
        <div class="navbar-right">
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage_stock.php">Manage Stock</a></li>
                <li><a href="manage_requests.php">Manage request</a></li>
                <li><a href="donor_request.php"> Donor Request</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

<style>
.dashboard-chart {
  width: 90%;
  max-width: 800px;
  margin: 50px auto;
  background: rgba(255, 255, 255, 0.7);
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
}

.dashboard-chart h2 {
  text-align: center;
  margin-bottom: 20px;
  color: #333;
}

canvas {
  display: block;
  margin: 0 auto;
}
</style>

<section id="admin-dashboard">
  <div class="dashboard-container">
    <main id="main-content">
      <div class="main-content-header">
        <div class="admin-info">
         <!--  <h2>Welcome, Admin!</h2>
        <p>Manage the blood donation system with ease.</p>
    -->      </div>
      </div>
 
      <div class="dashboard-chart">
        <!-- <h2>Blood Stock Bar Chart</h2> -->
        <canvas id="blood-stock-bar-chart" width="400" height="200"></canvas>
      </div>

      <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

      <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  // PHP-generated blood stock data
  const bloodTypes = <?php echo json_encode($bloodTypes); ?>;
  const stockValues = <?php echo json_encode($stockValues); ?>;

  // Create the bar chart
  const ctx = document.getElementById('blood-stock-bar-chart').getContext('2d');
  new Chart(ctx, {
      type: 'bar',
      data: {
          labels: bloodTypes,
          datasets: [{
              label: 'Blood Stock by Type',
              data: stockValues,
              backgroundColor: [
                  'rgba(255, 99, 132, 0.2)',
                  'rgba(54, 162, 235, 0.2)',
                  'rgba(255, 206, 86, 0.2)',
                  'rgba(75, 192, 192, 0.2)',
                  'rgba(153, 102, 255, 0.2)',
                  'rgba(255, 159, 64, 0.2)',
                  'rgba(0, 128, 128, 0.2)',
                  'rgba(128, 0, 128, 0.2)'
              ],
              borderColor: [
                  'rgba(205, 99, 132, 1)',
                  'rgba(54, 162, 235, 1)',
                  'rgba(255, 206, 86, 1)',
                  'rgba(75, 192, 192, 1)',
                  'rgba(153, 102, 255, 1)',
                  'rgba(235, 159, 64, 1)',
                  'rgba(0, 128, 138, 1)',
                  'rgba(128, 0, 128, 1)'
              ],
              borderWidth: 1,
          }]
      },
      options: {
          responsive: true,
          plugins: {
              legend: {
                  display: true,
                  position: 'top',
              },
          },
          scales: {
              x: {
                  title: {
                      display: true,
                      text: 'Blood Types',
                  },
              },
              y: {
                  title: {
                      display: true,
                      text: 'Stock Quantity',
                  },
                  beginAtZero: true,
              },
          },
      },
  });
</script>

<?php include('footer.php'); ?>
