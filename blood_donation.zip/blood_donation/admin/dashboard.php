<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit();
}

// Include database connection file
include('db.php');

// Ensure $conn is initialized
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Initialize variables
$bloodStocks = [];
$bloodTypes = [];
$stockValues = [];

// Fetch blood stock data from the database
$query = "SELECT * FROM blood_stock ORDER BY blood_type ASC";
$result = $conn->query($query);
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $bloodStocks[] = $row;
        $bloodTypes[] = $row['blood_type'];
        $stockValues[] = (int)$row['stock'];
    }
}

// Close database connection
$conn->close();
?>

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: Arial, sans-serif;
        background: #f0f0f0;
        color: #333;
    }

    /* Glass Effect Navbar */
    .glass-navbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px 30px;
        background: rgba(255, 255, 255, 0.2);
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        backdrop-filter: blur(10px);
        position: sticky;
        top: 0;
        z-index: 1000;
    }

    .navbar-left h1 {
        font-size: 24px;
        color: #ff4d4d;
    }

    .navbar-right ul {
        list-style: none;
        display: flex;
        gap: 20px;
    }

    .navbar-right ul li {
        display: inline;
    }

    .navbar-right ul li a {
        text-decoration: none;
        color: #333;
        font-weight: bold;
        padding: 8px 15px;
        border-radius: 20px;
        transition: 0.3s;
    }

    .navbar-right ul li a:hover {
        background: rgba(255, 77, 77, 0.2);
        color: #ff4d4d;
    }

    .dashboard-chart {
        width: 90%;
        max-width: 800px;
        margin: 50px auto;
        background: rgba(255, 255, 255, 0.9);
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
    }

    .dashboard-chart h2 {
        text-align: center;
        margin-bottom: 20px;
        color: #222;
    }

    p {
        color: #444;
        font-size: 16px;
    }
</style>

<nav class="glass-navbar">
    <div class="navbar-left">
        <h1>Blood Donation System</h1>
    </div>
    <div class="navbar-right">
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="manage_stock.php">Manage Stock</a></li>
            <li><a href="manage_requests.php">Manage Requests</a></li>
            <li><a href="donor_request.php">Donor Request</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>
</nav>

<section id="admin-dashboard">
    <div class="dashboard-container">
        <main id="main-content">
            <div class="dashboard-chart">
                <canvas id="blood-stock-bar-chart" width="400" height="200"></canvas>
            </div>
        </main>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const bloodTypes = <?php echo json_encode($bloodTypes); ?>;
    const stockValues = <?php echo json_encode($stockValues); ?>;
    const colors = [
        'rgba(255, 99, 132, 0.5)',
        'rgba(54, 162, 235, 0.5)',
        'rgba(255, 206, 86, 0.5)',
        'rgba(75, 192, 192, 0.5)',
        'rgba(153, 102, 255, 0.5)',
        'rgba(255, 159, 64, 0.5)',
        'rgba(0, 128, 128, 0.5)',
        'rgba(128, 0, 128, 0.5)'
    ];
    
    const ctx = document.getElementById('blood-stock-bar-chart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: bloodTypes,
            datasets: [{
                label: 'Blood Stock by Type',
                data: stockValues,
                backgroundColor: colors,
                borderColor: colors.map(color => color.replace('0.5', '1')),
                borderWidth: 1,
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                },
            },
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Blood Types',
                    },
                },
                y: {
                    title: {
                        display: true,
                        text: 'Stock Quantity',
                    },
                    beginAtZero: true,
                },
            },
        },
    });
</script>

<?php include('footer.php'); ?>