<?php
// db.php - MySQLi connection setup
include('db.php');
// Add Blood Stock (Create)
if (isset($_POST['add'])) {
  $blood_type = $_POST['blood_type'];
  $stock = $_POST['stock'];

  // Insert blood stock into the database
  $query = "INSERT INTO blood_stock (blood_type, stock) VALUES (?, ?)";
  $stmt = $conn->prepare($query);
  $stmt->bind_param("si", $blood_type, $stock); // 'si' -> string, integer
  if ($stmt->execute()) {
    header("Location: manage_stock.php"); // Redirect back to index page after successful insertion
    exit();
  } else {
    echo "Error: " . $stmt->error;
  }
}

// Update Blood Stock (Update)
if (isset($_POST['update'])) {
  $id = $_POST['id'];
  $stock = $_POST['stock'];

  // Update the blood stock in the database
  $query = "UPDATE blood_stock SET stock = ? WHERE id = ?";
  $stmt = $conn->prepare($query);
  $stmt->bind_param("ii", $stock, $id); // 'ii' -> integer, integer
  if ($stmt->execute()) {
    header("Location: manage_stock.php"); // Redirect back to index page after successful update
    exit();
  } else {
    echo "Error: " . $stmt->error;
  }
}

// // Delete Blood Stock (Delete)
// if (isset($_GET['delete_id'])) {
//   $id = $_GET['delete_id'];

//   // Delete the blood stock from the database
//   $query = "DELETE FROM blood_stock WHERE id = ?";
//   $stmt = $conn->prepare($query);
//   $stmt->bind_param("i", $id); // 'i' -> integer
//   if ($stmt->execute()) {
//     header("Location: manage_stock.php"); // Redirect back to index page after successful deletion
//     exit();
//   } else {
//     echo "Error: " . $stmt->error;
//   }
// }

// Close the connection
$conn->close();
