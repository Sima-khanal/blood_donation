<?php
// Include the header file
include('header.php');

// Include database connection file
include('db.php');

$sql = "SELECT id, user_id, blood_type, contact_number, unit, status, created_at FROM blood_requests"; // Ensure 'unit' is part of the query
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Blood Stock Search</title>
</head>

<body>
  <div class="container">
    <h1>Search Blood Stock</h1>

    <!-- Search Bar -->
    <div class="search-container">
      <form id="searchForm">
        <label for="bloodTypeFilter">Blood Type:</label>
        <select name="blood_type" id="bloodTypeFilter">
          <option value="">All Blood Types</option>
          <option value="A+">A+</option>
          <option value="A-">A-</option>
          <option value="B+">B+</option>
          <option value="B-">B-</option>
          <option value="AB+">AB+</option>
          <option value="AB-">AB-</option>
          <option value="O+">O+</option>
          <option value="O-">O-</option>
        </select>

        <label for="minStockFilter">Minimum Stock:</label>
        <input type="number" id="minStockFilter" name="min_stock" placeholder="Enter minimum stock" min="0">

        <button type="button" id="searchButton">Search</button>
      </form>
    </div>
  </div>

  <script>
    document.getElementById('searchButton').addEventListener('click', function() {
      const bloodType = document.getElementById('bloodTypeFilter').value;
      const minStock = document.getElementById('minStockFilter').value;

      // AJAX Request
      const xhr = new XMLHttpRequest();
      xhr.open('GET', `search.php?blood_type=${bloodType}&min_stock=${minStock}`, true);
      xhr.onload = function() {
        if (this.status === 200) {
          const response = JSON.parse(this.responseText);

          if (response.message) {
            alert(response.message); // Display the no results message
          } else {
            // Build the alert message
            let message = "Blood Stock Details:\n";
            response.forEach(item => {
              message += `Blood Type: ${item.blood_type}, Stock: ${item.stock}\n`;
            });
            alert(message); // Show the stock details in an alert box
          }
        }
      };
      xhr.send();
    });
  </script>
</body>

</html>

<?php
// Start the table
echo "<table border='1'>
        <tr>
            <th>Receiver's Name</th>
            <th>Contact</th>
            <th>Blood Type</th>
            <th>Units</th> <!-- Add column header for Units -->
            <th>Status</th>
            <th>Request Date</th>
            <th>Action</th>
        </tr>";

if ($result->num_rows > 0) {
  // Output data of each row
  while ($row = $result->fetch_assoc()) {
    // Get donor name (assuming user_id references a user table)
    $user_id = $row["user_id"];
    $user_name_query = "SELECT name FROM users WHERE id = $user_id"; // Query to get the donor's name
    $user_name_result = $conn->query($user_name_query);
    $user_name = ($user_name_result->num_rows > 0) ? $user_name_result->fetch_assoc()["name"] : "Unknown";

    echo "<tr id='request-" . $row['id'] . "'>
                <td>" . $user_name . "</td>
                <td>" . $row["contact_number"] . "</td>
                <td>" . $row["blood_type"] . "</td>
                <td>" . $row["unit"] . "</td> <!-- Add the Units field here -->
                <td>" . $row["status"] . "</td>
                <td>" . $row["created_at"] . "</td>
                <td>
                    <a href='approve_request.php?id=" . $row['id'] . "'>Approve</a> |
                    <a href='delete_request.php?id=" . $row['id'] . "' onclick='return confirm(\"Are you sure you want to delete this request?\");'>Delete</a>
                </td>
              </tr>";
  }
  echo "</table>";
} else {
  echo "0 results";
}

$conn->close();

// Include the footer file
include('footer.php');
?>
<style>
  table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
    background-color: #fff;
  }

  th,
  td {
    padding: 12px;
    text-align: left;
    border: 1px solid #ddd;
  }

  th {
    background-color: #4CAF50;
    color: white;
  }

  tr:nth-child(even) {
    background-color: #f2f2f2;
  }

  a {
    color: #4CAF50;
    text-decoration: none;
    margin-right: 10px;
  }

  a:hover {
    text-decoration: underline;
  }
</style>