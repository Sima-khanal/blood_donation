<?php
session_start();

// Include the database connection
include('db.php');

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Fetch all blood requests from the database
$sql = "SELECT * FROM blood_requests ORDER BY created_at DESC";
$result = $conn->query($sql);

// Update request status based on action
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && isset($_POST['request_id'])) {
    $request_id = $_POST['request_id'];
    $action = $_POST['action'];
    
    $status = "";
    if ($action == "accept") {
        $status = "Accepted";
    } elseif ($action == "cancel") {
        $status = "Cancelled";
    } elseif ($action == "dispatch") {
        $status = "Dispatched";
    }

    // Update the status in the database
    if ($status != "") {
        $stmt = $conn->prepare("UPDATE blood_requests SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $request_id);
        
        if ($stmt->execute()) {
            $success_message = "Request status updated successfully!";
        } else {
            $error_message = "Error: Could not update the status.";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin - View Blood Requests</title>
  <style>
        body {
            background: #f0f0f0;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        /* Glass Effect Navbar */
        .glass-navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            background: rgba(255, 255, 255, 0.2);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .navbar-left h1 {
            font-size: 24px;
            color: #ff4d4d;
        }

        .navbar-right ul {
            list-style: none;
            display: flex;
            gap: 20px;
            margin: 0;
            padding: 0;
        }

        .navbar-right ul li {
            display: inline;
        }

        .navbar-right ul li a {
            text-decoration: none;
            color: #333;
            font-weight: bold;
            padding: 8px 15px;
            border-radius: 20px;
            transition: 0.3s;
        }

        .navbar-right ul li a:hover {
            background: rgba(255, 77, 77, 0.2);
            color: #ff4d4d;
        }

        .request-container {
            max-width: 1000px;
            margin: 50px auto;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #ff4d4d;
        }

        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        table th {
            background: #ff4d4d;
            color: white;
        }

        /* Status Styling */
        .status-pending {
            background: #ffcc00;
            color: black;
            padding: 5px;
            border-radius: 5px;
            font-weight: bold;
        }

        .status-accepted {
            background: #28a745;
            color: white;
            padding: 5px;
            border-radius: 5px;
            font-weight: bold;
        }

        .status-cancelled {
            background: #dc3545;
            color: white;
            padding: 5px;
            border-radius: 5px;
            font-weight: bold;
        }

        .status-dispatched {
            background: #007bff;
            color: white;
            padding: 5px;
            border-radius: 5px;
            font-weight: bold;
        }

        /* Action Buttons */
        .action-button {
            padding: 8px 12px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-weight: bold;
            transition: 0.3s;
        }

        .accept-btn {
            background: #28a745;
            color: white;
        }

        .accept-btn:hover {
            background: #218838;
        }

        .cancel-btn {
            background: #dc3545;
            color: white;
        }

        .cancel-btn:hover {
            background: #c82333;
        }

        .dispatch-btn {
            background: #007bff;
            color: white;
        }

        .dispatch-btn:hover {
            background: #0056b3;
        }

  </style>
</head>

<body>

   <nav class="glass-navbar">
        <div class="navbar-left">
            <h1>Blood Donation System</h1>
        </div>
        <div class="navbar-right">
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage_stock.php">Manage Stock</a></li>
                <li><a href="manage_requests.php">Blood Requests</a></li>
                <li><a href="donor_request.php">Donor Request</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

  <section id="view-requests-section">
    <div class="request-container">
        <h2>Manage Blood Donation Requests</h2>
        <?php
        if (isset($success_message)) {
            echo '<p class="success-message">' . $success_message . '</p>';
        }
        if (isset($error_message)) {
            echo '<p class="error-message">' . $error_message . '</p>';
        }
        ?>

        <!-- Table to display all blood requests -->
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Blood Type</th>
                    <th>Contact Number</th>
                    <th>Message</th>
                    <th>Quantity</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['blood_type'] . "</td>";
                        echo "<td>" . $row['contact_number'] . "</td>";
                        echo "<td>" . $row['message'] . "</td>";
                        echo "<td>" . $row['quantity'] . "</td>";
                        echo "<td class='status-" . strtolower($row['status']) . "'>" . $row['status'] . "</td>";
                        echo "<td>";

                        if ($row['status'] == 'Pending') {
                            echo "<form method='POST'>
                                    <input type='hidden' name='request_id' value='" . $row['id'] . "'>
                                    <button type='submit' name='action' value='accept' class='action-button accept-btn'>Accept</button>
                                    <button type='submit' name='action' value='cancel' class='action-button cancel-btn'>Cancel</button>
                                  </form>";
                        } elseif ($row['status'] == 'Accepted') {
                            echo "<form method='POST'>
                                    <button type='submit' name='action' value='dispatch' class='action-button dispatch-btn'>Dispatch</button>
                                  </form>";
                        }

                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No requests found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
  </section>
<?php include('footer.php'); ?>
</body>
</html>
