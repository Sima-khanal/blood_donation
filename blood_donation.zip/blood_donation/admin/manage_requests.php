<?php
// Include the header file
include('header.php');

// Include database connection file
include('db.php');

$sql = "SELECT id, user_id, blood_type, contact_number, message, status, created_at FROM blood_requests"; // Modify your table name
$result = $conn->query($sql);

// Start the table
echo "<table border='1'>
        <tr>
            <th>Donor Name</th>
            <th>Contact</th>
            <th>Blood Type</th>
            <th>Status</th>
            <th>Request Date</th>
            <th>Action</th>
        </tr>";

if ($result->num_rows > 0) {
  // Output data of each row
  while ($row = $result->fetch_assoc()) {
    // Get donor name (assuming user_id references a user table)
    $user_id = $row["user_id"];
    $user_name_query = "SELECT name FROM users WHERE id = $user_id"; // Query to get the donor's name
    $user_name_result = $conn->query($user_name_query);
    $user_name = ($user_name_result->num_rows > 0) ? $user_name_result->fetch_assoc()["name"] : "Unknown";

    echo "<tr id='request-" . $row['id'] . "'>
                <td>" . $user_name . "</td>
                <td>" . $row["contact_number"] . "</td>
                <td>" . $row["blood_type"] . "</td>
                <td>" . $row["status"] . "</td>
                <td>" . $row["created_at"] . "</td>
                <td>
                    <a href='approve_request.php?id=" . $row['id'] . "'>Approve</a> |
                    <a href='delete_request.php?id=" . $row['id'] . "' onclick='return confirm(\"Are you sure you want to delete this request?\");'>Delete</a>
                </td>
              </tr>";
  }
  echo "</table>";
} else {
  echo "0 results";
}

$conn->close();

// Include the footer file
include('footer.php');
?>
<style>
  table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
    background-color: #fff;
  }

  th,
  td {
    padding: 12px;
    text-align: left;
    border: 1px solid #ddd;
  }

  th {
    background-color: #4CAF50;
    color: white;
  }

  tr:nth-child(even) {
    background-color: #f2f2f2;
  }

  a {
    color: #4CAF50;
    text-decoration: none;
    margin-right: 10px;
  }

  a:hover {
    text-decoration: underline;
  }
</style>