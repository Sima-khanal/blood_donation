<?php
session_start();

// Include the database connection
include('db.php');

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Fetch all blood requests from the database
$sql = "SELECT * FROM blood_requests ORDER BY created_at DESC";
$result = $conn->query($sql);

// Update request status based on action
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && isset($_POST['request_id'])) {
    $request_id = $_POST['request_id'];
    $action = $_POST['action'];
    
    $status = "";
    if ($action == "accept") {
        $status = "Accepted";
    } elseif ($action == "cancel") {
        $status = "Cancelled";
    } elseif ($action == "dispatch") {
        $status = "Dispatched";
    }

    // Update the status in the database
    if ($status != "") {
        $stmt = $conn->prepare("UPDATE blood_requests SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $request_id);
        
        if ($stmt->execute()) {
            $success_message = "Request status updated successfully!";
        } else {
            $error_message = "Error: Could not update the status.";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin - View Blood Requests</title>
  <style>
        body {
            background: #f0f0f0;
        }

        /* Glass Effect Navbar */
        .glass-navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            background: rgba(255, 255, 255, 0.2);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .navbar-left h1 {
            font-size: 24px;
            color: #ff4d4d;
        }

        .navbar-right ul {
            list-style: none;
            display: flex;
            gap: 20px;
        }

        .navbar-right ul li {
            display: inline;
        }

        .navbar-right ul li a {
            text-decoration: none;
            color: #333;
            font-weight: bold;
            padding: 8px 15px;
            border-radius: 20px;
            transition: 0.3s;
        }

        .navbar-right ul li a:hover {
            background: rgba(255, 77, 77, 0.2);
            color: #ff4d4d;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .glass-navbar {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }

            .navbar-right ul {
                flex-direction: column;
                gap: 10px;
            }
  </style>
</head>

<body>

   <nav class="glass-navbar">
        <div class="navbar-left">
            <h1>Blood Donation System</h1>
        </div>
        <div class="navbar-right">
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage_stock.php">Manage Stock</a></li>
                <li><a href="manage_requests.php">Blood Requests</a></li>
                <li><a href="donor_request.php">Donor Request</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

  <section id="view-requests-section">
    <div class="request-container">
        <h2>Manage Blood Donation Requests</h2>
        <?php
        if (isset($success_message)) {
            echo '<p class="success-message">' . $success_message . '</p>';
        }
        if (isset($error_message)) {
            echo '<p class="error-message">' . $error_message . '</p>';
        }
        ?>

        <!-- Table to display all blood requests -->
        <table border="1" cellpadding="10" cellspacing="0" style="width: 100%; margin-top: 20px;">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Blood Type</th>
                    <th>Contact Number</th>
                    <th>Message</th>
                    <th>Quantity</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['blood_type'] . "</td>";
                        echo "<td>" . $row['contact_number'] . "</td>";
                        echo "<td>" . $row['message'] . "</td>";
                        echo "<td>" . $row['quantity'] . "</td>";
                        echo "<td>" . $row['status'] . "</td>";
                        echo "<td>";

                        // Show actions based on current status
                        if ($row['status'] == 'Pending') {
                            echo "<form method='POST' style='display:inline;'>
                                    <input type='hidden' name='request_id' value='" . $row['id'] . "'>
                                    <button type='submit' name='action' value='accept'>Accept</button>
                                    <button type='submit' name='action' value='cancel'>Cancel</button>
                                  </form>";
                        } elseif ($row['status'] == 'Accepted') {
                            echo "<form method='POST' style='display:inline;'>
                                    <input type='hidden' name='request_id' value='" . $row['id'] . "'>
                                    <button type='submit' name='action' value='dispatch'>Dispatch</button>
                                  </form>";
                        }

                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No requests found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
  </section>

  <?php include('footer.php'); ?>

</body>

</html>
