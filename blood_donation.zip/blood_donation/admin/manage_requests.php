<?php
// Include database connection
include('db.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Blood Requests</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: #f4f4f4;
        }
        .search-bar {
            margin-bottom: 20px;
            text-align: center;
        }
        .search-bar input {
            padding: 8px;
            width: 250px;
            margin-right: 10px;
        }
        .search-bar button {
            padding: 8px 12px;
            background-color: #007BFF;
            color: #fff;
            border: none;
            cursor: pointer;
        }
        .search-bar button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
   <?php include('header.php');?>
   
    <h1>Manage Blood Requests</h1>

    <!-- Search bar for blood types -->
    <form class="search-bar" method="GET" action="search.php">
        <input type="text" name="blood_type" placeholder="Search Blood Group" required>
        <button type="submit">Search</button>
    </form>

    <!-- Display requests -->
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Phone No</th>
                <th>Blood Group</th>
                <th>Quantity</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Query to fetch blood requests
            $sql = "SELECT blood_requests.id, blood_requests.blood_type, blood_requests.quantity, 
                           blood_requests.status, blood_requests.contact_number, users.name 
                    FROM blood_requests 
                    JOIN users ON blood_requests.user_id = users.id";
            $result = $conn->query($sql);

            // Loop through each row and display
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>{$row['name']}</td>";
                echo "<td>{$row['contact_number']}</td>";
                echo "<td>{$row['blood_type']}</td>";
                echo "<td>{$row['quantity']}</td>";
                echo "<td>{$row['status']}</td>";
                echo "<td>";
                if ($row['status'] == 'pending') {
                    echo "<a href='approve_request.php?id={$row['id']}'>Approve</a>";
                } elseif ($row['status'] == 'approved') {
                    echo "<a href='dispatch_request.php?id={$row['id']}'>Dispatch</a>";
                } else {
                    echo "Dispatched";
                }
                echo "</td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
     <?php include('footer.php'); ?>
</body>
</html>
