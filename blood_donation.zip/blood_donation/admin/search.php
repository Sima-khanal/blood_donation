<?php
include 'db.php';

$bloodType = isset($_GET['blood_type']) ? $_GET['blood_type'] : '';
$minStock = isset($_GET['min_stock']) ? (int)$_GET['min_stock'] : 0;

$query = "SELECT blood_type, stock FROM blood_stock WHERE stock >= $minStock";
if (!empty($bloodType)) {
  $query .= " AND blood_type = '$bloodType'";
}

$result = $conn->query($query);

$response = [];

if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $response[] = $row; // Add each result to the response array
  }
} else {
  $response = ['message' => 'No matching blood types found.'];
}

// Send JSON response
header('Content-Type: application/json');
echo json_encode($response);

$conn->close();
