<?php
include 'db_connection.php'; // Replace with your actual DB connection file

$id = $_GET['id'];

// Fetch the request details
$request = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM requests WHERE id='$id'"));
$requested_amount = $request['quantity'];
$blood_type = $request['blood_type'];

// Reduce the stock amount
$update_stock = "UPDATE blood_stock SET stock = stock - $requested_amount WHERE blood_type='$blood_type'";
if (mysqli_query($conn, $update_stock)) {
  // Update the request status to "dispatched"
  $update_request = "UPDATE requests SET status='dispatched' WHERE id='$id'";
  if (mysqli_query($conn, $update_request)) {
    header("Location: admin_dashboard.php"); // Redirect back to the admin dashboard
  } else {
    echo "Error updating request status: " . mysqli_error($conn);
  }
} else {
  echo "Error updating stock: " . mysqli_error($conn);
}

mysqli_close($conn);
