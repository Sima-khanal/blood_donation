<?php
// Include database connection
include('db.php');

// Fetch data from the database
$query = "SELECT date, stock FROM blood_stock WHERE blood_type = 'A+' ORDER BY date";
$result = $conn->query($query);

$dates = [];
$stocks = [];

while ($row = $result->fetch_assoc()) {
  $dates[] = $row['date'];
  $stocks[] = $row['stock'];
}


$datesJson = json_encode($dates);
$stocksJson = json_encode($stocks);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Line Graph with PHP and Chart.js</title>
</head>

<body>
  <div style="width: 80%; margin: auto;">
    <canvas id="lineChart"></canvas>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
    const labels = <?php echo $datesJson; ?>; // X-axis labels (Dates)
    const data = <?php echo $stocksJson; ?>; // Y-axis data (Stock levels)

    // Create the line chart
    const ctx = document.getElementById('lineChart').getContext('2d');
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: 'Blood Stock Levels',
          data: data,
          borderColor: 'rgba(75, 192, 192, 1)',
          backgroundColor: 'rgba(75, 192, 192, 0.2)',
          borderWidth: 2,
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: true,
            position: 'top'
          }
        },
        scales: {
          x: {
            title: {
              display: true,
              text: 'Date'
            }
          },
          y: {
            title: {
              display: true,
              text: 'Stock Levels'
            },
            beginAtZero: true
          }
        }
      }
    });
  </script>
</body>

</html>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>