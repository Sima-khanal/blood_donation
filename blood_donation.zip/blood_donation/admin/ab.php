<?php
include('db.php');
// Assuming you have a MySQLi connection in $conn
$query = "SELECT * FROM blood_stock ORDER BY blood_type ASC";
$result = $conn->query($query); // Use query() with MySQLi

// Check if there are any results
if ($result->num_rows > 0) {
  // Fetch the results into an associative array
  $bloodStocks = $result->fetch_all(MYSQLI_ASSOC); // Use fetch_all() with MySQLi
} else {
  $bloodStocks = []; // No data found
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Blood Stock Management Dashboard</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f9f9f9;
    }

    .container {
      width: 90%;
      margin: 20px auto;
    }

    h1 {
      text-align: center;
      color: #333;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    table,
    th,
    td {
      border: 1px solid #ddd;
    }

    th,
    td {
      text-align: left;
      padding: 12px;
    }

    th {
      background-color: #4CAF50;
      color: white;
    }

    tr:nth-child(even) {
      background-color: #f2f2f2;
    }

    .form-container {
      margin-bottom: 20px;
    }

    .form-container input,
    .form-container button {
      padding: 10px;
      margin-right: 10px;
    }
  </style>
</head>

<body>
  <div class="container">
    <h1>Blood Stock Management Dashboard</h1>

    <!-- Add Blood Stock Form -->
    <div class="form-container">
      <form method="POST" action="crud.php">
        <input type="text" name="blood_type" placeholder="Blood Type (e.g., A+)" required>
        <input type="number" name="stock" placeholder="Stock Amount" required>
        <button type="submit" name="add">Add Blood Stock</button>
      </form>
    </div>

    <!-- Display Blood Stock -->
    <?php if (!empty($bloodStocks)): ?>
      <?php foreach (['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'] as $bloodType): ?>
        <h2><?= htmlspecialchars($bloodType); ?> Blood Group</h2>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Blood Type</th>
              <th>Stock</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($bloodStocks as $stock): ?>
              <?php if ($stock['blood_type'] === $bloodType): ?>
                <tr>
                  <td><?= htmlspecialchars($stock['id']); ?></td>
                  <td><?= htmlspecialchars($stock['blood_type']); ?></td>
                  <td><?= htmlspecialchars($stock['stock']); ?></td>
                  <td>
                    <!-- Update Form -->
                    <form method="POST" action="crud.php" style="display: inline;">
                      <input type="hidden" name="id" value="<?= $stock['id']; ?>">
                      <input type="number" name="stock" value="<?= $stock['stock']; ?>" required>
                      <button type="submit" name="update">Update</button>
                    </form>
                    <!-- Delete Link -->
                    <a href="crud.php?delete_id=<?= $stock['id']; ?>" onclick="return confirm('Are you sure?');">Delete</a>
                  </td>
                </tr>
              <?php endif; ?>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endforeach; ?>
    <?php else: ?>
      <p>No blood stock available.</p>
    <?php endif; ?>
  </div>
</body>

</html>