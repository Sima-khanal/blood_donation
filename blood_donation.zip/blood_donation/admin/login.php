<?php
session_start();

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $admin_id = $_POST['admin_id'];
  $password = $_POST['password'];

  // Simple validation (Admin ID and Password check)
  // Here, we are assuming that the Admin ID and Password are hardcoded for now
  $valid_admin_id = 'admin123'; // Example admin ID
  $valid_password = 'password123'; // Example password

  // If Admin credentials are correct
  if ($admin_id == $valid_admin_id && $password == $valid_password) {
    $_SESSION['admin_logged_in'] = true;
    $_SESSION['admin_id'] = $admin_id;
    header("Location: dashboard.php"); // Redirect to admin dashboard
    exit();
  } else {
    $error_message = "Invalid Admin ID or Password!";
  }
}
?>
<style>
  #login-section {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background-color: #f4f4f4;
  }

  .login-container {
    background-color: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    width: 400px;
    text-align: center;
  }

  .login-container h2 {
    margin-bottom: 20px;
    color: #333;
  }

  .login-container label {
    display: block;
    margin-bottom: 8px;
    text-align: left;
    color: #555;
  }

  .login-container input {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 4px;
  }

  .login-container .btn-submit {
    background-color: #4CAF50;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }

  .login-container .btn-submit:hover {
    background-color: #45a049;
  }

  .error-message {
    color: red;
    font-size: 14px;
    margin-bottom: 10px;
  }
</style>
<!-- Login Form Section -->
<section id="login-section">
  <div class="login-container">
    <h2>Admin Login</h2>
    <?php
    if (isset($error_message)) {
      echo '<p class="error-message">' . $error_message . '</p>';
    }
    ?>
    <form action="login.php" method="POST">
      <label for="admin_id">Admin ID:</label>
      <input type="text" id="admin_id" name="admin_id" required placeholder="Enter Admin ID" />

      <label for="password">Password:</label>
      <input type="password" id="password" name="password" required placeholder="Enter Password" />

      <button type="submit" class="btn-submit">Login</button>
    </form>
  </div>
</section>