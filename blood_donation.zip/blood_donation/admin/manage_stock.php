<?php
include('db.php');
$query = "SELECT * FROM blood_stock ORDER BY blood_type ASC";
$result = $conn->query($query);
if ($result->num_rows > 0) {
  $bloodStocks = $result->fetch_all(MYSQLI_ASSOC);
} else {
  $bloodStocks = [];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Blood Stock Management Dashboard</title>
  <style>
    .container {
      width: 90%;
      margin: 20px auto;
    }

    h1 {
      text-align: center;
      color: #333;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    table,
    th,
    td {
      border: 1px solid #ddd;
    }

    th,
    td {
      text-align: left;
      padding: 12px;
    }

    th {
      background-color: #4CAF50;
      color: white;
    }

    tr:nth-child(even) {
      background-color: #f2f2f2;
    }

    .form-container {
      margin-bottom: 20px;
    }

    .form-container input,
    .form-container button {
      padding: 10px;
      margin-right: 10px;
    }
  </style>
</head>

<body>
  <div class="container">
    <h1>Blood Stock Management Dashboard</h1>
    <?php if (!empty($bloodStocks)): ?>
      <?php foreach (['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'] as $bloodType): ?>
        <h2><?= htmlspecialchars($bloodType); ?> Blood Group</h2>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Blood Type</th>
              <th>Stock</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($bloodStocks as $stock): ?>
              <?php if ($stock['blood_type'] === $bloodType): ?>
                <tr>
                  <td><?= htmlspecialchars($stock['id']); ?></td>
                  <td><?= htmlspecialchars($stock['blood_type']); ?></td>
                  <td><?= htmlspecialchars($stock['stock']); ?></td>
                  <td>
                    <!-- Update Form -->
                    <form method="POST" action="crud.php" style="display: inline;">
                      <input type="hidden" name="id" value="<?= $stock['id']; ?>">
                      <input type="number" name="stock" value="<?= $stock['stock']; ?>" min="0" required>
                      <button type="submit" name="update">Update</button>
                    </form>
                  </td>
                </tr>
              <?php endif; ?>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endforeach; ?>
    <?php else: ?>
      <p>No blood stock available.</p>
    <?php endif; ?>
  </div>
</body>

</html>