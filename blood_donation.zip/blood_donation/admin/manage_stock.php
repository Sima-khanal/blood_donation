<?php
include('db.php');

// Fetch blood stocks from the database
$query = "SELECT * FROM blood_stock ORDER BY blood_type ASC";
$result = $conn->query($query);
$bloodStocks = $result->num_rows > 0 ? $result->fetch_all(MYSQLI_ASSOC) : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Blood Stock Management</title>
  <style>
    /* General Styling */
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f9;
      color: #333;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      min-height: 100vh;
    }

    /* Header */
    h1 {
      text-align: center;
      margin-bottom: 20px;
      color: #0056b3;
    }

    /* Table Styling */
    table {
      width: 80%;
      border-collapse: collapse;
      margin: 0 auto;
      background: #fff;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
      overflow: hidden;
    }

    table th, table td {
      border: 1px solid #ddd;
      padding: 10px;
      text-align: center;
      font-size: 14px;
    }

    table th {
      background-color: #0056b3;
      color: white;
      font-weight: bold;
    }

    table tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    table tr:hover {
      background-color: #f1f1f1;
    }

    /* Action Buttons */
    form {
      display: inline-block;
    }

    input[type="number"] {
      width: 70px;
      padding: 5px;
      font-size: 14px;
      border: 1px solid #ccc;
      border-radius: 4px;
      text-align: center;
    }

    button {
      padding: 5px 10px;
      font-size: 14px;
      color: white;
      background-color: #0056b3;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    button:hover {
      background-color: #003d7a;
    }
  </style>
</head>
<body>
   <?php include('header.php');?>
  <h1>Manage Stock</h1>
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Blood Type</th>
        <th>Stock</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($bloodStocks as $stock): ?>
        <tr>
          <td><?= htmlspecialchars($stock['id']); ?></td>
          <td><?= htmlspecialchars($stock['blood_type']); ?></td>
          <td>
            <form method="POST" action="crud.php" style="display: inline;">
              <input type="hidden" name="id" value="<?= htmlspecialchars($stock['id']); ?>">
              <input type="number" name="stock" value="<?= htmlspecialchars($stock['stock']); ?>" min="0" required>
          </td>
          <td>
              <button type="submit" name="update">Update</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
   <?php include('footer.php'); ?>
</body>
</html>
