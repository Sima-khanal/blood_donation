<?php
// Include the database connection
include('db.php');

// Check if the admin has taken any action
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $donation_id = $_POST['donation_id']; // Donation ID from form
    $action = $_POST['action']; // Action (Accept, Reject, Donate)

    $sql = "";
    if ($action === "Accept") {
        $sql = "UPDATE donation SET status = 'Accepted' WHERE id = ?";
    } elseif ($action === "Reject") {
        $sql = "UPDATE donation SET status = 'Rejected' WHERE id = ?";
    } elseif ($action === "Donate") {
        $sql = "UPDATE donation SET status = 'Completed' WHERE id = ?";
    }

    // Execute the SQL query
    if ($sql && $stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $donation_id);
        if ($stmt->execute()) {
            echo "<script>alert('Action completed successfully!');</script>";
        } else {
            echo "<p style='color: red;'>Error: " . $stmt->error . "</p>";
        }
        $stmt->close();
    } else {
        echo "<p style='color: red;'>Database error: " . $conn->error . "</p>";
    }
}

// Fetch all donations from the database
$sql = "SELECT * FROM donation";
$result = $conn->query($sql);

// Check if the query was successful
if (!$result) {
    die("Error: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Donations - Admin</title>
    <style>
         body {
            background: #f0f0f0;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        /* Glass Effect Navbar */
        .glass-navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            background: rgba(255, 255, 255, 0.2);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .navbar-left h1 {
            font-size: 24px;
            color: #ff4d4d;
        }

        .navbar-right ul {
            list-style: none;
            display: flex;
            gap: 20px;
            margin: 0;
            padding: 0;
        }

        .navbar-right ul li {
            display: inline;
        }

        .navbar-right ul li a {
            text-decoration: none;
            color: #333;
            font-weight: bold;
            padding: 8px 15px;
            border-radius: 20px;
            transition: 0.3s;
        }

        .navbar-right ul li a:hover {
            background: rgba(255, 77, 77, 0.2);
            color: #ff4d4d;
        }

        .request-container {
            max-width: 1000px;
            margin: 50px auto;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #ff4d4d;
        }

        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        table th {
            background: #ff4d4d;
            color: white;
        }

        /* Status Styling */
        .status-pending {
            background: #ffcc00;
            color: black;
            padding: 5px;
            border-radius: 5px;
            font-weight: bold;
        }

        .status-accepted {
            background: #28a745;
            color: white;
            padding: 5px;
            border-radius: 5px;
            font-weight: bold;
        }

        .status-cancelled {
            background: #dc3545;
            color: white;
            padding: 5px;
            border-radius: 5px;
            font-weight: bold;
        }

        .status-donate {
            background: #007bff;
            color: white;
            padding: 5px;
            border-radius: 5px;
            font-weight: bold;
        }

        /* Action Buttons */
        .action-button {
            padding: 8px 12px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-weight: bold;
            transition: 0.3s;
        }

        .accept-btn {
            background: #28a745;
            color: white;
        }

        .accept-btn:hover {
            background: #218838;
        }

        .reject-btn {
            background: #dc3545;
            color: white;
        }

        .reject-btn:hover {
            background: #c82333;
        }

        .donate-btn {
            background: #007bff;
            color: white;
        }

        .donate-btn:hover {
            background: #0056b3;
        }

    </style>
</head>
<body>
<nav class="glass-navbar">
        <div class="navbar-left">
            <h1>Blood Donation System</h1>
        </div>
        <div class="navbar-right">
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage_stock.php">Manage Stock</a></li>
                <li><a href="manage_requests.php">Blood Requests</a></li>
                <li><a href="donor_request.php">Donor Request</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <h1>Manage Donations</h1>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Birthdate</th>
                    <th>Last Donated Date</th>
                    <th>Donation Date</th>
                    <th>Blood Type</th>
                    <th>Weight</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['birthdate']; ?></td>
                        <td><?php echo $row['last_donated_date']; ?></td>
                        <td><?php echo $row['donation_date']; ?></td>
                        <td><?php echo $row['blood_type']; ?></td>
                        <td><?php echo $row['weight_kg']; ?> kg</td>
                        <td class="status-<?php echo strtolower($row['status']); ?>"><?php echo $row['status']; ?></td>
                        <td>
                            <form method="POST" action="donor_request.php">
                                <input type="hidden" name="donation_id" value="<?php echo $row['id']; ?>">
                                <?php if ($row['status'] == 'Pending') { ?>
                                    <button type="submit" name="action" value="Accept" class="accept-btn">Accept</button>
                                    <button type="submit" name="action" value="Reject" class="reject-btn">Reject</button>
                                <?php } elseif ($row['status'] == 'Accepted') { ?>
                                    <button type="submit" name="action" value="Donate" class="donate-btn">Donate</button>
                                <?php } ?>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

<?php include('footer.php'); ?>

</body>
</html>
