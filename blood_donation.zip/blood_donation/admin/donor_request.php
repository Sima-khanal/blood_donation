<?php
// Include database connection
include('db.php');

// Handle donation status update to "approved"
if (isset($_POST['approve_donation'])) {
    $donation_id = $_POST['donation_id'];

    // Update the donation status to "approved" in the database
    $sql = "UPDATE donation SET status = 'approved' WHERE id = $donation_id";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Donation approved.');</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Handle donation status update to "donated"
if (isset($_POST['donate_blood'])) {
    $donation_id = $_POST['donation_id'];

    // Update the donation status to "donated" in the database
    $sql = "UPDATE donation SET status = 'donated' WHERE id = $donation_id";
    if ($conn->query($sql) === TRUE) {
        // Increase the blood stock when status is updated to "donated"
        $update_stock_sql = "UPDATE blood_stock SET stock = stock + 1 WHERE blood_type = (SELECT blood_type FROM donation WHERE id = $donation_id)";
        $conn->query($update_stock_sql);
        echo "<script>alert('Donation marked as donated. Stock updated.');</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Handle donation request deletion
if (isset($_POST['delete_donation'])) {
    $donation_id = $_POST['donation_id'];

    // Delete the donation request from the database
    $delete_sql = "DELETE FROM donation WHERE id = $donation_id";
    if ($conn->query($delete_sql) === TRUE) {
        echo "<script>alert('Donation request deleted successfully.');</script>";
    } else {
        echo "Error: " . $delete_sql . "<br>" . $conn->error;
    }
}

// Retrieve all donations
$sql = "SELECT * FROM donation";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Donations</title>
    <style>
        table {
            width: 100%;
            margin: 20px 0;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f4f4f9;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            border-radius: 4px;
        }

        button:hover {
            background-color: #45a049;
        }

        .delete-btn {
            background-color: #f44336;
        }

        .delete-btn:hover {
            background-color: #e53935;
        }

        .donate-btn {
            background-color: #008CBA;
        }

        .donate-btn:hover {
            background-color: #007B9C;
        }
    </style>
</head>
<body>
    <?php include('header.php');?>
    <table>
        <thead>
            <tr>
                <th>Donation ID</th>
                <th>Donor Info</th>
                <th>Donation Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Display donation records
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['birthdate'] . " - " . $row['blood_type']; ?></td>
                        <td><?php echo $row['donation_date']; ?></td>
                        <td><?php echo ucfirst($row['status']); ?></td>
                        <td>
                            <?php if ($row['status'] == 'pending') { ?>
                                <form method="POST" action="" style="display:inline;">
                                    <input type="hidden" name="donation_id" value="<?php echo $row['id']; ?>">
                                    <button type="submit" name="approve_donation">Approve</button>
                                </form>
                            <?php } ?>
                            <?php if ($row['status'] == 'approved') { ?>
                                <form method="POST" action="" style="display:inline;">
                                    <input type="hidden" name="donation_id" value="<?php echo $row['id']; ?>">
                                    <button type="submit" name="donate_blood" class="donate-btn">Donate</button>
                                </form>
                            <?php } ?>

                            <?php if ($row['status'] != 'donated') { ?>
                                <form method="POST" action="" style="display:inline;">
                                    <input type="hidden" name="donation_id" value="<?php echo $row['id']; ?>">
                                    <button type="submit" name="delete_donation" class="delete-btn">Delete</button>
                                </form>
                            <?php } ?>
                        </td>
                    </tr>
                    <?php
                }
            } else {
                echo "<tr><td colspan='5'>No donation records found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
     <?php include('footer.php');?>
</body>
</html>
