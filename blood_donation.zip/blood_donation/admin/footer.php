  <footer>
    <div class="container">
      <div class="footer-section">
        <div>
          <h4>BD - Admin Panel</h4>
          <p>Efficiently manage system users, records, and operations.</p>
        </div>

        <div>
          <h4>Quick Links</h4>
          <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="manage_requests.php">Manage Request</a></li>
            <li><a href="manage_stock.php">Manage Stock</a></li>
          </ul>
        </div>

        <div class="contact-info">
          <h4>Contact Support</h4>
          <p>For any assistance, contact IT support:</p>
          <p>Email: <a href="mailto:simacodevibrant@gmail.com/upreti.cloudtechservices@gmail.com">simacodevibrant@gmail.com/upreti.cloudtechservices@gmail.com</a></p>
          <p>Phone: +977-01-2345678</p>
        </div>
      </div>

      <div class="bottom">
        <p>©2025 SD creation. All Rights Reserved.</p>
      </div>
    </div>
  </footer>
    <style>
    
  footer {
    background-color: #333;
    color: #fff;
    padding: 40px 20px;
    font-family: Arial, sans-serif;
  }

  .container {
    max-width: 1200px;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
  }

  /* Footer Section */
  .footer-section {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    margin-bottom: 40px;
    gap: 30px;
    text-align: left;
    width: 100%;
  }

  /* Section Titles */
  h4 {
    color: #007bff;
    margin-bottom: 15px;
    font-size: 18px;
  }

  /* Paragraph and Links */
  p, ul {
    color: #ddd;
    line-height: 1.6;
  }

  /* Links */
  a {
    color: #ddd;
    text-decoration: none;
    transition: color 0.3s ease;
  }

  a:hover {
    color: #007bff;
  }

  /* Quick Links */
  .footer-section ul {
    list-style: none;
    padding: 0;
  }

  .footer-section ul li {
    margin-bottom: 10px;
  }

  /* Contact Info Section */
  .contact-info a {
    color: #ddd;
    text-decoration: underline;
  }

  .contact-info a:hover {
    color: #007bff;
  }

  /* Bottom Text */
  .bottom {
    margin-top: 20px;
    font-size: 14px;
    color: #aaa;
  }

  .bottom p {
    margin: 0;
  }

  /* Responsive Design */
  @media (max-width: 768px) {
    .footer-section {
      flex-direction: column;
      align-items: center;
    }

    .footer-section div {
      width: 100%;
      margin-bottom: 20px;
    }
  }
</style>
</body>

</html>