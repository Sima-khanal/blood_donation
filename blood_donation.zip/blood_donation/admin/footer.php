<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Footer Example</title>
  <style>
    html,
    body {
      height: 100%;
      margin: 0;
    }

    body {
      display: flex;
      flex-direction: column;
      font-family: Arial, sans-serif;
    }

    .content {
      flex: 1;
    }

    footer {
      background-color: #2c3e50;
      color: #ecf0f1;
      padding: 20px;
      text-align: center;
      font-family: Arial, sans-serif;
      margin-top: auto;
    }

    footer .container {
      max-width: 1200px;
      margin: auto;
    }

    .footer-section {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      align-items: center;
    }

    .footer-section div {
      flex: 1;
      min-width: 250px;
      margin: 10px;
    }

    .footer-section h4 {
      color: #3498db;
      margin-bottom: 10px;
    }

    .footer-section ul {
      list-style: none;
      padding: 0;
      line-height: 1.8;
    }

    .footer-section a {
      color: #bdc3c7;
      text-decoration: none;
    }

    .footer-section .contact-info a {
      color: #1abc9c;
      text-decoration: none;
    }

    footer .bottom {
      margin-top: 20px;
      border-top: 1px solid #7f8c8d;
      padding-top: 10px;
    }
  </style>
</head>

<body>

  <!-- Main content -->
  <div class="content">
    <!-- Your page content here -->
  </div>

  <!-- Footer -->
  <footer>
    <div class="container">
      <div class="footer-section">
        <div>
          <h4>BD - Admin Panel</h4>
          <p>Efficiently manage system users, records, and operations.</p>
        </div>

        <div>
          <h4>Quick Links</h4>
          <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="manage_requests.php">Manage Request</a></li>
            <li><a href="manage_stock.php">Manage Stock</a></li>
          </ul>
        </div>

        <div class="contact-info">
          <h4>Contact Support</h4>
          <p>For any assistance, contact IT support:</p>
          <p>Email: <a href="mailto:support@BD.edu">support@BD.edu</a></p>
          <p>Phone: +977-01-2345678</p>
        </div>
      </div>

      <div class="bottom">
        <p>© 2023 BD. Admin Panel. All Rights Reserved.</p>
      </div>
    </div>
  </footer>

</body>

</html>