<?php
// Include database connection
include('db.php');

// Check if request ID is provided
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Update the status to "approved"
    $stmt = $conn->prepare("UPDATE blood_requests SET status = 'approved' WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: manage_requests.php?message=Request approved successfully.");
        exit();
    } else {
        echo "Error: Could not approve the request.";
    }
} else {
    echo "Invalid request ID.";
}

$conn->close();
?>
