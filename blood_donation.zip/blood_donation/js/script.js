// Function to handle form validation for user registration
function validateRegistrationForm() {
  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;
  const phone = document.getElementById('phone').value;
  const password = document.getElementById('password').value;
  const confirmPassword = document.getElementById('confirm_password').value;

  // Basic validation checks
  if (!name || !email || !phone || !password || !confirmPassword) {
      alert("All fields are required.");
      return false;
  }

  if (password !== confirmPassword) {
      alert("Passwords do not match.");
      return false;
  }

  const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
  if (!emailRegex.test(email)) {
      alert("Please enter a valid email.");
      return false;
  }

  const phoneRegex = /^[0-9]{10}$/;
  if (!phoneRegex.test(phone)) {
      alert("Please enter a valid 10-digit phone number.");
      return false;
  }

  return true;
}

// Function to handle blood request form validation
function validateBloodRequestForm() {
  const bloodType = document.getElementById('blood_type').value;
  const quantity = document.getElementById('quantity').value;

  if (!bloodType || !quantity || isNaN(quantity) || quantity <= 0) {
      alert("Please provide a valid blood type and quantity.");
      return false;
  }

  return true;
}

// Function to handle blood request creation using AJAX
function createBloodRequest() {
  const bloodType = document.getElementById('blood_type').value;
  const quantity = document.getElementById('quantity').value;

  if (!validateBloodRequestForm()) {
      return;
  }

  const data = new FormData();
  data.append('blood_type', bloodType);
  data.append('quantity', quantity);

  const xhr = new XMLHttpRequest();
  xhr.open('POST', 'create_blood_request.php', true);
  xhr.onreadystatechange = function () {
      if (xhr.readyState == 4 && xhr.status == 200) {
          const response = JSON.parse(xhr.responseText);
          if (response.success) {
              alert('Blood request created successfully.');
              window.location.reload();  // Reload the page to show updated data
          } else {
              alert('Error creating blood request. Please try again.');
          }
      }
  };
  xhr.send(data);
}

// Function to handle AJAX request to cancel a blood request
function cancelBloodRequest(requestId) {
  if (confirm('Are you sure you want to cancel this request?')) {
      const data = new FormData();
      data.append('request_id', requestId);

      const xhr = new XMLHttpRequest();
      xhr.open('POST', 'cancel_request.php', true);
      xhr.onreadystatechange = function () {
          if (xhr.readyState == 4 && xhr.status == 200) {
              const response = JSON.parse(xhr.responseText);
              if (response.success) {
                  alert('Blood request cancelled successfully.');
                  window.location.reload();  // Reload the page to reflect the changes
              } else {
                  alert('Error cancelling blood request. Please try again.');
              }
          }
      };
      xhr.send(data);
  }
}

// Function to handle the form submission for login
function validateLoginForm() {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  if (!email || !password) {
      alert("Email and password are required.");
      return false;
  }

  return true;
}

// Function to handle the login form submission using AJAX
function loginUser() {
  if (!validateLoginForm()) {
      return;
  }

  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  const data = new FormData();
  data.append('email', email);
  data.append('password', password);

  const xhr = new XMLHttpRequest();
  xhr.open('POST', 'login.php', true);
  xhr.onreadystatechange = function () {
      if (xhr.readyState == 4 && xhr.status == 200) {
          const response = JSON.parse(xhr.responseText);
          if (response.success) {
              alert('Login successful.');
              window.location.href = 'dashboard.php';  // Redirect to dashboard after login
          } else {
              alert('Invalid login credentials. Please try again.');
          }
      }
  };
  xhr.send(data);
}

// Function to update blood stock using AJAX
function updateBloodStock() {
  const bloodType = document.getElementById('blood_type').value;
  const quantity = document.getElementById('quantity').value;

  if (isNaN(quantity) || quantity <= 0) {
      alert("Please enter a valid quantity.");
      return;
  }

  const data = new FormData();
  data.append('blood_type', bloodType);
  data.append('quantity', quantity);

  const xhr = new XMLHttpRequest();
  xhr.open('POST', 'update_blood_stock.php', true);
  xhr.onreadystatechange = function () {
      if (xhr.readyState == 4 && xhr.status == 200) {
          const response = JSON.parse(xhr.responseText);
          if (response.success) {
              alert('Blood stock updated successfully.');
              window.location.reload();  // Reload the page to show updated stock
          } else {
              alert('Error updating blood stock. Please try again.');
          }
      }
  };
  xhr.send(data);
}

// Function to dynamically load blood requests for admin
function loadBloodRequests() {
  const xhr = new XMLHttpRequest();
  xhr.open('GET', 'get_blood_requests.php', true);
  xhr.onreadystatechange = function () {
      if (xhr.readyState == 4 && xhr.status == 200) {
          const response = JSON.parse(xhr.responseText);
          const requestsTable = document.getElementById('requests_table');
          requestsTable.innerHTML = '';  // Clear previous content

          response.requests.forEach(function (request) {
              const row = document.createElement('tr');
              row.innerHTML = `
                  <td>${request.request_id}</td>
                  <td>${request.user_name}</td>
                  <td>${request.blood_type}</td>
                  <td>${request.quantity}</td>
                  <td>${request.status}</td>
                  <td><button onclick="cancelBloodRequest(${request.request_id})">Cancel</button></td>
              `;
              requestsTable.appendChild(row);
          });
      }
  };
  xhr.send();
}

// Load blood requests when the page loads
window.onload = function () {
  loadBloodRequests();
};

