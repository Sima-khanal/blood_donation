CREATE DATABASE blood_donation;
USE blood_donation;

-- Create the users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(15) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE donation (
    id INT AUTO_INCREMENT PRIMARY KEY,
    birthdate DATE NOT NULL,
    last_donated_date DATE NOT NULL,
    donation_date DATE NOT NULL,
    blood_type ENUM('A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-') NOT NULL,
    quantity_ml INT NOT NULL CHECK (quantity_ml BETWEEN 200 AND 500),
    weight_kg INT NOT NULL CHECK (weight_kg >= 50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
