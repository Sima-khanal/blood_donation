<?php
// footer.php

// You can include any global elements like database connections or user session logic here
?>
<script src="script.js"></script>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>

  <footer>
    <div class="footer-container">
      <!-- About NMC -->
      <div class="footer-about">
        <h3>Blood Donation </h3>
        <p>
          It is situated at Kathmandu, about 11 km. northeast of Kathmandu Valley.
        </p>
      </div>

      <!-- Quick Links -->
      <div class="footer-links">
        <h3>Quick Links</h3>
        <ul>
          <li><a href="index.php/#about">About Us</a></li>
          <li><a href="login.php">Login</a></li>
          <li><a href="request_blood.php"> Blood Request</a></li>
          <li><a href="view_request.php">View Request</a></li>
          <li><a href="#contact">Contact Us</a></li>
        </ul>
      </div>

      <!-- Contact Info -->
      <div class="footer-contact">
        <h3>Contact Info</h3>
        <p>+977-01-1234567</p>
        <p>knk@knk.edu</p>
        <p>Kathmandu, Nepal</p>
      </div>

      <!-- Newsletter -->
      <div class="footer-newsletter">
        <h3>Newsletter</h3>
        <form action="#" method="post">
          <input type="email" name="email" placeholder="Enter your email" required>
          <button type="submit">Subscribe</button>
        </form>
      </div>
    </div>

    <!-- Social Media Links -->
    <div class="footer-social">
      <ul>
        <li><a href="#" target="_blank"><img src="images/facebook-icon.png" alt="Facebook"></a></li>
        <li><a href="#" target="_blank"><img src="images/twitter-icon.png" alt="Twitter"></a></li>
        <li><a href="#" target="_blank"><img src="images/instagram-icon.png" alt="Instagram"></a></li>
        <li><a href="#" target="_blank"><img src="images/linkedin-icon.png" alt="LinkedIn"></a></li>
      </ul>
    </div>

    <div class="footer-bottom">
      <p>&copy; All Rights Reserved.</p>
    </div>
  </footer>

</body>

</html>