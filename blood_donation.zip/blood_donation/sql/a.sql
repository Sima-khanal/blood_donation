CREATE DATABASE IF NOT EXISTS blood_donation;

USE blood_donation;

CREATE TABLE donation (
    id INT AUTO_INCREMENT PRIMARY KEY,
    birthdate DATE NOT NULL,
    last_donated_date DATE NOT NULL,
    blood_type VARCHAR(3) NOT NULL,
    quantity_ml INT NOT NULL,
    weight_kg INT NOT NULL,
    health_declaration BOOLEAN NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE donation ADD health_declaration TINYINT(1) NOT NULL DEFAULT 0;


INSERT INTO donation (birthdate, last_donated_date, blood_type, quantity_ml, weight_kg)
VALUES ('1990-05-10', '2025-01-01', 'O+', 450, 65.50);



CREATE TABLE blood_stock (
    id INT AUTO_INCREMENT PRIMARY KEY,
    blood_type VARCHAR(5) NOT NULL,
    stock INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);INSERT INTO blood_stock (blood_type, stock) VALUES
('A+', 10),
('A-', 7),
('B+', 8),
('B-', 6),
('O+', 15),
('O-', 5),
('AB+', 12),
('AB-', 4);

-- Create the blood_donation database
CREATE DATABASE blood_donation;
USE blood_donation;

-- Create the users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(15) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Create the blood_donors table
CREATE TABLE blood_donors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    blood_type VARCHAR(5) NOT NULL,
    registered_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Create the blood_requests table
CREATE TABLE blood_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    blood_type VARCHAR(5) NOT NULL,
    contact_number VARCHAR(15) NOT NULL,
    message TEXT,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create the blood_stock table
CREATE TABLE blood_stock (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    blood_type VARCHAR(5) NOT NULL,
    contact_number VARCHAR(15) NOT NULL,
    message TEXT,
    status ENUM('available', 'out_of_stock') DEFAULT 'available',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert sample data into the users table
INSERT INTO users (name, email, phone, password, created_at)
VALUES
('Sima Khanal', 'prem@gmail.com', '9848327268', '$2y$10$KYyrTFbMW8050ViXe9xJ2uf9uP7JfZgv8zkkdsQDI4t...', '2025-01-11 21:43:06'),
('Sima Khanal', 'pre1m@gmail.com', '9848327268', '$2y$10$BdjDwgE/Cjh.ljBpSijp2OSwPhTBkUnkbcjliIF1MD5...', '2025-01-11 21:48:15'),
('Sima Khanal', 'm@gmail.com', '9848327268', '$2y$10$3kzJT4EDb4EU9eNJuTyVjOkIYLrUmn3DvIWt895Y1TT...', '2025-01-11 22:13:00');

-- Insert sample data into the blood_donors table
INSERT INTO blood_donors (name, email, phone, blood_type, registered_at)
VALUES
('Sima Khanal', 'seemakhanal608@gmail.com', '9848327268', 'B-', '2025-01-11 21:28:49'),
('Sima Khanal', 'makhanal608@gmail.com', '9848327268', 'O+', '2025-01-11 21:30:22');

-- Insert sample data into the blood_requests table
INSERT INTO blood_requests (user_id, blood_type, contact_number, message, status, created_at)
VALUES
(4, 'A+', '9848327268', 'ktrfds', 'approved', '2025-01-12 14:01:19');

-- Insert sample data into the blood_stock table
INSERT INTO blood_stock (user_id, blood_type, contact_number, message, status, created_at)
VALUES
(4, 'A+', '9848327268', 'ktrfds', 'approved', '2025-01-12 14:01:19');
