<?php
// Include database connection
include('db.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $errors = [];

    // Retrieve and sanitize form data
    $donation_date = isset($_POST['donation_date']) ? trim($_POST['donation_date']) : '';
    $birthdate = isset($_POST['birthdate']) ? trim($_POST['birthdate']) : '';
    $last_donated_date = isset($_POST['last_donated_date']) ? trim($_POST['last_donated_date']) : '';
    $blood_type = isset($_POST['blood_type']) ? trim($_POST['blood_type']) : '';
    $weight = isset($_POST['weight']) ? (int)$_POST['weight'] : 0;
    $health_declaration = isset($_POST['health_declaration']) ? 1 : 0;

    // Validate health declaration
    if (!$health_declaration) {
        $errors[] = "You must declare that you are fit to donate blood.";
    }

    // Validate birthdate (age between 18-50)
    $birthdate_obj = new DateTime($birthdate);
    $current_date = new DateTime();
    $age = $current_date->diff($birthdate_obj)->y;
    if ($age < 18 || $age > 50) {
        $errors[] = "You must be between 18 and 50 years old to donate blood.";
    }

    // Validate last donated date (at least 3 months ago)
    $last_donated_obj = new DateTime($last_donated_date);
    if ($current_date->diff($last_donated_obj)->days < 90) {
        $errors[] = "You must wait at least 3 months between donations.";
    }

    // Validate donation date (future date)
    $donation_date_obj = new DateTime($donation_date);
    if ($donation_date_obj < $current_date) {
        $errors[] = "The appointment date cannot be in the past.";
    }

    // Validate weight (minimum 50 kg)
    if ($weight < 50) {
        $errors[] = "You must weigh at least 50 kg to donate blood.";
    }

    // If no errors, insert data into the database
    if (empty($errors)) {
        $sql = "INSERT INTO donation (birthdate, last_donated_date, donation_date, blood_type, weight_kg) 
                VALUES (?, ?, ?, ?, ?)";

        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("ssssi", $birthdate, $last_donated_date, $donation_date, $blood_type, $weight);
            if ($stmt->execute()) {
                echo "<script>alert('Thank you for your donation! Your data has been successfully recorded.');</script>";
            } else {
                echo "<p style='color: red;'>Error: " . $stmt->error . "</p>";
            }
            $stmt->close();
        } else {
            echo "<p style='color: red;'>Database error: " . $conn->error . "</p>";
        }
    } else {
        foreach ($errors as $error) {
            echo "<p style='color: red;'>$error</p>";
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Donation Form</title>
    <style>
        * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background: #f0f0f0;
}

/* Glass Effect Navbar */
.glass-navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 30px;
    background: rgba(255, 255, 255, 0.2);
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(10px);
    position: sticky;
    top: 0;
    z-index: 1000;
}

.navbar-left h1 {
    font-size: 24px;
    color: #ff4d4d;
}

.navbar-right ul {
    list-style: none;
    display: flex;
    gap: 20px;
}

.navbar-right ul li {
    display: inline;
}

.navbar-right ul li a {
    text-decoration: none;
    color: #333;
    font-weight: bold;
    padding: 8px 15px;
    border-radius: 20px;
    transition: 0.3s;
}

.navbar-right ul li a:hover {
    background: rgba(255, 77, 77, 0.2);
    color: #ff4d4d;
}
        form {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            margin: auto;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            font-weight: bold;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        .error {
            color: red;
            font-size: 12px;
        }
    </style>
</head>
<body>
    
    <nav class="glass-navbar">
        <div class="navbar-left">
            <h1>Blood Donation System</h1>
        </div>
            <div class="navbar-right">
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="request_blood.php">Request</a></li>
            <li><a href="blood_donation.php">Donation</a></li>
            <li><a href="view_requests.php">View Request Status</a></li>
            <li><a href="view_donation_status.php">Donation Status</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>
    </nav>

    <form id="donation-form" method="POST" action="blood_donation.php">
    <div class="form-group">
        <label for="birthdate">Birthdate:</label>
        <input type="date" id="birthdate" name="birthdate" required>
    </div>

    <div class="form-group">
        <label for="last_donated_date">Last Donated Date:</label>
        <input type="date" id="last_donated_date" name="last_donated_date" required>
    </div>

    <div class="form-group">
        <label for="donation_date">Appointment Date:</label>
        <input type="date" id="donation_date" name="donation_date" required>
    </div>

    <div class="form-group">
        <label for="blood_type">Blood Type:</label>
        <select id="blood_type" name="blood_type" required>
            <option value="A+">A+</option>
            <option value="A-">A-</option>
            <option value="B+">B+</option>
            <option value="B-">B-</option>
            <option value="O+">O+</option>
            <option value="O-">O-</option>
            <option value="AB+">AB+</option>
            <option value="AB-">AB-</option>
        </select>
    </div>

    <div class="form-group">
        <label for="weight">Weight (kg):</label>
        <input type="number" id="weight" name="weight" min="50" required>
    </div>

    <div class="form-group">
        <input type="checkbox" id="health_declaration" name="health_declaration" required>
        <label for="health_declaration">I declare that I am fit to donate blood.</label>
    </div>

    <button type="submit">Submit</button>
</form>

    <script>
        document.getElementById("donation-form").addEventListener("submit", function (event) {
            const today = new Date();
            let valid = true;

            // Clear previous errors
            document.querySelectorAll(".error").forEach(el => el.textContent = "");

            // Validate Birthdate
            const birthdate = new Date(document.getElementById("birthdate").value);
            const age = today.getFullYear() - birthdate.getFullYear();
            if (age < 18 || age > 50) {
                document.getElementById("age-error").textContent = "Age must be between 18 and 50.";
                valid = false;
            }

            // Validate Last Donated Date
            const lastDonated = new Date(document.getElementById("last_donated_date").value);
            if ((today - lastDonated) / (1000 * 3600 * 24) < 90) {
                document.getElementById("last-donation-error").textContent = "You must wait 3 months after your last donation.";
                valid = false;
            }

            // Validate Appointment Date
            const appointmentDate = new Date(document.getElementById("donation_date").value);
            if (appointmentDate < today) {
                document.getElementById("appointment-error").textContent = "Appointment date cannot be in the past.";
                valid = false;
            }

            // Validate Weight
            const weight = document.getElementById("weight").value;
            if (weight < 50) {
                document.getElementById("weight-error").textContent = "Weight must be at least 50 kg.";
                valid = false;
            }

            // Validate Quantity
            // const quantity = document.getElementById("quantity").value;
            // if (quantity < 200 || quantity > 500) {
            //     document.getElementById("quantity-error").textContent = "Quantity must be between 200 and 500 ml.";
            //     valid = false;
            // }

            if (!valid) {
                event.preventDefault();
            }
        });
    </script>
   <?php include('footer.php');?>
</body>
</html>
