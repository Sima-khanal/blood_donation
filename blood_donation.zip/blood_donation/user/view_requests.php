<?php
session_start();

// Include the database connection
include('db.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM blood_requests WHERE user_id = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Delete a request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && isset($_POST['request_id'])) {
    $request_id = $_POST['request_id'];
    $action = $_POST['action'];

    if ($action == "delete") {
        // Delete the request only if it's not accepted
        $stmt = $conn->prepare("SELECT status FROM blood_requests WHERE id = ?");
        $stmt->bind_param("i", $request_id);
        $stmt->execute();
        $stmt->bind_result($status);
        $stmt->fetch();
        $stmt->close();

        if ($status != "Accepted") {
            // Proceed to delete
            $stmt = $conn->prepare("DELETE FROM blood_requests WHERE id = ?");
            $stmt->bind_param("i", $request_id);
            if ($stmt->execute()) {
                $success_message = "Request deleted successfully!";
            } else {
                $error_message = "Error: Could not delete the request.";
            }
            $stmt->close();
        } else {
            $error_message = "Cannot delete the request once it's accepted.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User - View Blood Requests</title>
  <style>
        body {
            background: #f0f0f0;
        }

        /* Glass Effect Navbar */
        .glass-navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            background: rgba(255, 255, 255, 0.2);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .navbar-left h1 {
            font-size: 24px;
            color: #ff4d4d;
        }

        .navbar-right ul {
            list-style: none;
            display: flex;
            gap: 20px;
        }

        .navbar-right ul li {
            display: inline;
        }

        .navbar-right ul li a {
            text-decoration: none;
            color: #333;
            font-weight: bold;
            padding: 8px 15px;
            border-radius: 20px;
            transition: 0.3s;
        }

        .navbar-right ul li a:hover {
            background: rgba(255, 77, 77, 0.2);
            color: #ff4d4d;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .glass-navbar {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }

            .navbar-right ul {
                flex-direction: column;
                gap: 10px;
            }
        }

        /* Table styles */
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: center;
        }

        .action-buttons button {
            padding: 5px 10px;
            margin: 5px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        .success-message {
            color: green;
        }

        .error-message {
            color: red;
        }

        /* Status Colors */
        .pending {
            color: orange;
            font-weight: bold;
        }

        .accepted {
            color: green;
            font-weight: bold;
        }

        .rejected {
            color: red;
            font-weight: bold;
        }

        /* Delete Button */
        .delete-btn {
            background-color: red;
            color: white;
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            transition: 0.3s;
        }

        .delete-btn:hover {
            background-color: darkred;
        }

  </style>
</head>

<body>

  <nav class="glass-navbar">
        <div class="navbar-left">
            <h1>Blood Donation System</h1>
        </div>
        <div class="navbar-right">
         <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="request_blood.php">Request</a></li>
            <li><a href="blood_donation.php">Donation</a></li>
            <li><a href="view_requests.php">View Request Status</a></li>
            <li><a href="view_donation_status.php">Donation Status</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
        </div>
    </nav>

  <section id="view-requests-section">
    <div class="request-container">
        <h2>Your Blood Donation Requests</h2>
        <?php
        if (isset($success_message)) {
            echo '<p class="success-message">' . $success_message . '</p>';
        }
        if (isset($error_message)) {
            echo '<p class="error-message">' . $error_message . '</p>';
        }
        ?>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Blood Type</th>
                    <th>Contact Number</th>
                    <th>Message</th>
                    <th>Quantity</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['blood_type'] . "</td>";
                        echo "<td>" . $row['contact_number'] . "</td>";
                        echo "<td>" . $row['message'] . "</td>";
                        echo "<td>" . $row['quantity'] . "</td>";

                        // Apply class-based status colors
                        $statusClass = strtolower($row['status']); // Convert to lowercase class
                        echo "<td class='$statusClass'>" . $row['status'] . "</td>";

                        echo "<td class='action-buttons'>";

                        // Show delete button if status is not "Accepted"
                        if ($row['status'] != 'Accepted') {
                            echo "<form method='POST' style='display:inline;'>
                                    <input type='hidden' name='request_id' value='" . $row['id'] . "'>
                                    <button type='submit' name='action' value='delete' class='delete-btn'>Delete</button>
                                  </form>";
                        }

                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No requests found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
  </section>

  <?php include('footer.php'); ?>

</body>

</html>
