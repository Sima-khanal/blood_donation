<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Donation System</title>
<style>
 * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background: #f0f0f0;
}

/* Glass Effect Navbar */
.glass-navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 30px;
    background: rgba(255, 255, 255, 0.2);
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(10px);
    position: sticky;
    top: 0;
    z-index: 1000;
}

.navbar-left h1 {
    font-size: 24px;
    color: #ff4d4d;
}

.navbar-right ul {
    list-style: none;
    display: flex;
    gap: 20px;
}

.navbar-right ul li {
    display: inline;
}

.navbar-right ul li a {
    text-decoration: none;
    color: #333;
    font-weight: bold;
    padding: 8px 15px;
    border-radius: 20px;
    transition: 0.3s;
}

.navbar-right ul li a:hover {
    background: rgba(255, 77, 77, 0.2);
    color: #ff4d4d;
}

/* Hero Section */
.hero-section {
    height: 100vh;
    background: url('https://i.pinimg.com/1200x/50/29/17/5029178336d066378befb7f09ee6d72e.jpg') no-repeat center center/cover;
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    position: relative;
}

.hero-section::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 1;
}

.hero-content {
    position: relative;
    z-index: 2;
    padding: 20px 40px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
}

.hero-content h1 {
    font-size: 36px;
    color: #ff4d4d;
    margin-bottom: 10px;
}

.hero-content p {
    font-size: 20px;
    color: #333;
}

.about-us-section {
    padding: 50px 20px;
    background-color: #f9f9f9;
}

.about-us-container {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 30px;
    max-width: 1200px;
    margin: 0 auto;
    flex-wrap: wrap; /* For responsiveness */
}

.about-us-photo img {
    width: 100%;
    max-width: 500px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
}

.about-us-content {
    max-width: 600px;
    text-align: left;
}

.about-us-content h2 {
    font-size: 28px;
    color: #ff4d4d; /* Blood donation theme */
    margin-bottom: 10px;
}

.about-us-content h3 {
    font-size: 22px;
    color: #333;
    margin-bottom: 20px;
}

.about-us-content p {
    font-size: 18px;
    line-height: 1.6;
    color: #555;
}

.possibilities-section {
    padding: 50px 20px;
    background-color: #fff;
}

.possibilities-container {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 30px;
    max-width: 1200px;
    margin: 0 auto;
    flex-wrap: wrap; /* Makes it responsive */
}

.possibilities-content {
    max-width: 600px;
    text-align: left;
}

.possibilities-content h2 {
    font-size: 28px;
    color: #ff4d4d; /* Blood donation theme */
    margin-bottom: 15px;
}

.possibilities-content p {
    font-size: 18px;
    line-height: 1.6;
    color: #555;
    margin-bottom: 20px;
}

.possibilities-content ul {
    list-style-type: disc;
    padding-left: 20px;
}

.possibilities-content ul li {
    font-size: 18px;
    color: #333;
    margin-bottom: 10px;
}

.possibilities-photo img {
    width: 100%;
    max-width: 500px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
}

.three-column-section {
    padding: 50px 20px;
    background-color: #f9f9f9;
}

.three-column-container {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 20px;
    max-width: 1200px;
    margin: 0 auto;
    flex-wrap: wrap; /* Responsive design */
}

.column {
    flex: 1;
    min-width: 300px; /* Ensures proper sizing on smaller screens */
    padding: 20px;
    background: #fff;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    text-align: left;
}

.column h2 {
    font-size: 22px;
    color: #ff4d4d; /* Blood donation theme color */
    margin-bottom: 15px;
}

.column p {
    font-size: 16px;
    color: #555;
    line-height: 1.5;
    margin-bottom: 10px;
}

.column ul {
    list-style-type: disc;
    padding-left: 20px;
    font-size: 16px;
    color: #333;
}

.column ul li {
    margin-bottom: 8px;
}

.contact p span {
    font-family: 'Font Awesome 5 Free'; /* Add Font Awesome */
    font-weight: 900;
    margin-right: 8px;
    color: #ff4d4d;
}

.contact p {
    font-size: 16px;
}

/* Contact Form Section Styling */
#Contact {
    padding: 60px 20px;
    background-color: #f9f9f9;
}

.container.form-container {
    max-width: 600px;
    margin: 0 auto;
    background: #fff;
    padding: 30px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.form-title {
    font-size: 24px;
    font-weight: bold;
    color: #ff4d4d; /* Blood donation theme */
    margin-bottom: 20px;
    text-transform: uppercase;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    font-size: 16px;
    font-weight: bold;
    margin-bottom: 8px;
    color: #333;
}
.form-group input,
.form-group textarea {
    width: 100%;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ddd;
    border-radius: 5px;
    outline: none;
    box-sizing: border-box;
    transition: border-color 0.3s ease-in-out;
}

.form-group input:focus,
.form-group textarea:focus {
    border-color: #ff4d4d; /* Highlight border on focus */
    box-shadow: 0 0 5px rgba(255, 77, 77, 0.3);
}

textarea.form-control {
    resize: vertical; /* Allow vertical resizing only */
    min-height: 100px;
}

.btn {
    display: inline-block;
    background-color: #ff4d4d;
    color: #fff;
    padding: 10px 20px;
    font-size: 16px;
    font-weight: bold;
    text-align: center;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
}

.btn:hover {
    background-color: #e63939;
}

/* Responsive Design */
@media (max-width: 768px) {
    .container.form-container {
        padding: 20px;
    }

    .form-title {
        font-size: 20px;
    }

    .btn {
        width: 100%;
        padding: 12px;
    }
}

/* Footer Styling */
.footer {
    background-color: #222; /* Dark background for footer */
    color: #fff;
    padding: 20px 10px;
    font-size: 14px;
}

.footer-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    max-width: 1200px;
    margin: 0 auto;
}

.footer-left {
    font-size: 14px;
    color: #ccc;
}

.footer-left p {
    margin: 0;
}

.footer-right a {
    color: #ccc;
    font-size: 18px;
    margin-left: 15px;
    text-decoration: none;
    transition: color 0.3s ease-in-out;
}

.footer-right a:hover {
    color: #ff4d4d; /* Highlight effect on hover */
}

/* Responsive Design */
@media (max-width: 768px) {
    .footer-container {
        flex-direction: column;
        text-align: center;
        gap: 10px;
    }

    .footer-right a {
        margin: 0 10px;
    }
}


</style>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

</head>
<body>
    <nav class="glass-navbar">
        <div class="navbar-left">
            <h1>Blood Donation System</h1>
        </div>
        <div class="navbar-right">
            <ul>
                <li><a href="#about">ABOUT</a></li>
                <li><a href="#services">SERVICES</a></li>
                <li><a href="#contact">CONTACT</a></li>
                <li><a href="register.php"></a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </div>
    </nav>

    <section class="hero-section">
        <div class="hero-content">
            <h1>Welcome to Blood Donation System</h1>
            <p>Saving Lives Through Blood Donation</p>
        </div>
    </section>

    <section class="about-us-section" id="about">
    <div class="about-us-container">
        <div class="about-us-photo">
            <img src="https://i.pinimg.com/736x/2c/22/3b/2c223bd99c7f20ac821d77f760cdf5a2.jpg" alt="About Us Image">
        </div>
        <div class="about-us-content">
            <h2>ABOUT US</h2>
            <h3>Saving Lives Through Blood Donation</h3>
            <p>
                Our platform enables administrators to effectively manage blood inventory and facilitate donation requests, 
                while also providing users with a seamless process to request and receive blood donations.
            </p>
        </div>
    </div>
</section>

<section class="possibilities-section" id="services" >
    <div class="possibilities-container">
        <div class="possibilities-content">
            <h2>Endless Possibilities</h2>
            <p>
                Our platform enables administrators to effectively manage blood inventory and facilitate donation requests, 
                while also providing users with a seamless process to request and receive blood donations.
            </p>
            <ul>
                <li><strong>Blood Inventory Management</strong></li>
                <li><strong>Donation Request Management</strong></li>
                <li><strong>Donor Verification and Matching</strong></li>
            </ul>
        </div>
        <div class="possibilities-photo">
            <img src="https://i.pinimg.com/736x/87/46/5d/87465d9dfc6d19aad478cd332602f916.jpg" alt="Endless Possibilities Image">
        </div>
    </div>
</section>
<section class="three-column-section">
    <div class="three-column-container">
        <!-- Left: Company Overview -->
        <div class="column overview">
            <h2>Company Overview</h2>
            <p>
                With a commitment to excellence and customer satisfaction, we strive to deliver premium quality and 
                innovative solutions tailored to meet your needs.
            </p>
        </div>

        <!-- Center: Contact -->
        <div class="column contact">
            <h2>Contact</h2>
            <p><span></span> Blood Donation System, Kapan Kathmandu</p>
            <p><span></span> 999 673 984</p>
            <p><span></span> support@yourdomain.com</p>
        </div>

        <!-- Right: Services -->
        <div class="column services">
            <h2>Services</h2>
            <ul>
                <li>Donation Request Management</li>
                <li>Donor Verification and Matching</li>
                <li>Donor Engagement and Recognition</li>
            </ul>
        </div>
    </div>
</section>
<section id="contact">
    <div class="container form-container">
        <h2 class="form-title">Contact Us</h2>
        <form id="contactForm" onsubmit="return validateForm(event)">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" placeholder="Your Name">
                <small id="nameError" style="color: red;"></small>
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="Your Email">
                <small id="emailError" style="color: red;"></small>
            </div>

            <div class="form-group">
                <label for="message">Message</label>
                <textarea id="message" name="message" placeholder="Your Message"></textarea>
                <small id="messageError" style="color: red;"></small>
            </div>

            <button type="submit" class="btn">Submit</button>
        </form>
    </div>
</section>

<script>
    function validateForm(event) {
        event.preventDefault(); // Prevent form submission for validation

        // Clear previous errors
        document.getElementById("nameError").innerText = "";
        document.getElementById("emailError").innerText = "";
        document.getElementById("messageError").innerText = "";

        let isValid = true;

        // Name Validation
        const name = document.getElementById("name").value;
        if (name.trim() === "") {
            document.getElementById("nameError").innerText = "Name is required";
            isValid = false;
        }

        // Email Validation
        const email = document.getElementById("email").value;
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!emailRegex.test(email)) {
            document.getElementById("emailError").innerText = "Please enter a valid email";
            isValid = false;
        }

        // Message Validation
        const message = document.getElementById("message").value;
        if (message.trim() === "") {
            document.getElementById("messageError").innerText = "Message cannot be empty";
            isValid = false;
        }

        // If form is valid, submit it
        if (isValid) {
            alert("Form submitted successfully!");
            document.getElementById("contactForm").submit(); // Submit form if all validations are passed
        }

        return isValid; // Prevent form submission if any validation fails
    }
</script>
<footer class="footer">
  <div class="footer-container">
    <!-- Left Side: Copyright Text -->
    <div class="footer-left">
      <p>Copyright © 2025 All Rights Reserved. Made by SD Creation</p>
    </div>

    <!-- Right Side: Social Media Icons -->
    <div class="footer-right">
      <a href="https://facebook.com" target="_blank" aria-label="Facebook">
        <i class="fab fa-facebook"></i>
      </a>
      <a href="https://instagram.com" target="_blank" aria-label="Instagram">
        <i class="fab fa-instagram"></i>
      </a>
      <a href="mailto:support@yourdomain.com" aria-label="Mail">
        <i class="fas fa-envelope"></i>
      </a>
    </div>
  </div>
</footer>

</body>
</html>
