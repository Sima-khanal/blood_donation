<?php
// Start the session to access session variables
session_start();

// Include the header
include('header.php');

// Include the database connection file
include('db.php');

// Ensure $conn is initialized
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Fetch the logged-in user's real name
$real_name = 'User'; // Default fallback name
$username = '';

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
    $query = "SELECT real_name FROM users WHERE username = ?";
    $stmt = $conn->prepare($query);

    if ($stmt) {
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->bind_result($real_name);
        if ($stmt->fetch()) {
            // If real name is found, set it
            $real_name = $real_name;
        }
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
} else {
    // If username is not set, display a default message
    $real_name = 'Guest';
}

// Fetch the count of blood requests
$blood_request_count = 0;
$query = "SELECT COUNT(*) FROM blood_requests";
$result = mysqli_query($conn, $query);
if ($result) {
    $row = mysqli_fetch_row($result);
    $blood_request_count = $row[0];
} else {
    echo "Error fetching blood request count: " . mysqli_error($conn);
}

// Close the database connection
$conn->close();
?>

<style>
 /* General Reset */
body {
    margin: 0;
    font-family: Arial, sans-serif;
    line-height: 1.6;
    color: #333;
}

/* Hero Section */
.hero-section {
    text-align: center;
    background: linear-gradient(to bottom, #f44336, #e57373);
    color: white;
    padding: 50px 20px;
}

.hero-section h1 {
    font-size: 2.5rem;
    margin-bottom: 10px;
}

.hero-section p {
    font-size: 1.2rem;
}

/* About Us Section */
.about-us-section {
    display: flex;
    flex-wrap: wrap;
    padding: 50px 20px;
    background: #f7f7f7;
    gap: 20px;
}

.about-us-container {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
    max-width: 1200px;
    margin: 0 auto;
    gap: 20px;
}

.about-us-photo img {
    width: 100%;
    max-width: 400px;
    border-radius: 10px;
}

.about-us-content {
    flex: 1;
    max-width: 600px;
}

.about-us-content h2 {
    font-size: 2rem;
    color: #f44336;
}

.about-us-content h3 {
    font-size: 1.5rem;
    margin: 10px 0;
}

.about-us-content p {
    font-size: 1rem;
}

/* Possibilities Section */
.possibilities-section {
    display: flex;
    flex-wrap: wrap;
    padding: 50px 20px;
    background: white;
    gap: 20px;
}

.possibilities-container {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
    max-width: 1200px;
    margin: 0 auto;
    gap: 20px;
}

.possibilities-photo img {
    width: 100%;
    max-width: 400px;
    border-radius: 10px;
}

.possibilities-content {
    flex: 1;
    max-width: 600px;
}

.possibilities-content h2 {
    font-size: 2rem;
    color: #f44336;
}

.possibilities-content p {
    font-size: 1rem;
}

/* Three Column Section */
.three-column-section {
    background: #f7f7f7;
    padding: 50px 20px;
}

.three-column-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    max-width: 1200px;
    margin: 0 auto;
    gap: 20px;
}

.column {
    flex: 1;
    min-width: 280px;
    background: white;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.column h2 {
    font-size: 1.5rem;
    color: #f44336;
    margin-bottom: 10px;
}

.column p {
    font-size: 1rem;
    margin-bottom: 10px;
}

.column ul {
    list-style: none;
    padding: 0;
}

.column ul li {
    margin-bottom: 10px;
    padding-left: 20px;
    position: relative;
}

.column ul li::before {
    content: "✔";
    position: absolute;
    left: 0;
    color: #f44336;
}

/* Responsive Design */
@media (max-width: 768px) {
    .about-us-container, .possibilities-container, .three-column-container {
        flex-direction: column;
        align-items: center;
    }

    .about-us-content, .possibilities-content {
        text-align: center;
    }

    .about-us-content h2, .possibilities-content h2 {
        font-size: 1.8rem;
    }

    .about-us-photo img, .possibilities-photo img {
        max-width: 300px;
    }
}

@media (max-width: 480px) {
    .hero-section h1 {
        font-size: 2rem;
    }

    .hero-section p {
        font-size: 1rem;
    }

    .about-us-content h2, .possibilities-content h2 {
        font-size: 1.5rem;
    }

    .column {
        min-width: 100%;
    }
}


</style>
 

    <section class="hero-section">
        <div class="hero-content">
            <h1>Welcome to Blood Donation System</h1>
            <p>Join us in saving lives with blood donation</p>
        </div>
    </section>

    <section class="about-us-section">
        <div class="about-us-container">
            <div class="about-us-photo">
                <img src="https://i.pinimg.com/236x/c9/14/c6/c914c63a80aa1db05328f07054afd299.jpg" alt="Blood Donation">
            </div>
            <div class="about-us-content">
                <h2>About Us</h2>
                <h3>Making a Difference in Lives</h3>
                <p>Our mission is to ensure a constant supply of blood for patients in need, creating a better world for all.</p>
            </div>
        </div>
    </section>

    <section class="possibilities-section">
        <div class="possibilities-container">
            <div class="possibilities-content">
                <h2>Why Donate Blood?</h2>
                <p>Blood donation saves lives. You can make a difference by donating blood, helping hospitals and clinics with their needs.</p>
            </div>
            <div class="possibilities-photo">
                <img src="https://i.pinimg.com/736x/dc/b9/e5/dcb9e58f141142179a84c350f820f496.jpg" alt="Donate Blood">
            </div>
        </div>
    </section>

    <section class="three-column-section">
        <div class="three-column-container">
            <div class="column">
                <h2>How It Works</h2>
                <p>Learn the process of blood donation from registration to donation.</p>
                <ul>
                    <li>Step 1: Register as a donor</li>
                    <li>Step 2: Attend a donation camp</li>
                    <li>Step 3: Make a difference</li>
                </ul>
            </div>
            <div class="column">
                <h2>Get Involved</h2>
                <p>Explore ways to get involved in our blood donation drives and events.</p>
                <ul>
                    <li>Host a donation camp</li>
                    <li>Spread awareness about blood donation</li>
                    <li>Volunteer for events</li>
                </ul>
            </div>
            <div class="column">
                <h2>Request Blood</h2>
                <p>If you need blood for medical purposes, you can request it from our database of registered donors.</p>
                <ul>
                    <li>Fill out the blood request form</li>
                    <li>We will match you with available donors</li>
                    <li>Get in touch with the donor for blood collection</li>
                </ul>
            </div>
        </div>
    </section>

  <?php include('footer.php'); ?>
</body>
</html>
