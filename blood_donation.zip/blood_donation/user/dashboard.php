<?php


// Include the header
include('header.php');
?>
<style>
  /* General Styling for User Dashboard */
  #user-dashboard {
    background-color: #f9f9f9;
    /* Light background for the dashboard */
    padding: 20px;
    font-family: Arial, sans-serif;
  }

  .dashboard-container {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
    /* Ensures responsive layout */
  }

  /* Main Content Area */
  #main-content {
    flex: 1;
    background-color: #fff;
    /* White background for content */
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    /* Subtle shadow for elevation */
    padding: 20px;
  }

  /* Header Styling */
  .main-content-header {
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid #ddd;
  }

  .admin-info h2 {
    font-size: 24px;
    color: #333;
    margin: 0;
  }

  .admin-info p {
    color: #666;
    margin-top: 5px;
    font-size: 14px;
  }

  /* Overview Items */
  .overview-item {
    background-color: #e8f5e9;
    /* Light green background */
    border: 1px solid #c8e6c9;
    /* Border for better distinction */
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 20px;
    text-align: center;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
  }

  .overview-item:hover {
    transform: translateY(-5px);
    /* Slight lift effect */
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
  }

  .overview-item a {
    text-decoration: none;
    color: #333;
  }

  .overview-item h3 {
    margin: 0;
    font-size: 20px;
    color: #2e7d32;
    /* Green text */
  }

  .overview-item p {
    margin: 10px 0 0;
    font-size: 18px;
    font-weight: bold;
    color: #1b5e20;
  }

  /* Responsive Design */
  @media (max-width: 768px) {
    .dashboard-container {
      flex-direction: column;
      /* Stack items vertically */
    }

    .overview-item {
      margin: 0 auto 20px;
      /* Center overview items */
      width: 100%;
      /* Full-width for smaller screens */
    }
  }
</style>

<!-- Admin Dashboard Section -->
<section id="user-dashboard">
  <div class="dashboard-container">
    <!-- Sidebar -->

    <!-- Main Content Area -->
    <main id="main-content">
      <div class="main-content-header">
        <div class="admin-info">
          <h2>Welcome, User!</h2>
          <p>Manage the blood donation system with ease.</p>
        </div>

      </div>

      <!-- Dashboard Overview -->
      <div class="overview-item">
        <a href="request_blood.php">
          <h3>Blood Request</h3>
          <p>120</p>
        </a>
      </div>

      <div class="overview-item">
        <a href="view_requests.php">
          <h3>View Request</h3>
          <p>15</p>
        </a>
      </div>

  </div>
  </main>
  </div>
</section>


<script src="script.js"></script>

<?php
// Include the footer
include('footer.php');
?>