<?php
// Start the session to access session variables
session_start();

// Include the header
include('header.php');

// Include the database connection file
include('db.php');

// Ensure $conn is initialized
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Fetch the logged-in user's real name
$real_name = 'User'; // Default fallback name
$username = '';

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
    $query = "SELECT real_name FROM users WHERE username = ?";
    $stmt = $conn->prepare($query);

    if ($stmt) {
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->bind_result($real_name);
        if ($stmt->fetch()) {
            // If real name is found, set it
            $real_name = $real_name;
        }
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
} else {
    // If username is not set, display a default message
    $real_name = 'Guest';
}

// Fetch the count of blood requests
$blood_request_count = 0;
$query = "SELECT COUNT(*) FROM blood_requests";
$result = mysqli_query($conn, $query);
if ($result) {
    $row = mysqli_fetch_row($result);
    $blood_request_count = $row[0];
} else {
    echo "Error fetching blood request count: " . mysqli_error($conn);
}

// Close the database connection
$conn->close();
?>

<style>
  /* Hero Section */
.hero-section {
    height: 100vh;
    background: url('https://i.pinimg.com/1200x/50/29/17/5029178336d066378befb7f09ee6d72e.jpg') no-repeat center center/cover;
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    position: relative;
}

.hero-section::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 1;
}

.hero-content {
    position: relative;
    z-index: 2;
    padding: 20px 40px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
}

.hero-content h1 {
    font-size: 36px;
    color: #ff4d4d;
    margin-bottom: 10px;
}

.hero-content p {
    font-size: 20px;
    color: #333;
}

.about-us-section {
    padding: 50px 20px;
    background-color: #f9f9f9;
}

.about-us-container {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 30px;
    max-width: 1200px;
    margin: 0 auto;
    flex-wrap: wrap; /* For responsiveness */
}

.about-us-photo img {
    width: 100%;
    max-width: 500px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
}

.about-us-content {
    max-width: 600px;
    text-align: left;
}

.about-us-content h2 {
    font-size: 28px;
    color: #ff4d4d; /* Blood donation theme */
    margin-bottom: 10px;
}

.about-us-content h3 {
    font-size: 22px;
    color: #333;
    margin-bottom: 20px;
}

.about-us-content p {
    font-size: 18px;
    line-height: 1.6;
    color: #555;
}

.possibilities-section {
    padding: 50px 20px;
    background-color: #fff;
}

.possibilities-container {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 30px;
    max-width: 1200px;
    margin: 0 auto;
    flex-wrap: wrap; /* Makes it responsive */
}

.possibilities-content {
    max-width: 600px;
    text-align: left;
}

.possibilities-content h2 {
    font-size: 28px;
    color: #ff4d4d; /* Blood donation theme */
    margin-bottom: 15px;
}

.possibilities-content p {
    font-size: 18px;
    line-height: 1.6;
    color: #555;
    margin-bottom: 20px;
}

.possibilities-content ul {
    list-style-type: disc;
    padding-left: 20px;
}

.possibilities-content ul li {
    font-size: 18px;
    color: #333;
    margin-bottom: 10px;
}

.possibilities-photo img {
    width: 100%;
    max-width: 500px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
}

.three-column-section {
    padding: 50px 20px;
    background-color: #f9f9f9;
}

.three-column-container {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 20px;
    max-width: 1200px;
    margin: 0 auto;
    flex-wrap: wrap; /* Responsive design */
}

.column {
    flex: 1;
    min-width: 300px; /* Ensures proper sizing on smaller screens */
    padding: 20px;
    background: #fff;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    text-align: left;
}

.column h2 {
    font-size: 22px;
    color: #ff4d4d; /* Blood donation theme color */
    margin-bottom: 15px;
}

.column p {
    font-size: 16px;
    color: #555;
    line-height: 1.5;
    margin-bottom: 10px;
}

.column ul {
    list-style-type: disc;
    padding-left: 20px;
    font-size: 16px;
    color: #333;
}

.column ul li {
    margin-bottom: 8px;
}

.contact p span {
    font-family: 'Font Awesome 5 Free'; /* Add Font Awesome */
    font-weight: 900;
    margin-right: 8px;
    color: #ff4d4d;
}

.contact p {
    font-size: 16px;
}

/* Contact Form Section Styling */
#Contact {
    padding: 60px 20px;
    background-color: #f9f9f9;
}

.container.form-container {
    max-width: 600px;
    margin: 0 auto;
    background: #fff;
    padding: 30px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.form-title {
    font-size: 24px;
    font-weight: bold;
    color: #ff4d4d; /* Blood donation theme */
    margin-bottom: 20px;
    text-transform: uppercase;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    font-size: 16px;
    font-weight: bold;
    margin-bottom: 8px;
    color: #333;
}

.form-group input,
.form-group textarea {
    width: 100%;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ddd;
    border-radius: 5px;
    outline: none;
    box-sizing: border-box;
    transition: border-color 0.3s ease-in-out;
}

.form-group input:focus,
.form-group textarea:focus {
    border-color: #ff4d4d; /* Highlight border on focus */
    box-shadow: 0 0 5px rgba(255, 77, 77, 0.3);
}

textarea.form-control {
    resize: vertical; /* Allow vertical resizing only */
    min-height: 100px;
}

.btn {
    display: inline-block;
    background-color: #ff4d4d;
    color: #fff;
    padding: 10px 20px;
    font-size: 16px;
    font-weight: bold;
    text-align: center;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
}

.btn:hover {
    background-color: #e63939;
}

/* Responsive Design */
@media (max-width: 768px) {
    .container.form-container {
        padding: 20px;
    }

    .form-title {
        font-size: 20px;
    }

    .btn {
        width: 100%;
        padding: 12px;
    }
}

</style>


    <section class="hero-section">
        <div class="hero-content">
            <h1>Welcome to Blood Donation System</h1>
            <p>Join us in saving lives with blood donation</p>
        </div>
    </section>

    <section class="about-us-section">
        <div class="about-us-container">
            <div class="about-us-photo">
                <img src="https://i.pinimg.com/236x/c9/14/c6/c914c63a80aa1db05328f07054afd299.jpg" alt="Blood Donation">
            </div>
            <div class="about-us-content">
                <h2>About Us</h2>
                <h3>Making a Difference in Lives</h3>
                <p>Our mission is to ensure a constant supply of blood for patients in need, creating a better world for all.</p>
            </div>
        </div>
    </section>

    <section class="possibilities-section">
        <div class="possibilities-container">
            <div class="possibilities-content">
                <h2>Why Donate Blood?</h2>
                <p>Blood donation saves lives. You can make a difference by donating blood, helping hospitals and clinics with their needs.</p>
            </div>
            <div class="possibilities-photo">
                <img src="https://i.pinimg.com/736x/dc/b9/e5/dcb9e58f141142179a84c350f820f496.jpg" alt="Donate Blood">
            </div>
        </div>
    </section>

    <section class="three-column-section">
        <div class="three-column-container">
            <div class="column">
                <h2>How It Works</h2>
                <p>Learn the process of blood donation from registration to donation.</p>
                <ul>
                    <li>Step 1: Register as a donor</li>
                    <li>Step 2: Attend a donation camp</li>
                    <li>Step 3: Make a difference</li>
                </ul>
            </div>
            <div class="column">
                <h2>Get Involved</h2>
                <p>Explore ways to get involved in our blood donation drives and events.</p>
                <ul>
                    <li>Host a donation camp</li>
                    <li>Spread awareness about blood donation</li>
                    <li>Volunteer for events</li>
                </ul>
            </div>
            <div class="column">
                <h2>Request Blood</h2>
                <p>If you need blood for medical purposes, you can request it from our database of registered donors.</p>
                <ul>
                    <li>Fill out the blood request form</li>
                    <li>We will match you with available donors</li>
                    <li>Get in touch with the donor for blood collection</li>
                </ul>
            </div>
        </div>
    </section>

    <section id="Contact">
        <div class="container form-container">
            <h2 class="form-title">Contact Us</h2>
            <form action="https://api.web3forms.com/submit" method="POST" id="form">
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" id="name" name="name" placeholder="Your Full Name" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="Your Email" required>
                </div>
                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea id="message" name="message" placeholder="Your Message" required></textarea>
                </div>
                <input type="hidden" name="access_key" value="your_api_key_here">
                <button type="submit" class="btn">Submit</button>
            </form>
        </div>
    </section>
</body>
</html>
