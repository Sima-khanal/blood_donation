<?php
// Database connection function
function getDBConnection()
{
  // Database credentials
  $host = 'localhost';
  $username = 'root'; // Update with your database username
  $password = ''; // Update with your database password
  $dbname = 'blood_donation';

  try {
    // Create a new PDO instance for database connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $pdo;
  } catch (PDOException $e) {
    // Handle connection errors
    echo "Connection failed: " . $e->getMessage();
    return null;
  }
}

// Function to check if a user exists by email
function userExists($email)
{
  $pdo = getDBConnection();
  if ($pdo) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    return $stmt->fetchColumn() > 0;
  }
  return false;
}

// Function to register a new user
function registerUser($name, $email, $phone, $password, $role)
{
  $pdo = getDBConnection();
  if ($pdo) {
    // Hash the password before saving to database
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (name, email, phone, password, role) 
                               VALUES (:name, :email, :phone, :password, :role)");
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':password', $hashedPassword);
    $stmt->bindParam(':role', $role);
    return $stmt->execute();
  }
  return false;
}

// Function to authenticate user login
function authenticateUser($email, $password)
{
  $pdo = getDBConnection();
  if ($pdo) {
    $stmt = $pdo->prepare("SELECT id, password, role FROM users WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
      // Return user data if authentication is successful
      return $user;
    }
  }
  return false;
}

// Function to create a new blood request
function createBloodRequest($userId, $bloodType, $quantity)
{
  $pdo = getDBConnection();
  if ($pdo) {
    $stmt = $pdo->prepare("INSERT INTO blood_requests (user_id, blood_type, quantity) 
                               VALUES (:user_id, :blood_type, :quantity)");
    $stmt->bindParam(':user_id', $userId);
    $stmt->bindParam(':blood_type', $bloodType);
    $stmt->bindParam(':quantity', $quantity);
    return $stmt->execute();
  }
  return false;
}

// Function to update the blood stock
function updateBloodStock($bloodType, $quantity)
{
  $pdo = getDBConnection();
  if ($pdo) {
    // Check if the blood type already exists in stock
    $stmt = $pdo->prepare("SELECT quantity FROM blood_stock WHERE blood_type = :blood_type");
    $stmt->bindParam(':blood_type', $bloodType);
    $stmt->execute();
    $existingStock = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existingStock) {
      // Update existing stock
      $newQuantity = $existingStock['quantity'] + $quantity;
      $updateStmt = $pdo->prepare("UPDATE blood_stock SET quantity = :quantity WHERE blood_type = :blood_type");
      $updateStmt->bindParam(':quantity', $newQuantity);
      $updateStmt->bindParam(':blood_type', $bloodType);
      return $updateStmt->execute();
    } else {
      // Add new stock entry
      $insertStmt = $pdo->prepare("INSERT INTO blood_stock (blood_type, quantity) VALUES (:blood_type, :quantity)");
      $insertStmt->bindParam(':blood_type', $bloodType);
      $insertStmt->bindParam(':quantity', $quantity);
      return $insertStmt->execute();
    }
  }
  return false;
}

// Function to cancel a blood request
function cancelBloodRequest($requestId)
{
  $pdo = getDBConnection();
  if ($pdo) {
    $stmt = $pdo->prepare("DELETE FROM blood_requests WHERE request_id = :request_id");
    $stmt->bindParam(':request_id', $requestId);
    return $stmt->execute();
  }
  return false;
}

// Function to get blood stock information
function getBloodStock()
{
  $pdo = getDBConnection();
  if ($pdo) {
    $stmt = $pdo->prepare("SELECT * FROM blood_stock");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
  }
  return [];
}

// Function to get all blood requests (for admin view)
function getBloodRequests()
{
  $pdo = getDBConnection();
  if ($pdo) {
    $stmt = $pdo->prepare("SELECT * FROM blood_requests");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
  }
  return [];
}

// Function to get a user's blood requests
function getUserBloodRequests($userId)
{
  $pdo = getDBConnection();
  if ($pdo) {
    $stmt = $pdo->prepare("SELECT * FROM blood_requests WHERE user_id = :user_id");
    $stmt->bindParam(':user_id', $userId);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
  }
  return [];
}

// Function to get a user's request cancellation history
function getUserCancellationHistory($userId)
{
  $pdo = getDBConnection();
  if ($pdo) {
    $stmt = $pdo->prepare("SELECT * FROM request_cancellations WHERE request_id IN (SELECT request_id FROM blood_requests WHERE user_id = :user_id)");
    $stmt->bindParam(':user_id', $userId);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
  }
  return [];
}
