<?php
// Include the database connection
include('db.php');

// Check if the user has taken any action
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $donation_id = $_POST['donation_id']; // Donation ID from form
    $action = $_POST['action']; // Action (Delete)

    // Delete the donation request if it's not accepted yet
    if ($action === "Delete") {
        $sql = "DELETE FROM donation WHERE id = ? AND status != 'Accepted'";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("i", $donation_id);
            if ($stmt->execute()) {
                echo "<script>alert('Donation request deleted successfully!');</script>";
            } else {
                echo "<p style='color: red;'>Error: " . $stmt->error . "</p>";
            }
            $stmt->close();
        } else {
            echo "<p style='color: red;'>Database error: " . $conn->error . "</p>";
        }
    }
}

// Fetch all donations from the database
$sql = "SELECT * FROM donation";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Donations - User</title>
    <style>
        body {
            background: #f0f0f0;
            font-family: Arial, sans-serif;
        }

        /* Glass Effect Navbar */
        .glass-navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            background: rgba(255, 255, 255, 0.2);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .navbar-left h1 {
            font-size: 24px;
            color: #ff4d4d;
        }

        .navbar-right ul {
            list-style: none;
            display: flex;
            gap: 20px;
        }

        .navbar-right ul li {
            display: inline;
        }

        .navbar-right ul li a {
            text-decoration: none;
            color: #333;
            font-weight: bold;
            padding: 8px 15px;
            border-radius: 20px;
            transition: 0.3s;
        }

        .navbar-right ul li a:hover {
            background: rgba(255, 77, 77, 0.2);
            color: #ff4d4d;
        }

        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
        }

        th {
            background: #ff4d4d;
            color: white;
        }

        /* Status Colors */
        .status-pending {
            background: orange;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
        }

        .status-accepted {
            background: green;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
        }

        .status-rejected {
            background: red;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
        }

        /* Delete Button */
        .delete-btn {
            background: red;
            color: white;
            padding: 8px 12px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
            transition: 0.3s;
        }

        .delete-btn:hover {
            background: darkred;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .glass-navbar {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }

            .navbar-right ul {
                flex-direction: column;
                gap: 10px;
            }

            table {
                font-size: 14px;
            }

            th, td {
                padding: 8px;
            }
        }
    </style>
</head>
<body>
    <nav class="glass-navbar">
        <div class="navbar-left">
            <h1>Blood Donation System</h1>
        </div>
        <div class="navbar-right">
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="request_blood.php">Request</a></li>
                <li><a href="blood_donation.php">Donation</a></li>
                <li><a href="view_requests.php">View Request Status</a></li>
                <li><a href="view_donation_status.php">Donation Status</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <h1>Your Donation Requests</h1>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Birthdate</th>
                <th>Last Donated Date</th>
                <th>Donation Date</th>
                <th>Blood Type</th>
                <th>Weight</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
<tbody>
    <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['birthdate']; ?></td>
            <td><?php echo $row['last_donated_date']; ?></td>
            <td><?php echo $row['donation_date']; ?></td>
            <td><?php echo $row['blood_type']; ?></td>
            <td><?php echo $row['weight_kg']; ?></td>
            <td>
                <?php 
                    $status = $row['status'];
                    $color = "";
                    if ($status == "Pending") {
                        $color = "orange";
                    } elseif ($status == "Accepted") {
                        $color = "green";
                    } elseif ($status == "Completed") {
                        $color = "blue";
                    } elseif ($status == "Rejected") {
                        $color = "red";
                    }
                ?>
                <span style="color: white; background-color: <?php echo $color; ?>; padding: 5px 10px; border-radius: 5px;">
                    <?php echo $status; ?>
                </span>
            </td>
            <td>
                <?php if ($row['status'] != 'Accepted' && $row['status'] != 'Completed') { ?>
                    <form method="POST" action="view_donation_status.php">
                        <input type="hidden" name="donation_id" value="<?php echo $row['id']; ?>">
                        <button type="submit" name="action" value="Delete" style="background-color: red; color: white; padding: 5px 10px; border: none; border-radius: 5px; cursor: pointer;">
                            Delete
                        </button>
                    </form>
                <?php } ?>
            </td>
        </tr>
    <?php } ?>
</tbody>

    </table>

    <?php include('footer.php'); ?>

</body>
</html>
