<?php
// header.php

// You can include any global elements like database connections or user session logic here

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Blood Donation System</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>

  <header>
  <div class="container-header">
    <!-- Logo Section -->
    <div class="logo" id="left">
      <img src="https://i.pinimg.com/474x/3f/66/64/3f66647bf0b133d872d22f016aedaf56.jpg" alt="Hospital Logo">
    </div>

    <!-- Navigation Menu -->
    <div class="links" id="right">
      <nav>
        <ul>
          <li><a href="dashboard.php">Dashboard</a></li>
          <li><a href="request_blood.php">Request Blood</a></li>
          <li><a href="view_requests.php">View Requests</a></li>
          <li><a href="blood_donation.php">Blood Donation</a></li>
          <li><a href="logout.php">Logout</a></li>
        </ul>
      </nav>
    </div>
  </div>
</header>
<script src="script.js"></script>
