<?php
$servername = "localhost"; // or the server name (e.g., 127.0.0.1)
$username = "root"; // your database username
$password = ""; // your database password (usually empty for XAMPP)
$database = "blood_donation"; // your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
