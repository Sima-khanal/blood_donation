<?php
session_start();

// Include the database connection
include('db.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
  header("Location: login.php"); // Redirect to login page if not logged in
  exit();
}

// Get the request ID from the URL
if (isset($_GET['request_id'])) {
  $request_id = $_GET['request_id'];

  // Check if the request exists and belongs to the logged-in user
  $user_id = $_SESSION['user_id'];
  $sql = "SELECT * FROM blood_requests WHERE id = '$request_id' AND user_id = '$user_id' AND status = 'pending'";
  $result = mysqli_query($conn, $sql);

  if (mysqli_num_rows($result) > 0) {
    // Delete the request permanently from the database
    $delete_sql = "DELETE FROM blood_requests WHERE id = '$request_id'";
    if (mysqli_query($conn, $delete_sql)) {
      // Redirect back to the view requests page with a success message
      header("Location: view_requests.php?message=Request successfully canceled and deleted.");
      exit();
    } else {
      $error_message = "Error: Could not cancel and delete the request.";
    }
  } else {
    $error_message = "No pending request found with the provided ID.";
  }
} else {
  $error_message = "Invalid request ID.";
}

?>

<!-- Cancel Request Section -->
<section id="cancel-request-section">
  <div class="cancel-container">
    <h2>Cancel Blood Donation Request</h2>
    <?php
    if (isset($success_message)) {
      echo '<p class="success-message">' . $success_message . '</p>';
    }
    if (isset($error_message)) {
      echo '<p class="error-message">' . $error_message . '</p>';
    }
    ?>
    <p>If you want to cancel and delete your pending request, please confirm by clicking the button below. Once deleted, your request will no longer be processed and will be permanently removed.</p>
    <a href="cancel_request.php?request_id=<?php echo $request_id; ?>" class="btn-confirm-cancel">Cancel Request</a>
  </div>
</section>
<script src="script.js"></script>