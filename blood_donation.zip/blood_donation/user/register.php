<?php
// Include the database connection
include('db.php');

// Define variables and set them to empty values
$name = $email = $phone = $password = "";
$nameErr = $emailErr = $phoneErr = $passwordErr = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Validate the inputs
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
  }

  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    // Check if the email format is valid
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
    }
  }

  if (empty($_POST["phone"])) {
    $phoneErr = "Phone number is required";
  } else {
    $phone = test_input($_POST["phone"]);
  }

  if (empty($_POST["password"])) {
    $passwordErr = "Password is required";
  } else {
    $password = password_hash(test_input($_POST["password"]), PASSWORD_DEFAULT); // Hash the password
  }


  // If no validation errors, proceed with inserting the data into the database
  if (empty($nameErr) && empty($emailErr) && empty($phoneErr) && empty($passwordErr)) {
    // Prepare the SQL query to insert user data
    $sql = "INSERT INTO users (name, email, phone, password) 
            VALUES ('$name', '$email', '$phone', '$password')";

    if (mysqli_query($conn, $sql)) {
      // Successfully inserted, redirect to a confirmation or login page
      header("Location: login.php");
      exit();
    } else {
      // Check if the error is a duplicate entry error
      if (mysqli_errno($conn) == 1062) {
        $emailErr = "This email is already registered.";
      } else {
        echo "Error: " . mysqli_error($conn);
      }
    }
  }
}

// Function to clean input data to avoid XSS and other vulnerabilities
function test_input($data)
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registration Form</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f9;
      color: #333;
    }

    #register-section {
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      background-color: #f8f9fa;
    }

    .register-container {
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      max-width: 500px;
      width: 100%;
      padding: 20px;
    }

    .register-container h2 {
      text-align: center;
      margin-bottom: 20px;
      color: #007bff;
    }

    form {
      display: flex;
      flex-direction: column;
    }

    form label {
      margin-bottom: 5px;
      font-weight: bold;
    }

    form input,
    form select {
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }

    form .error {
      color: #d9534f;
      font-size: 12px;
    }

    .btn-submit {
      background-color: #007bff;
      color: white;
      padding: 10px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .btn-submit:hover {
      background-color: #0056b3;
    }
  </style>
</head>

<body>
  <section id="register-section">
    <div class="register-container">
      <h2>User Registration</h2>
      <form action="register.php" method="POST">
        <label for="name">Full Name:</label>
        <input type="text" id="name" name="name" value="<?php echo $name; ?>" required />
        <span class="error"><?php echo $nameErr; ?></span>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo $email; ?>" required />
        <span class="error"><?php echo $emailErr; ?></span>

        <label for="phone">Phone Number:</label>
        <input type="text" id="phone" name="phone" value="<?php echo $phone; ?>" required />
        <span class="error"><?php echo $phoneErr; ?></span>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required />
        <span class="error"><?php echo $passwordErr; ?></span>
        <button type="submit" class="btn-submit">Register</button>
        <p> Already have account? <a href=login.php>Login Here</a>
      </form>
    </div>
  </section>
</body>

</html>