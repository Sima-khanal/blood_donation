<?php
// Include the database connection
include('db.php');

// Define variables and set them to empty values
$name = $email = $phone = $password = $confirm_password = "";
$nameErr = $emailErr = $phoneErr = $passwordErr = $confirmPasswordErr = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Validate the inputs
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
  }

  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    // Check if the email format is valid
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
    } else {
      // Check if the email already exists in the database
      $checkEmailQuery = "SELECT * FROM users WHERE email = '$email'";
      $emailResult = mysqli_query($conn, $checkEmailQuery);
      if (mysqli_num_rows($emailResult) > 0) {
        $emailErr = "This email is already registered.";
      }
    }
  }

  if (empty($_POST["phone"])) {
    $phoneErr = "Phone number is required";
  } else {
    $phone = test_input($_POST["phone"]);
    // Check if phone is a valid number
    if (!preg_match("/^[0-9]{10}$/", $phone)) {
      $phoneErr = "Invalid phone number";
    } else {
      // Check if the phone number already exists in the database
      $checkPhoneQuery = "SELECT * FROM users WHERE phone = '$phone'";
      $phoneResult = mysqli_query($conn, $checkPhoneQuery);
      if (mysqli_num_rows($phoneResult) > 0) {
        $phoneErr = "This phone number is already registered.";
      }
    }
  }

  if (empty($_POST["password"])) {
    $passwordErr = "Password is required";
  } else {
    $password = test_input($_POST["password"]);
    // Check if password meets minimum strength
    if (!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/", $password)) {
      $passwordErr = "Password must be at least 6 characters, include at least one uppercase letter, one lowercase letter, one number, and one special character.";
    }
  }

  if (empty($_POST["confirm_password"])) {
    $confirmPasswordErr = "Confirm Password is required";
  } else {
    $confirm_password = test_input($_POST["confirm_password"]);
    if ($password !== $confirm_password) {
      $confirmPasswordErr = "Passwords do not match.";
    }
  }

  // If no validation errors, proceed with inserting the data into the database
  if (empty($nameErr) && empty($emailErr) && empty($phoneErr) && empty($passwordErr) && empty($confirmPasswordErr)) {
    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    // Prepare the SQL query to insert user data
    $sql = "INSERT INTO users (name, email, phone, password) 
            VALUES ('$name', '$email', '$phone', '$hashedPassword')";

    if (mysqli_query($conn, $sql)) {
      // Successfully inserted, redirect to a confirmation or login page
      header("Location: login.php");
      exit();
    } else {
      echo "Error: " . mysqli_error($conn);
    }
  }
}

// Function to clean input data to avoid XSS and other vulnerabilities
function test_input($data)
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registration Form</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f9;
      color: #333;
    }

    #register-section {
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      background-color: #f8f9fa;
    }

    .register-container {
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      max-width: 500px;
      width: 100%;
      padding: 20px;
    }

    .register-container h2 {
      text-align: center;
      margin-bottom: 20px;
      color: #007bff;
    }

    form {
      display: flex;
      flex-direction: column;
    }

    form label {
      margin-bottom: 5px;
      font-weight: bold;
    }

    form input {
      padding: 10px;
      margin-bottom: 5px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }

    form .error {
      color: #d9534f;
      font-size: 12px;
      margin-bottom: 15px;
    }

    .btn-submit {
      background-color: #007bff;
      color: white;
      padding: 10px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .btn-submit:hover {
      background-color: #0056b3;
    }

    ul {
      padding-left: 20px;
    }
  </style>
</head>

<body>
  <section id="register-section">
    <div class="register-container">
      <h2>User Registration</h2>
      <form id="registration-form" method="POST">
        <label for="name">Full Name:</label>
        <input type="text" id="name" name="name" required />
        <span class="error" id="name-error"></span>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required />
        <span class="error" id="email-error"></span>

        <label for="phone">Phone Number:</label>
        <input type="text" id="phone" name="phone" required />
        <span class="error" id="phone-error"></span>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required />
        <span class="error" id="password-error"></span>

        <label for="confirm_password">Confirm Password:</label>
        <input type="password" id="confirm_password" name="confirm_password" required />
        <span class="error" id="confirm-password-error"></span>

        <button type="submit" class="btn-submit">Register</button>
        <p>Already have an account? <a href="login.php">Login Here</a></p>
      </form>
    </div>
  </section>

  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const name = document.getElementById('name');
      const email = document.getElementById('email');
      const phone = document.getElementById('phone');
      const password = document.getElementById('password');
      const confirmPassword = document.getElementById('confirm_password');

      const nameError = document.getElementById('name-error');
      const emailError = document.getElementById('email-error');
      const phoneError = document.getElementById('phone-error');
      const passwordError = document.getElementById('password-error');
      const confirmPasswordError = document.getElementById('confirm-password-error');

      const passwordRules = [
        { regex: /[a-z]/, message: "At least one lowercase letter is required." },
        { regex: /[A-Z]/, message: "At least one uppercase letter is required." },
        { regex: /\d/, message: "At least one number is required." },
        { regex: /[@$!%*?&]/, message: "At least one special character is required." },
        { regex: /.{6,}/, message: "Password must be at least 6 characters long." },
      ];

      // Real-time validation for the name
      name.addEventListener('input', () => {
        if (name.value.trim() === "") {
          nameError.textContent = "Name is required.";
        } else if (!/^[a-zA-Z\s]+$/.test(name.value)) {
          nameError.textContent = "Name must only contain letters and spaces.";
        } else {
          nameError.textContent = "";
        }
      });

      // Real-time validation for the email
      email.addEventListener('input', () => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email.value)) {
          emailError.textContent = "Invalid email format.";
        } else {
          emailError.textContent = "";
        }
      });

      // Real-time validation for the phone
      phone.addEventListener('input', () => {
        if (!/^\d{10}$/.test(phone.value)) {
          phoneError.textContent = "Phone number must be exactly 10 digits.";
        } else {
          phoneError.textContent = "";
        }
      });

      // Real-time validation for the password
      password.addEventListener('input', () => {
        const errors = passwordRules
          .filter(rule => !rule.regex.test(password.value))
          .map(rule => `<li>${rule.message}</li>`).join("");

        passwordError.innerHTML = errors ? `<ul>${errors}</ul>` : "";
      });

      // Real-time validation for confirm password
      confirmPassword.addEventListener('input', () => {
        if (password.value !== confirmPassword.value) {
          confirmPasswordError.textContent = "Passwords do not match.";
        } else {
          confirmPasswordError.textContent = "";
        }
      });
    });
  </script>
</body>

</html>
