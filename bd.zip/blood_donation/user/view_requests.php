<?php
session_start();

// Include the database connection
include('db.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
  header("Location: login.php"); // Redirect to login page if not logged in
  exit();
}

// Get the logged-in user's ID
$user_id = $_SESSION['user_id'];

// Retrieve the blood requests made by the logged-in user
$sql = "SELECT * FROM blood_requests WHERE user_id = '$user_id'";
$result = mysqli_query($conn, $sql);

?>

<?php include('header.php'); ?>

<!-- View Requests Section -->
<section id="view-requests-section">
  <div class="view-requests-container">
    <h2>Your Blood Donation Requests</h2>

    <?php
    // Check if the user has made any requests
    if (mysqli_num_rows($result) > 0) {
      // Display the requests in a table
      echo '<table class="requests-table">
                    <tr>
                        <th>Blood Type</th>
                        <th>Contact Number</th>
                        <th>Status</th>
                        <th>Quantity</th>
                        <th>Message</th>
                        <th>Action</th>
                    </tr>';

      while ($row = mysqli_fetch_assoc($result)) {
        // Determine the status
        $status = $row['status'] == 'pending' ? 'Pending' : ($row['status'] == 'approved' ? 'Approved' : 'Dispatched');
        
        // Get the number of quantity updates
        $quantity_updates = $row['quantity_updates']; // Assuming you have this column to track updates

        // Allow users to update the quantity only if status is 'pending' and updates are less than 3
        $can_update = ($row['status'] == 'pending' && $quantity_updates < 3);

        echo '<tr>
                        <td>' . $row['blood_type'] . '</td>
                        <td>' . $row['contact_number'] . '</td>
                        <td>' . $status . '</td>
                        <td>' . $row['quantity'] . '</td>
                        <td>' . $row['message'] . '</td>
                        <td>';

        // If the request is still pending and the user can update the quantity
        if ($can_update) {
          echo '<a href="update_quantity.php?request_id=' . $row['id'] . '" class="btn-update-quantity">Update Quantity</a>';
        } else {
          echo 'N/A'; // If the request is not pending or max updates reached, show "N/A"
        }

        echo '</td></tr>';
      }

      echo '</table>';
    } else {
      echo '<p>You have not made any blood donation requests yet.</p>';
    }
    ?>
  </div>
</section>

<script src="script.js"></script>

<style>
  /* View Requests Section */
  #view-requests-section {
    padding: 40px 20px;
    background-color: #f9f9f9;
    font-family: Arial, sans-serif;
  }

  .view-requests-container {
    max-width: 900px;
    margin: 0 auto;
    background-color: #fff;
    padding: 20px 30px;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  }

  .view-requests-container h2 {
    text-align: center;
    font-size: 24px;
    color: #333;
    margin-bottom: 20px;
  }

  /* Table Styling */
  .requests-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
  }

  .requests-table th,
  .requests-table td {
    padding: 12px 15px;
    text-align: center;
    border: 1px solid #ddd;
    font-size: 14px;
  }

  .requests-table th {
    background-color: #007bff;
    color: #fff;
    font-weight: bold;
  }

  .requests-table tr:nth-child(even) {
    background-color: #f2f2f2;
  }

  .requests-table tr:hover {
    background-color: #e6f7ff;
  }

  /* Action Button Styling */
  .btn-update-quantity {
    display: inline-block;
    padding: 8px 12px;
    background-color: #ff9900;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
    font-size: 14px;
    transition: background-color 0.3s;
  }

  .btn-update-quantity:hover {
    background-color: #cc7a00;
  }

  /* No Requests Message */
  .view-requests-container p {
    text-align: center;
    color: #666;
    font-size: 16px;
    margin-top: 20px;
  }

  /* Responsive Design */
  @media (max-width: 768px) {
    .view-requests-container {
      padding: 15px 20px;
    }

    .requests-table th,
    .requests-table td {
      padding: 10px;
      font-size: 12px;
    }

    .btn-update-quantity {
      font-size: 12px;
      padding: 6px 10px;
    }
  }
</style>

<?php include('footer.php'); ?>
