<?php
session_start();
include('db.php');

if (!isset($_SESSION['user_id']) || !isset($_GET['request_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$request_id = $_GET['request_id'];

// Fetch the request
$sql = "SELECT * FROM blood_requests WHERE id = '$request_id' AND user_id = '$user_id'";
$result = mysqli_query($conn, $sql);
$request = mysqli_fetch_assoc($result);

if ($request) {
    // Allow the user to update the quantity if status is 'pending' and less than 3 updates
    if ($request['status'] == 'pending' && $request['quantity_updates'] < 3) {
        // Process the form to update the quantity
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $new_quantity = $_POST['quantity'];
            $sql_update = "UPDATE blood_requests SET quantity = '$new_quantity', quantity_updates = quantity_updates + 1 WHERE id = '$request_id'";
            mysqli_query($conn, $sql_update);
            header("Location: view_requests.php");
        }
    } else {
        echo "You cannot update the quantity anymore.";
    }
} else {
    echo "Invalid request.";
}
?>

<!-- HTML form for updating quantity -->
<form method="post">
    <label for="quantity">New Quantity:</label>
    <input type="number" id="quantity" name="quantity" required min="1" value="<?= $request['quantity'] ?>">
    <button type="submit">Update Quantity</button>
</form>
