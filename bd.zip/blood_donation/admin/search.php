<?php
// Include database connection
include('db.php');

// Check if search query is provided
if (isset($_GET['blood_type'])) {
    $blood_type = $_GET['blood_type'];

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT stock FROM blood_stock WHERE blood_type = ?");
    $stmt->bind_param("s", $blood_type);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo "Blood Type: " . $blood_type . ", Quantity Available: " . $row['stock'];
    } else {
        echo "No stock available for Blood Type: " . $blood_type;
    }

    $stmt->close();
} else {
    echo "Please provide a blood type to search.";
}

$conn->close();
?>
