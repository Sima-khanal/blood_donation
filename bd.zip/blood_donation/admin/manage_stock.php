<?php
include('db.php');
$query = "SELECT * FROM blood_stock ORDER BY blood_type ASC";
$result = $conn->query($query);
$bloodStocks = $result->num_rows > 0 ? $result->fetch_all(MYSQLI_ASSOC) : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Blood Stock Management Dashboard</title>
  <style>
    body {
  font-family: Arial, sans-serif;
  background-color: #f9f9f9;
  margin: 0;
  padding: 0;
  color: #333;
}

.container {
  width: 90%;
  max-width: 1200px;
  margin: 20px auto;
  background: #ffffff;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

h1 {
  text-align: center;
  color: #4CAF50;
  font-size: 2em;
  margin-bottom: 20px;
}

h2 {
  color: #333;
  margin-top: 20px;
  border-bottom: 2px solid #4CAF50;
  display: inline-block;
  padding-bottom: 5px;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 10px;
}

table th,
table td {
  text-align: left;
  padding: 12px;
  border: 1px solid #ddd;
}

table th {
  background-color: #4CAF50;
  color: #fff;
  text-transform: uppercase;
  font-size: 0.9em;
}

table tr:nth-child(even) {
  background-color: #f2f2f2;
}

table tr:hover {
  background-color: #e0ffe0;
}

table td button {
  background-color: #4CAF50;
  color: white;
  border: none;
  padding: 5px 10px;
  font-size: 0.9em;
  cursor: pointer;
  border-radius: 5px;
}

table td button:hover {
  background-color: #45a049;
}

table td input[type="number"] {
  width: 60px;
  padding: 5px;
  border: 1px solid #ddd;
  border-radius: 5px;
}

p {
  text-align: center;
  font-size: 1em;
  color: #777;
}

form {
  display: inline;
}

@media (max-width: 768px) {
  .container {
    width: 95%;
  }

  h1 {
    font-size: 1.5em;
  }

  table th,
  table td {
    font-size: 0.9em;
    padding: 8px;
  }

  table td input[type="number"] {
    width: 50px;
  }
}

  </style>
</head>
<body>
  <div class="container">
    <h1>Blood Stock Management Dashboard</h1>
    <?php if (!empty($bloodStocks)): ?>
      <?php foreach (['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'] as $bloodType): ?>
        <?php
        $groupStocks = array_filter($bloodStocks, fn($stock) => $stock['blood_type'] === $bloodType);
        if (!empty($groupStocks)):
        ?>
          <h2><?= htmlspecialchars($bloodType); ?> Blood Group</h2>
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Blood Type</th>
                <th>Stock</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($groupStocks as $stock): ?>
                <tr>
                  <td><?= htmlspecialchars($stock['id']); ?></td>
                  <td><?= htmlspecialchars($stock['blood_type']); ?></td>
                  <td><?= isset($stock['stock']) ? htmlspecialchars($stock['stock']) : 'N/A'; ?></td>
                  <td>
                    <form method="POST" action="crud.php" style="display: inline;">
                      <input type="hidden" name="id" value="<?= $stock['id']; ?>">
                      <input type="number" name="stock" value="<?= isset($stock['stock']) ? htmlspecialchars($stock['stock']) : 0; ?>" min="0" required>
                      <button type="submit" name="update">Update</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php else: ?>
          <p>No stock available for <?= htmlspecialchars($bloodType); ?>.</p>
        <?php endif; ?>
      <?php endforeach; ?>
    <?php else: ?>
      <p>No blood stock available.</p>
    <?php endif; ?>
  </div>
</body>
</html>
